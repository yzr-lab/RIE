import numpy as np

from rineng_replay.monitors import fit_monitor
from rineng_replay.relations import fit_top_strength_relations


def _stable_and_changed() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(121)
    source = rng.normal(size=140)
    stable_target = np.roll(source, 1) + 0.04 * rng.normal(size=140)
    calibration = np.column_stack((source[:60], stable_target[:60], rng.normal(size=60)))
    stable = np.column_stack((source[60:100], stable_target[60:100], rng.normal(size=40)))
    changed = np.column_stack((source[100:140], -np.roll(source[100:140], 1), rng.normal(size=40)))
    return calibration, stable, changed


def test_ldsi_increases_after_relation_change() -> None:
    calibration, stable, changed = _stable_and_changed()
    relations = fit_top_strength_relations(calibration, max_lag=2, m=6)
    stable_monitor = fit_monitor("ldsi", calibration, relations, aggregation_k=3)
    changed_monitor = fit_monitor("ldsi", calibration, relations, aggregation_k=3)
    stable_score = stable_monitor.score_window(stable).score
    changed_score = changed_monitor.score_window(changed).score
    assert changed_score > stable_score


def test_dynamic_correlation_change_has_increasing_score_direction() -> None:
    calibration, stable, changed = _stable_and_changed()
    relations = fit_top_strength_relations(calibration, max_lag=2, m=6)
    stable_monitor = fit_monitor("dynamic_corr", calibration, relations, 3)
    changed_monitor = fit_monitor("dynamic_corr", calibration, relations, 3)
    assert changed_monitor.score_window(changed).score > stable_monitor.score_window(stable).score

