import json
from pathlib import Path

import pytest

from rineng_replay.ledger import (
    LedgerIntegrityError,
    ScoreRecord,
    verify_locked_ledger,
    write_score_ledger,
)


def _record() -> ScoreRecord:
    return ScoreRecord(
        subset="FD001",
        engine_id=1,
        condition_group="single",
        fault_mode_group="one",
        calibration_end=60,
        window_start=61,
        window_end=100,
        score_time=100,
        monitor="LDSI",
        conditioning="raw",
        selector_m=20,
        aggregation_k=5,
        score=0.25,
        threshold=0.2,
        alert=True,
        persistent_alert=False,
        episode_id=None,
        contributors_json="[]",
    )


def test_score_ledger_round_trip(tmp_path: Path) -> None:
    path = tmp_path / "scores.jsonl"
    manifest = write_score_ledger([_record()], path, "a" * 64)
    verify_locked_ledger(path, manifest)
    payload = json.loads(path.read_text(encoding="utf-8").strip())
    assert payload["score_time"] == payload["window_end"] == 100


def test_modified_ledger_fails_hash_verification(tmp_path: Path) -> None:
    path = tmp_path / "scores.jsonl"
    manifest = write_score_ledger([_record()], path, "b" * 64)
    with path.open("ab") as stream:
        stream.write(b" ")
    with pytest.raises(LedgerIntegrityError):
        verify_locked_ledger(path, manifest)

