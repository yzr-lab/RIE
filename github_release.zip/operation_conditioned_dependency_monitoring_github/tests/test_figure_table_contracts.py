from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]


def test_main_tables_use_booktabs_and_no_vertical_rules() -> None:
    for name in (
        "table1_protocol.tex",
        "table2_raw_conditioned.tex",
        "table3_operational_frontier.tex",
    ):
        text = (ROOT / "tables" / name).read_text(encoding="utf-8")
        assert "\\toprule" in text
        assert "\\bottomrule" in text
        assert "|" not in text
        assert "denominator" in text.lower() or "$n$" in text


def test_mandatory_figures_have_vector_and_600_dpi_exports() -> None:
    for stem in (
        "figure1_workflow",
        "figure2_information_timeline",
        "figure3_condition_effects",
        "figure4_lead_workload",
    ):
        for suffix in (".pdf", ".svg", ".png"):
            assert (ROOT / "figures" / f"{stem}{suffix}").is_file()
        with Image.open(ROOT / "figures" / f"{stem}.png") as image:
            dpi = image.info.get("dpi", (0, 0))
            assert dpi[0] >= 590 and dpi[1] >= 590
        svg = (ROOT / "figures" / f"{stem}.svg").read_text(encoding="utf-8")
        assert "<text" in svg


def test_claim_evidence_map_names_every_main_figure_and_table() -> None:
    text = (ROOT / "docs" / "claim_evidence_map.md").read_text(encoding="utf-8")
    for number in range(1, 5):
        assert f"Figure {number}" in text
    for number in range(1, 4):
        assert f"Table {number}" in text
