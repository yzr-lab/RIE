import numpy as np
import pandas as pd

from rineng_replay.statistics import fixed_fd_engine_bootstrap


def test_fixed_fd_bootstrap_is_deterministic_and_finite() -> None:
    frame = pd.DataFrame(
        {
            "subset": ["FD001"] * 4 + ["FD002"] * 3,
            "engine_id": list(range(1, 5)) + list(range(1, 4)),
            "value": [0.1, 0.2, 0.3, 0.4, 0.8, 0.9, 1.0],
        }
    )
    first = fixed_fd_engine_bootstrap(frame, n_resamples=200, seed=19)
    second = fixed_fd_engine_bootstrap(frame, n_resamples=200, seed=19)
    assert first == second
    assert np.isfinite(first["estimate"])
    assert first["ci_low"] <= first["estimate"] <= first["ci_high"]
    assert first["fd_counts"] == {"FD001": 4, "FD002": 3}


def test_bootstrap_requires_one_value_per_engine() -> None:
    frame = pd.DataFrame(
        {"subset": ["FD001", "FD001"], "engine_id": [1, 1], "value": [1.0, 2.0]}
    )
    try:
        fixed_fd_engine_bootstrap(frame, n_resamples=20, seed=1)
    except ValueError as error:
        assert "one value per engine" in str(error)
    else:
        raise AssertionError("duplicate engines must be rejected")

