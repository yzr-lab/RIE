"""R1: calibration-support flags are exposed per window and are flag-only."""

from __future__ import annotations

import numpy as np

from rineng_replay.data import ObservedTrajectory, SENSOR_NAMES
from rineng_replay.protocol import ReplayConfig
from rineng_replay.replay import score_trajectory


def _config() -> ReplayConfig:
    return ReplayConfig(
        calibration_cycles=60,
        window_size=40,
        step=10,
        persistence=3,
        max_lag=3,
        selector_m=20,
        aggregation_k=5,
        min_monitor_windows=5,
    )


def make_shifted_trajectory() -> ObservedTrajectory:
    """Calibration settings form a tight cloud; later settings shift far away."""
    n = 200
    rng = np.random.default_rng(123)
    settings = rng.normal(size=(n, 3)) * 0.05
    settings[60:] += 6.0  # far outside the calibration support cloud
    sensors = rng.normal(size=(n, len(SENSOR_NAMES)))
    sensors[60:] += settings[60:, :1]  # keep a deterministic setting dependency
    return ObservedTrajectory(
        "FD002", 1, np.arange(1, n + 1), settings, sensors, SENSOR_NAMES
    )


def test_support_fields_are_present_and_flag_only():
    z = make_shifted_trajectory()
    cfg = _config()
    result = score_trajectory(z, cfg, conditioning="linear", monitor_names=("ldsi",))
    records = result.records["ldsi"]
    assert len(records) > 0, "flag-only must still produce scores for unsupported windows"
    for record in records:
        assert record.support_policy == "flag_only"
        assert record.support_radius > 0.0
        # late windows are outside support -> at least one unsupported row
        if record.score_time >= 140:
            assert record.unsupported_rows_in_window > 0


def test_unsupported_rows_are_counted_not_dropped():
    z = make_shifted_trajectory()
    cfg = _config()
    result = score_trajectory(z, cfg, conditioning="linear", monitor_names=("ldsi",))
    records = result.records["ldsi"]
    # windows before the shift (score_time 100,110,120) use only post-calibration
    # rows 61..120, which are within the support cloud for 100/110 but the shift
    # begins at row 60 (cycle 61), so the first window already sees shifted rows.
    # The key invariant: every completed window is scored (none silently dropped).
    scored_times = sorted(r.score_time for r in records)
    assert scored_times[0] == 100
    assert any(r.unsupported_rows_in_window > 0 for r in records)
