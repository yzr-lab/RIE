import numpy as np
import pytest

from rineng_replay.monitors import MONITOR_NAMES, fit_monitor
from rineng_replay.relations import fit_top_strength_relations


def _signals() -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(818)
    calibration = rng.normal(size=(60, 5))
    calibration[1:, 1] = 0.8 * calibration[:-1, 0] + 0.2 * calibration[1:, 1]
    window = rng.normal(size=(40, 5))
    window[1:, 1] = -0.8 * window[:-1, 0] + 0.2 * window[1:, 1]
    return calibration, window


@pytest.mark.parametrize("name", MONITOR_NAMES)
def test_monitor_outputs_are_finite_nonnegative_and_auditable(name: str) -> None:
    calibration, window = _signals()
    relations = fit_top_strength_relations(calibration, max_lag=3, m=10)
    monitor = fit_monitor(name, calibration, relations, aggregation_k=5)
    output = monitor.score_window(window)
    assert output.monitor == name
    assert np.isfinite(output.score)
    assert output.score >= 0.0
    assert 1 <= len(output.contributors) <= 5
    assert np.isfinite(monitor.calibration_scores).all()
    assert isinstance(output.state, dict)


def test_aggregation_k_cannot_exceed_candidate_m() -> None:
    calibration, _ = _signals()
    relations = fit_top_strength_relations(calibration, max_lag=2, m=4)
    with pytest.raises(ValueError, match="aggregation_k"):
        fit_monitor("ldsi", calibration, relations, aggregation_k=5)


def test_unknown_monitor_is_rejected() -> None:
    calibration, _ = _signals()
    relations = fit_top_strength_relations(calibration, max_lag=2, m=4)
    with pytest.raises(ValueError, match="unsupported monitor"):
        fit_monitor("opaque_model", calibration, relations, aggregation_k=2)
