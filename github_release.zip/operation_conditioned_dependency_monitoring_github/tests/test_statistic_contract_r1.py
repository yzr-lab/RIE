"""R1: statistic-contract tests — monitor formulas, sensor identity, parameters."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from rineng_replay import monitors as M
from rineng_replay.data import SENSOR_NAMES, SENSOR_ORIGINAL_LABELS
from rineng_replay.monitors import TransparentMonitor
from rineng_replay.relations import Relation, RelationSet


def _rset() -> RelationSet:
    rel = Relation(rank=1, source=0, target=1, lag=1, strength=0.5, sign=1, p_value=0.1)
    return RelationSet(
        relations=(rel,),
        candidate_count=1,
        fdr_retained_count=0,
        sensor_count=len(SENSOR_NAMES),
        max_lag=3,
        calibration_rows=60,
    )


def _monitor(name: str, baseline, scale, agg_k=1) -> TransparentMonitor:
    b = np.asarray(baseline, dtype=float)
    return TransparentMonitor(
        name=name,
        relation_set=_rset(),
        aggregation_k=agg_k,
        baseline=b,
        scale=np.asarray(scale, dtype=float),
        calibration_scores=np.array([0.0]),
        short_state=b.copy(),
        long_state=b.copy(),
        cumulative_state=np.zeros_like(b),
    )


def _patch_relation_values(monkeypatch, values: list[list[float]]):
    it = iter([np.asarray(v, dtype=float) for v in values])
    monkeypatch.setattr(M, "relation_strengths", lambda w, rs: next(it))


def test_ldsi_signed_memory_hand_calculation(monkeypatch):
    """Hand-verified two-step signed EWMA: step1 rho=0.1, step2 rho=-0.1."""
    mon = _monitor("ldsi", baseline=[0.5], scale=[1.0])
    _patch_relation_values(monkeypatch, [[0.1], [-0.1]])
    window = np.zeros((40, len(SENSOR_NAMES)))

    out1 = mon.score_window(window)
    # short = 0.4*0.1 + 0.6*0.5 = 0.34; long = 0.1*0.1 + 0.9*0.5 = 0.46
    assert np.isclose(mon.short_state[0], 0.34, atol=1e-12)
    assert np.isclose(mon.long_state[0], 0.46, atol=1e-12)
    assert np.isclose(out1.score, 0.12 / (0.46 + 0.05), atol=1e-12)

    out2 = mon.score_window(window)
    # signed update: short = 0.4*(-0.1)+0.6*0.34; long = 0.1*(-0.1)+0.9*0.46
    assert np.isclose(mon.short_state[0], 0.4 * (-0.1) + 0.6 * 0.34, atol=1e-12)
    assert np.isclose(mon.long_state[0], 0.1 * (-0.1) + 0.9 * 0.46, atol=1e-12)
    # NOT abs-first: abs(-0.1) would give a different short state
    assert not np.isclose(mon.short_state[0], 0.4 * 0.1 + 0.6 * 0.34, atol=1e-12)


def test_dynamic_corr_is_mean_topk_abs_z(monkeypatch):
    mon = _monitor("dynamic_corr", baseline=[0.5], scale=[0.5])
    # rho = 1.0 -> z = (1.0-0.5)/0.5 = 1.0
    _patch_relation_values(monkeypatch, [[1.0]])
    out = mon.score_window(np.zeros((40, len(SENSOR_NAMES))))
    assert np.isclose(out.score, 1.0, atol=1e-12)


def test_mewma_relation_ewma(monkeypatch):
    mon = _monitor("mewma", baseline=[0.0], scale=[1.0])
    # z values 0.5 then 0.0: m1 = 0.2*0.5 = 0.1; m2 = 0.2*0 + 0.8*0.1 = 0.08
    _patch_relation_values(monkeypatch, [[0.5], [0.0]])
    w = np.zeros((40, len(SENSOR_NAMES)))
    o1 = mon.score_window(w)
    assert np.isclose(mon.short_state[0], 0.1, atol=1e-12)
    assert np.isclose(o1.score, 0.1, atol=1e-12)
    o2 = mon.score_window(w)
    assert np.isclose(mon.short_state[0], 0.08, atol=1e-12)
    assert np.isclose(o2.score, 0.08, atol=1e-12)


def test_mcusum_absolute_deviation(monkeypatch):
    mon = _monitor("mcusum", baseline=[0.0], scale=[1.0])
    # |z| = 1.0 each step, allowance 0.5 -> c = 0.5, 1.0, 1.5
    _patch_relation_values(monkeypatch, [[1.0], [1.0], [1.0]])
    w = np.zeros((40, len(SENSOR_NAMES)))
    assert np.isclose(mon.score_window(w).score, 0.5, atol=1e-12)
    assert np.isclose(mon.score_window(w).score, 1.0, atol=1e-12)
    assert np.isclose(mon.score_window(w).score, 1.5, atol=1e-12)


def test_fit_var1_recovers_coefficient_matrix():
    # Non-decaying rotation dynamics so the design matrix stays well-conditioned.
    rng = np.random.default_rng(1)
    theta = 0.4
    A = np.array(
        [[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]]
    )
    rows = 80
    x = rng.normal(size=(rows, 2))
    for t in range(1, rows):
        x[t] = x[t - 1] @ A  # proper autoregression x[t] = x[t-1] @ A
    fitted = M._fit_var1(x)
    assert np.allclose(fitted, A.T, atol=1e-4)


def test_var1_is_coefficient_drift_not_residual(monkeypatch):
    baseline = np.array([[1.0, 0.0], [0.0, 1.0]])
    mon = TransparentMonitor(
        name="var1",
        relation_set=_rset(),
        aggregation_k=1,
        baseline=np.zeros(2),
        scale=np.ones(2),
        calibration_scores=np.array([0.0]),
        short_state=np.zeros(2),
        long_state=np.zeros(2),
        cumulative_state=np.zeros(2),
        var_baseline=baseline,
    )
    # A known drifted coefficient matrix; row-norm drift = [2, 3].
    monkeypatch.setattr(
        M, "_fit_var1", lambda values: np.array([[3.0, 0.0], [0.0, 4.0]])
    )
    out = mon.score_window(np.zeros((40, 2)))
    # row norms of (drifted - baseline) = [sqrt((3-1)^2)=2, sqrt((4-1)^2)=3]; top1=3
    assert np.isclose(out.score, 3.0, atol=1e-12)


def test_sensor_identity_mapping():
    assert len(SENSOR_ORIGINAL_LABELS) == len(SENSOR_NAMES) == 14
    assert SENSOR_ORIGINAL_LABELS[0] == "s2"
    assert SENSOR_ORIGINAL_LABELS[9] == "s14"
    assert SENSOR_ORIGINAL_LABELS[8] == "s13"
    # the audit's example: compressed s9->s8 == original s14->s13
    rel = Relation(rank=1, source=9, target=8, lag=1, strength=0.5, sign=1, p_value=0.1)
    assert rel.key == "s9->s8@1"
    assert rel.display_key == "s14->s13@1"


def test_contributor_carries_original_and_legacy_keys(monkeypatch):
    mon = _monitor("ldsi", baseline=[0.5], scale=[1.0])
    _patch_relation_values(monkeypatch, [[0.9]])
    out = mon.score_window(np.zeros((40, len(SENSOR_NAMES))))
    contributor = out.contributors[0]
    assert contributor.key == "s2->s3@1"  # original (compressed 0->1 = s2->s3)
    assert contributor.legacy_key == "s0->s1@1"


def test_statistic_contract_json_is_loaded_and_consistent():
    path = Path(__file__).resolve().parents[1] / "configs" / "statistic_contract.json"
    contract = json.loads(path.read_text(encoding="utf-8"))
    ids = [m["id"] for m in contract["monitors"]]
    assert ids == list(M.MONITOR_NAMES)
    params = contract["parameters"]
    assert params["context_ridge_lambda"] == 0.001
    assert params["var_ridge_lambda"] == 0.001
    assert params["short_alpha"] == 0.4
    assert params["long_alpha"] == 0.1
    assert params["mewma_alpha"] == 0.2
    assert params["cusum_allowance"] == 0.5
    assert params["ldsi_denominator_epsilon"] == 0.05
    assert params["relation_scale_floor"] == 0.05
