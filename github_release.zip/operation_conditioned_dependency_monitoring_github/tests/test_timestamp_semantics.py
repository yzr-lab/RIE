import pytest

from rineng_replay.ledger import ScoreRecord


def _payload() -> dict:
    return {
        "subset": "FD002",
        "engine_id": 7,
        "condition_group": "multi",
        "fault_mode_group": "one",
        "calibration_end": 60,
        "window_start": 71,
        "window_end": 110,
        "score_time": 110,
        "monitor": "MEWMA",
        "conditioning": "quadratic",
        "selector_m": 20,
        "aggregation_k": 5,
        "score": 1.2,
        "threshold": 1.0,
        "alert": True,
        "persistent_alert": True,
        "episode_id": 1,
        "contributors_json": "[]",
    }


def test_score_time_must_equal_window_end() -> None:
    payload = _payload()
    payload["score_time"] = 90
    with pytest.raises(ValueError, match="window end"):
        ScoreRecord(**payload)


def test_monitoring_window_must_start_after_calibration() -> None:
    payload = _payload()
    payload["window_start"] = 60
    with pytest.raises(ValueError, match="after calibration"):
        ScoreRecord(**payload)

