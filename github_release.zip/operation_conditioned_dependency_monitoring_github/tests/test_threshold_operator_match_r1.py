"""R1: matched-operator threshold calibration vs legacy shared statistic."""

from __future__ import annotations

import numpy as np

from rineng_replay.data import ObservedTrajectory, SENSOR_NAMES
from rineng_replay.protocol import ReplayConfig
from rineng_replay.replay import score_trajectory
from rineng_replay.monitors import (
    _reference_feature_windows,
    _threshold_calibration_windows,
    calibration_scores_for_monitor,
    fit_monitor,
)
from rineng_replay.relations import fit_top_strength_relations, relation_strengths


def _calibration() -> np.ndarray:
    rng = np.random.default_rng(7)
    return rng.normal(size=(60, len(SENSOR_NAMES)))


def test_threshold_calibration_windows_definition():
    calibration = np.arange(60.0).reshape(60, 1)
    windows = _threshold_calibration_windows(calibration, window_size=40, step=10)
    assert len(windows) == 3
    assert all(w.shape == (40, 1) for w in windows)
    # windows end at 40, 50, 60 -> start indices 0, 10, 20
    assert [w[0, 0] for w in windows] == [0.0, 10.0, 20.0]
    assert [w[-1, 0] for w in windows] == [39.0, 49.0, 59.0]


def test_reference_feature_windows_unchanged_from_legacy():
    calibration = _calibration()
    windows = _reference_feature_windows(calibration)
    # legacy _calibration_windows for C=60: width=min(40,max(20,30))=30, step=max(5,7)=7
    assert [len(w) for w in windows] == [30] * 5


def test_calibration_scores_use_monitor_own_recursion():
    calibration = _calibration()
    rset = fit_top_strength_relations(calibration, max_lag=3, m=20)
    mon = fit_monitor("ldsi", calibration, rset, aggregation_k=5)
    matched = calibration_scores_for_monitor(
        mon, calibration, window_size=40, step=10
    )
    assert len(matched) == 3
    # legacy shared instantaneous statistic on the SAME threshold windows for comparison
    shared = []
    for window in _threshold_calibration_windows(calibration, 40, 10):
        component = np.abs(
            (relation_strengths(window, rset) - mon.baseline) / mon.scale
        )
        shared.append(float(np.mean(np.sort(component)[-5:])))
    shared = np.asarray(shared)
    assert not np.allclose(matched, shared)  # own recursion != shared statistic


def test_calibration_scores_do_not_pollute_online_state():
    calibration = _calibration()
    rset = fit_top_strength_relations(calibration, max_lag=3, m=20)
    mon = fit_monitor("ldsi", calibration, rset, aggregation_k=5)
    short_before = mon.short_state.copy()
    long_before = mon.long_state.copy()
    step_before = mon._step
    _ = calibration_scores_for_monitor(mon, calibration, window_size=40, step=10)
    assert np.array_equal(mon.short_state, short_before)
    assert np.array_equal(mon.long_state, long_before)
    assert mon._step == step_before


def _trajectory(n: int = 200) -> ObservedTrajectory:
    rng = np.random.default_rng(4101)
    o = rng.normal(size=(n, 3))
    x = rng.normal(size=(n, len(SENSOR_NAMES))) + o[:, :1]
    return ObservedTrajectory("FD002", 1, np.arange(1, n + 1), o, x, SENSOR_NAMES)


def _config() -> ReplayConfig:
    return ReplayConfig(
        calibration_cycles=60, window_size=40, step=10, persistence=3,
        max_lag=3, selector_m=20, aggregation_k=5, min_monitor_windows=5,
    )


def test_online_score_unchanged_across_threshold_branches():
    z = _trajectory()
    cfg = _config()
    legacy = score_trajectory(
        z, cfg, conditioning="linear", monitor_names=("ldsi", "mcusum"),
        threshold_branch="reference_deviation",
    )
    matched = score_trajectory(
        z, cfg, conditioning="linear", monitor_names=("ldsi", "mcusum"),
        threshold_branch="matched_operator",
    )
    for name in ("ldsi", "mcusum"):
        for a, b in zip(legacy.records[name], matched.records[name]):
            assert a.score == b.score
            assert a.threshold_branch == "reference_deviation"
            assert b.threshold_branch == "matched_operator"
            assert a.threshold != b.threshold  # matched calibration changes threshold
