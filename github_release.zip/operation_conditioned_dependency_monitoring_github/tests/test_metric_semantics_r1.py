"""R1: metric-semantics golden tests (all/pre-proxy episodes, leads, exposure)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from rineng_replay.evaluation import ranking_metrics, summarize_alert_workload


def _frame(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows)


def test_failure_lead_differs_from_pre_proxy_advance():
    # Engine 1: T=260, H=125 -> e=135; persistent alert from t=120.
    engine1 = [
        {"subset": "FD001", "engine_id": 1, "score_time": t, "alert": True,
         "persistent_alert": t >= 120, "episode_id": 1 if t >= 120 else None,
         "max_cycle": 260}
        for t in range(100, 261, 10)
    ]
    # Engine 2: T=200, no alert.
    engine2 = [
        {"subset": "FD001", "engine_id": 2, "score_time": t, "alert": False,
         "persistent_alert": False, "episode_id": None, "max_cycle": 200}
        for t in range(100, 201, 10)
    ]
    result = summarize_alert_workload(_frame(engine1 + engine2), horizon=125)

    assert result["fleet_engines"] == 2
    assert result["failure_lead_detected_mean"] == 140.0  # 260 - 120
    assert result["failure_lead_detected_n"] == 1
    assert result["failure_lead_fleet_zero_filled"] == 70.0  # (140 + 0)/2
    assert result["pre_proxy_advance_detected_mean"] == 15.0  # max(135-120,0)
    assert result["pre_proxy_advance_fleet_zero_filled"] == 7.5  # (15 + 0)/2
    # the two leads must never be conflated
    assert result["failure_lead_detected_mean"] != result["pre_proxy_advance_detected_mean"]


def test_undetected_engine_excluded_from_conditional_mean():
    engine1 = [
        {"subset": "FD001", "engine_id": 1, "score_time": t, "alert": True,
         "persistent_alert": t >= 120, "episode_id": 1 if t >= 120 else None,
         "max_cycle": 260}
        for t in range(100, 261, 10)
    ]
    engine2 = [
        {"subset": "FD001", "engine_id": 2, "score_time": t, "alert": False,
         "persistent_alert": False, "episode_id": None, "max_cycle": 200}
        for t in range(100, 201, 10)
    ]
    result = summarize_alert_workload(_frame(engine1 + engine2), horizon=125)
    # undetected engine contributes 0 to fleet, and is not in the detected mean
    assert result["failure_lead_detected_n"] == 1
    assert result["failure_lead_fleet_zero_filled"] == 70.0


def test_crossing_episode_counted_once_in_total():
    # T=260, e=135; one episode spans the proxy boundary (t=130 pre, t=140 event).
    rows = [
        {"subset": "FD001", "engine_id": 1, "score_time": 130, "alert": True,
         "persistent_alert": True, "episode_id": 1, "max_cycle": 260},
        {"subset": "FD001", "engine_id": 1, "score_time": 140, "alert": True,
         "persistent_alert": True, "episode_id": 1, "max_cycle": 260},
    ]
    result = summarize_alert_workload(_frame(rows), horizon=125)
    assert result["all_episode_count"] == 1  # crossing episode counted once
    assert result["pre_proxy_episode_count"] == 1  # has a pre-proxy window


def test_age_only_score_has_auc_one():
    # Within an engine the label flips chronologically; score=t ranks all positives
    # after all negatives, so ROC-AUC is exactly 1.
    rows = pd.DataFrame({
        "subset": ["FD001"] * 6,
        "engine_id": [1] * 6,
        "score_time": [100, 110, 120, 130, 140, 150],
        "max_cycle": [220] * 6,
        "score": [100, 110, 120, 130, 140, 150],
        "event_label": [False, False, False, True, True, True],
    })
    metrics = ranking_metrics(rows)
    assert metrics["engine_macro_auc"] == 1.0


def test_exposure_denominator_is_inclusive_cycle_range():
    # engine 1: T=260, first score 100 -> exposure 260-100+1 = 161
    # engine 2: T=200, first score 100 -> exposure 200-100+1 = 101
    engine1 = [
        {"subset": "FD001", "engine_id": 1, "score_time": t, "alert": False,
         "persistent_alert": False, "episode_id": None, "max_cycle": 260}
        for t in range(100, 261, 10)
    ]
    engine2 = [
        {"subset": "FD001", "engine_id": 2, "score_time": t, "alert": False,
         "persistent_alert": False, "episode_id": None, "max_cycle": 200}
        for t in range(100, 201, 10)
    ]
    result = summarize_alert_workload(_frame(engine1 + engine2), horizon=125)
    assert result["exposure_engine_cycles"] == 161 + 101
