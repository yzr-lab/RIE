from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_official_test_table_change_is_column_difference():
    paired = json.loads((ROOT / "logs" / "r1_paired_inference.json").read_text(encoding="utf-8"))
    macros = (ROOT / "generated_metrics.tex").read_text(encoding="utf-8")
    for monitor, prefix in {
        "ldsi": "LDSI",
        "dynamic_corr": "DynamicCorr",
        "mewma": "MEWMA",
        "mcusum": "MCUSUM",
        "var1": "VAROne",
    }.items():
        expected = paired["test"][monitor]["paired_delta_auc"]["estimate"]
        assert f"\\newcommand{{\\TestDelta{prefix}AUC}}{{{expected:.3f}}}" in macros


def test_operational_sensitivity_reports_primary_cohort_and_exposure():
    payload = json.loads((ROOT / "logs" / "r1_operational_sensitivity.json").read_text(encoding="utf-8"))
    row = payload["configs"]["C60"]["monitors"]["ldsi"]["linear"]
    assert row["fleet_engines"] == 696
    assert row["engine_macro_denominator"] == 279
    assert row["exposure_engine_cycles"] == 89725.0
    assert abs(row["all_episode_rate_per_1000_engine_cycles"] - 2.52995) < 1e-5


def test_synthetic_audit_contains_both_threshold_branches_and_health_retention():
    payload = json.loads((ROOT / "logs" / "r1_synthetic.json").read_text(encoding="utf-8"))
    assert {row["threshold_branch"] for row in payload["S4"]} == {
        "reference_deviation",
        "matched_operator",
    }
    assert "S4u" in payload
    retention = payload["health_retention"]["summary"]["S4"]
    assert retention["n"] == 100
    assert "retention_mean_of_ratios" in retention
    assert "retention_ratio_of_means" in retention


def test_rq1_interval_is_for_multi_minus_single_gain():
    payload = json.loads((ROOT / "logs" / "r1_rq1_inference.json").read_text(encoding="utf-8"))
    row = payload["ldsi"]
    assert row["statistic"] == "multi_minus_single_conditioning_gain"
    assert row["n_bootstrap"] == 5000
    assert row["ci_low"] <= row["estimate"] <= row["ci_high"]


def test_relation_stability_contains_cross_engine_summary():
    payload = json.loads((ROOT / "logs" / "r1_relation_stability.json").read_text(encoding="utf-8"))
    assert payload["linear"]["monitorable_engines"] == 696
    assert payload["linear"]["engine_presence_summary"]["n_relations"] > 0


def test_selector_sensitivity_has_comparable_reference_and_random_denominators():
    payload = json.loads((ROOT / "logs" / "r1_design_sensitivity.json").read_text(encoding="utf-8"))
    reference = payload["top_strength_reference"]
    assert payload["sample_engines"] == 80
    assert reference["raw"]["sampled_engines"] == 80
    assert reference["linear"]["monitorable_engines"] == 80
    assert reference["raw"]["auc_valid_n"] == 38
    for seed in range(5):
        row = payload["variants"][f"selector_seed_{seed}"]
        assert row["raw"]["sampled_engines"] == 80
        assert row["linear"]["auc_valid_n"] == 38


def test_frozen_candidate_overlap_is_separate_from_dynamic_stability():
    payload = json.loads((ROOT / "logs" / "r1_frozen_candidate_stability.json").read_text(encoding="utf-8"))
    assert payload["monitorable_engines"] == 696
    assert payload["definition"].startswith("Pairwise Jaccard overlap of calibration-fixed")
    assert payload["by_conditioning"]["raw"]["ALL"]["pairwise_jaccard_median"] == 0.0
