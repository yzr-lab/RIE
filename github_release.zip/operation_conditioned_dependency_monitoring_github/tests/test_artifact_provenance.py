import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_artifact_manifest_tracks_the_locked_metric_ledger() -> None:
    metric_path = ROOT / "logs" / "main_metrics.json"
    manifest_path = ROOT / "figures" / "artifact_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest["metric_ledger_sha256"] == _sha256(metric_path)
    assert len(manifest["artifacts"]) >= 15
    for item in manifest["artifacts"]:
        path = ROOT / item["path"]
        assert path.is_file()
        assert item["sha256"] == _sha256(path)


def test_generators_do_not_read_the_legacy_submission() -> None:
    for name in ("generate_tables.py", "generate_figures.py"):
        text = (ROOT / "scripts" / name).read_text(encoding="utf-8")
        assert "RESS_submission_v2" not in text
        assert "legacy" not in text.lower()
        assert "logs/main_metrics.json" in text.replace("\\", "/")

