# Operation-conditioned dependency monitoring

Compact GitHub distribution for Operation-Conditioned Dependency Monitoring
for Turbofan Degradation: Transparent Evidence and Lead--Workload Trade-offs.

This archive contains the key replay code, frozen protocol definitions, derived
metric ledgers, revision audit results, tables, figures, and integrity tests.

## Contents

- src/rineng_replay/: conditioning, relation extraction, monitors, scoring,
  evaluation, and ledger verification;
- configs/: protocol and statistic contracts;
- scripts/: primary replay and revision-audit entry points;
- logs/: key derived metrics and audit records;
- tables/ and figures/: editable result tables and vector figures;
- tests/: focused integrity and metric-semantics tests.

NASA C-MAPSS raw files, full JSONL score ledgers, large sensitivity caches,
manuscript sources, response files, and submission metadata are intentionally
excluded. C-MAPSS must be obtained from the NASA Open Data Portal under its
original terms. The included result files are derived records and do not
redistribute the source data.

## Local checks

~~~powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest tests -q
~~~

The complete replay requires the NASA files and the full locked score ledgers;
this compact distribution is for transparent inspection of the implementation
and key results, not a replacement for the complete internal replay archive.

## License

Source code is MIT licensed. Documentation, figures, tables, and derived
results are released under CC BY 4.0. Third-party source data remain under
their original terms.
