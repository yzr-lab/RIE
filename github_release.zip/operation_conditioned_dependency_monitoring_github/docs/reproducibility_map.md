# Reproducibility map

## Identities

- Protocol SHA-256: `88feba120419fbe126297583057d496fdf78d4b4c698b350ef6735c767df6a05`
- Metrics-ledger SHA-256: `e65496335bcb1da927c45b17dfe9d501435b47e00a1c8873c73e033f60be2ef7`
- Pristine v1 metrics-ledger SHA-256 retained for provenance: `c42c2091f63c0acf8490d6c8ee2e59f30a3332b61ebcda3288e26d58af780d07`

## Evidence flow

| Stage | Input | Command | Output |
|---|---|---|---|
| Source identity audit | C-MAPSS train/test/RUL files | `python -m pytest tests/test_source_audit.py -q` | validated counts and source hashes |
| Protocol selection (full regeneration) | C-MAPSS train files | `python scripts/select_label_free_protocol.py` | fixed protocol and hash |
| Primary scoring | Sensors/settings only | `python scripts/run_primary_replay.py --validate-only` | validated immutable score manifest |
| Evaluation | Locked scores plus evaluator labels | `python scripts/build_metric_ledger.py` | main metric ledger and per-engine metrics |
| Sensitivities (full regeneration) | Locked or branch-specific scores | `python scripts/run_sensitivity_audits.py` | context, M/K, step, horizon, length, and 2x2 audits |
| Official test (full regeneration) | Observed test sequences | `python scripts/run_censored_test_replay.py` | censored score and metric manifests |
| LaTeX metrics | Main metric ledger | `python scripts/generate_latex_macros.py` | `generated_metrics.tex` |
| Tables | Main metric ledger | `python scripts/generate_tables.py` | editable booktabs tables |
| R1 audit tables | Sensitivity, stability, and mechanism ledgers | `python scripts/generate_r1_tables.py` | editable revision tables |
| Figures | Locked metrics and audit logs | `python scripts/generate_figures.py` | PDF/SVG/600 dpi PNG figures |
| Validation | All artifacts | `python -m pytest tests -q` | contract report |
| PDF and release build | LaTeX and verified artifacts | `powershell -ExecutionPolicy Bypass -File .\build.ps1` | manuscript PDFs, validation report, and deterministic GitHub ZIP |

## Principal claim mapping

| Claim | Primary log | Display artifact |
|---|---|---|
| Condition-specific gain | `logs/audits/context_model_sensitivity.csv` | Figure 3 |
| Cross-monitor raw/conditioned effect | `logs/main_metrics.json` | Table 2 |
| Lead-workload frontier | `logs/main_metrics.json` threshold frontier | Figure 4 |
| Paired P(delta>0), V20/V40/V60 | `logs/evaluation/paired_advance_ecdf.csv` | Table 3, Figure 4 |
| M/K roles | `logs/audits/selector_m_k_sensitivity.csv` | Supplementary Table S5 |
| Fault-count interaction audit | `logs/audits/fd_2x2_interaction.json` | Figure 3, Supplement S4 |
| Censored test direction | `logs/evaluations/test_censored_metrics.json` | Supplement S9 |

The detailed sentence-level mapping is in `docs/claim_evidence_map.md`.

## Rebuild invariant

The ordinary build regenerates only derived manuscript assets; it does not rerun primary, sensitivity, or censored scoring. Regenerating manuscript assets must not change score-ledger bytes, protocol identity, or source manifests. Any changed ledger hash invalidates the displayed result macros and blocks release. Full-regeneration rows above are provided for independent reproduction after the NASA files have been acquired.
