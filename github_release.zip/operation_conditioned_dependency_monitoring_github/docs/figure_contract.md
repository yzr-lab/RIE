# Publication Figure Contract

Backend: Python only. All quantitative and schematic artwork is deterministic; no generative artwork is used.

## Figure 1

- Core conclusion: Fixed calibration, operating-context correction, transparent dependency monitors, and workload-aware review form one auditable engineering pipeline.
- Archetype: schematic-led composite.
- Final size: 183 mm by approximately 96 mm.
- Panel map: mixed-regime streams; frozen calibration and conditioning; five transparent monitors; ranking evidence and governed review.
- Reviewer risk: the schematic must not imply autonomous maintenance action or causal graph recovery.

## Figure 2

- Core conclusion: Scores use completed windows and are locked before any endpoint or RUL information enters evaluation.
- Archetype: asymmetric information timeline.
- Final size: 183 mm by approximately 82 mm.
- Panel map: training replay; censored test replay; information boundary.
- Reviewer risk: score timestamps must appear at window ends, never window centers.

## Figure 3

- Core conclusion: Operating-context correction improves ranking primarily in multi-condition subsets, with consistent gains across one- and two-fault structures.
- Archetype: quantitative grid with a dominant condition-effect panel.
- Final size: 183 mm by approximately 142 mm.
- Panel map: multi-minus-single gain; four-FD paired effects; residual preservation and support; model-form robustness.
- Statistics: engine-macro AUC, fixed-FD bootstrap for 2x2 interaction, 696 train engines with 279 ranking-eligible engines at the primary horizon.
- Reviewer risk: distinguish the positive multi-versus-single contrast from the near-zero condition-by-fault difference-in-differences.

## Figure 4

- Core conclusion: Earlier advisory evidence is obtained along monitor-specific lead-workload frontiers rather than as a uniformly low-burden action trigger.
- Archetype: asymmetric quantitative grid.
- Final size: 183 mm by approximately 135 mm.
- Panel map: LDSI threshold frontier; locked operating points across monitors; paired-advance probabilities; paired-advance ECDF.
- Statistics: fleet lead assigns zero to late or undetected engines; episodes are pre-event persistent-alert episodes; paired advance uses engines detected by both representations.
- Reviewer risk: keep fleet, conditional, and paired denominators visually distinct.

## Figure 5, Optional

- Core conclusion: A representative multi-condition engine shows how a conditioned relation-level advisory can precede the raw advisory without increasing pre-event review episodes.
- Archetype: operator review card.
- Selection rule: defined separately before engine identity is inspected.
- Reviewer risk: the case is a review cue, not fault localization or physical attribution.

## Export Contract

- PDF and SVG with editable text and embedded TrueType fonts.
- PNG at 600 dpi for visual QA and submission fallback.
- Arial/Helvetica-compatible sans serif, 7-9 pt final text, white background.
- Colorblind-safe blue/teal/orange/grey semantic palette; line style and marker shape duplicate color encoding.
- Every artifact is registered against the SHA-256 of `logs/main_metrics.json`.

