# Scientific integrity report

## Locked study identity

- Protocol SHA-256: `88feba120419fbe126297583057d496fdf78d4b4c698b350ef6735c767df6a05`
- Metrics-ledger SHA-256: `e65496335bcb1da927c45b17dfe9d501435b47e00a1c8873c73e033f60be2ef7`
- Pristine v1 metrics-ledger SHA-256 retained for provenance: `c42c2091f63c0acf8490d6c8ee2e59f30a3332b61ebcda3288e26d58af780d07`
- Primary data: locally archived NASA C-MAPSS train files
- Training engines observed: 709
- Monitorable under the fixed protocol: 696
- Locked primary score rows: 92,860

## Research-integrity checks

| Check | Status | Evidence |
|---|---|---|
| NASA source files identified | Pass | `docs/source_manifest.json` and source-audit tests |
| Public archive excludes raw source data | Pass | GitHub release-content tests and archive scan |
| Fixed calibration length | Pass | `configs/primary_protocol.yaml`, protocol tests |
| Fixed monitoring window and step | Pass | protocol and score-contract tests |
| Score timestamp equals window end | Pass | timestamp tests and full-ledger validation |
| Scoring does not load RUL/event labels | Pass | data-access and evaluation-separation tests |
| Eligibility is outcome independent | Pass | monitorability and protocol tests |
| Relation selector is calibration fixed | Pass | relation-selection tests |
| M and K are distinct and audited | Pass | selector sensitivity log and tests |
| P(delta>0) differs from V20 | Pass | metric-definition tests and 10-cycle step |
| Main and supplement use one ledger | Pass | generated macros and manuscript consistency tests |
| Figures and tables derive from locked logs | Pass | artifact manifests and provenance tests |

## Claims supported by the locked replay

1. Linear operation conditioning improves engine-macro AUC across the five transparent monitor constructions in the 696-engine training replay.
2. The larger gains occur in FD002/FD004 compared with FD001/FD003; the 2x2 audit does not support a common fault-count interaction.
3. Ranking, coverage, lead, and review burden select different monitor roles.
4. LDSI provides a calibration-fixed, sparse relation-instability decomposition at comparatively low primary-threshold workload.
5. Official-test censored replay reproduces the positive LDSI and MEWMA ranking directions, but not every monitor direction.

## Claims intentionally excluded

- Structural direction or physical component diagnosis from lagged relation cues
- Distribution-free false-alert control
- Autonomous maintenance authorization
- Plant-specific monetary benefit
- Prospective field performance
- Universal superiority over all learned anomaly detectors

## Known boundaries

C-MAPSS is simulated, the RUL 125 event region is an evaluation proxy, official test trajectories are censored, and relation cues lack teardown or work-order labels. Cross-asset datasets are treated as scope audits rather than pooled positive validation. These limitations are stated once in the main Discussion and documented in the Supplementary Material.

## Unsupported-claim list

No unsupported quantitative main-text claim was identified after binding numerical statements to `logs/main_metrics.json`. The optional Figure 5 case is selected by a predeclared rule and is described as an auditability example rather than a best-performing case.
