# Claim-Evidence Map

Locked metric ledger SHA-256: `e65496335bcb1da927c45b17dfe9d501435b47e00a1c8873c73e033f60be2ef7`.

| Claim | Evidence | Artifact | Boundary |
|---|---|---|---|
| The workflow separates fixed calibration, transparent monitoring, and governed review | Frozen three-stage engineering architecture | Figure 1 | The review lane does not imply autonomous action |
| Scoring is trajectory-length-independent and endpoint-isolated | Fixed C/W/s protocol, window-end timestamps, verified score ledgers | Figure 2; Table 1 | Endpoint labels enter evaluation only |
| Operating-context correction primarily benefits multi-condition monitoring | Positive multi-minus-single paired AUC gain across five monitors | Figure 3a-b; Table 2 | The condition-by-fault difference-in-differences is near zero and uncertainty intervals cross zero |
| Residualization removes operating association without erasing single-condition variance | Per-FD association, energy, variance, and support audits | Figure 3c; Table 1 | Multi-condition residual energy is intentionally lower and is reported |
| Ranking improvements coexist with monitor-specific review burden | Threshold frontiers, proxy advance, episodes, coverage, and paired advance | Figure 4; Table 3 | The advisory is not a low-false-alert action policy |
| Independent truncated trajectories provide a separate audit | 363/707 official test engines monitorable; locked test score namespace | Results text and supplement | This is a censored audit, not complete run-to-failure validation |
| Relation contributions can organize operator review | Prespecified median representative multi-condition case | Figure 5 | Review cues are not fault localization or physical attribution |
