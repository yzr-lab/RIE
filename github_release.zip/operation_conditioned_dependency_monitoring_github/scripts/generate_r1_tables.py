"""Generate compact supplementary tables from revision audit ledgers."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "tables"


def f(value, digits=3):
    if value is None:
        return "--"
    return f"{float(value):.{digits}f}"


def signed(value, digits=3):
    if value is None:
        return "--"
    return f"{float(value):+.{digits}f}"


def row(*cells):
    return " & ".join(str(cell) for cell in cells) + r" \\"


def write(name, text):
    (TABLES / name).write_text(text.strip() + "\n", encoding="utf-8")


def main():
    rq1 = json.loads((ROOT / "logs" / "r1_rq1_inference.json").read_text(encoding="utf-8"))
    order = [("ldsi", "LDSI"), ("dynamic_corr", "Dynamic correlation"), ("mewma", "Relation-EWMA"), ("mcusum", "Absolute-deviation CUSUM"), ("var1", "VAR-coefficient drift")]
    rows = []
    for key, label in order:
        r = rq1[key]
        rows.append(row(label, signed(r["single_condition_mean_delta_auc"]), signed(r["multi_condition_mean_delta_auc"]), f"{signed(r['estimate'])} [{signed(r['ci_low'])},{signed(r['ci_high'])}]"))
    write("table_s_rq1_gain.tex", r"""
\begin{table}[pos=h]
\centering
\caption{FD-stratified bootstrap intervals for the multi-minus-single conditioning gain. The statistic is the mean conditioning $\Delta$AUC in FD002/FD004 minus the corresponding mean in FD001/FD003; it is not the $2\times2$ interaction.}
\label{tab:s-rq1-gain}
\begin{tabular}{@{}lrrr@{}}
\toprule
Monitor & Single $\Delta$AUC & Multi $\Delta$AUC & Multi$-$single [95\% interval] \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")

    design = json.loads((ROOT / "logs" / "r1_design_sensitivity.json").read_text(encoding="utf-8"))
    rows = []
    reference = design["top_strength_reference"]
    ref_raw = reference["raw"]
    ref_linear = reference["linear"]
    rows.append(
        row(
            "top-strength reference",
            design["sample_engines"],
            ref_raw["monitorable_engines"],
            ref_raw["auc_valid_n"],
            f(ref_raw["engine_macro_auc"]),
            f(ref_linear["engine_macro_auc"]),
            signed(ref_linear["engine_macro_auc"] - ref_raw["engine_macro_auc"]),
        )
    )
    for seed in range(5):
        r = design["variants"][f"selector_seed_{seed}"]
        rows.append(
            row(
                f"random seed {seed}",
                design["sample_engines"],
                r["raw"]["monitorable_engines"],
                r["raw"]["auc_valid_n"],
                f(r["raw"]["engine_macro_auc"]),
                f(r["linear"]["engine_macro_auc"]),
                signed(r["linear"]["engine_macro_auc"] - r["raw"]["engine_macro_auc"]),
            )
        )
    write("table_s_selector_sensitivity.tex", r"""
\begin{table}[pos=h]
\centering
\caption{Label-free relation-selector sensitivity on the same 80-engine sample. The top-strength row is the primary selector evaluated on this sample; random rows use fixed stratified-random seeds. Sampled and monitorable counts are both 80; AUC-valid $n$ is smaller when a trajectory lacks both evaluation classes.}
\label{tab:s-selector}
\begin{tabular}{@{}lrrrrrr@{}}
\toprule
Selector & Sampled $n$ & Monitorable $n$ & AUC-valid $n$ & Raw AUC & Conditioned AUC & $\Delta$AUC \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")

    operational = json.loads((ROOT / "logs" / "r1_operational_sensitivity.json").read_text(encoding="utf-8"))
    order_tags = ["C50", "C60", "C80", "C90", "W30", "W40", "W50", "s5", "s10", "s20", "p2", "p3", "p4"]
    rows_rank, rows_work = [], []
    for tag in order_tags:
        block = operational["configs"][tag]["monitors"]["ldsi"]
        raw, cond = block["raw"], block["linear"]
        label = f"{tag} (primary)" if tag in {"C60", "W40", "s10", "p3"} else tag
        rows_rank.append(row(label, cond["monitorable_n"], cond["auc_n"], f(raw["engine_macro_auc"]), f(cond["engine_macro_auc"]), signed(cond["engine_macro_auc"] - raw["engine_macro_auc"])))
        rows_work.append(row(label, f(cond["persistent_window_rate_pre_proxy"]), f(cond["pre_proxy_episode_rate_per_engine"]), f(cond["all_episode_rate_per_engine"]), f(cond["event_region_coverage"]), f(cond["pre_proxy_advance_fleet_zero_filled"], 1), int(cond["exposure_engine_cycles"])))
    write("table_s_temporal_ranking.tex", r"""
\begin{table}[pos=h]
\centering
\caption{Temporal and persistence sensitivity of LDSI ranking under the primary reference-deviation threshold. The AUC denominator is the number of engines with both evaluation classes.}
\label{tab:s-temporal-ranking}
\begin{tabular}{@{}lrrrrr@{}}
\toprule
Variant & Monitorable $n$ & AUC $n$ & Raw AUC & Conditioned AUC & $\Delta$AUC \\
\midrule
""" + "\n".join(rows_rank) + r"""
\bottomrule
\end{tabular}
\end{table}
""")
    write("table_s_temporal_workload.tex", r"""
\begin{table}[pos=h]
\centering
\caption{Operational sensitivity of LDSI. FPR and pre-proxy episodes are restricted to the pre-proxy region; complete episodes include the full observed trajectory. Advance is the zero-filled fleet mean.}
\label{tab:s-temporal-workload}
\resizebox{\textwidth}{!}{%
\begin{tabular}{@{}lrrrrrr@{}}
\toprule
Variant & Pre-FPR & Pre-episodes/eng. & Complete episodes/eng. & Coverage & Proxy advance & Exposure cycles \\
\midrule
""" + "\n".join(rows_work) + r"""
\bottomrule
\end{tabular}%
}
\end{table}
""")

    rows = []
    for tag in ("H100", "H125", "H150"):
        block = operational["configs"][tag]["monitors"]["ldsi"]
        cond = block["linear"]
        rows.append(row(tag[1:], cond["monitorable_n"], cond["auc_n"], f(cond["persistent_window_rate_pre_proxy"]), f(cond["pre_proxy_episode_rate_per_engine"]), f(cond["event_region_coverage"]), f(cond["pre_proxy_advance_fleet_zero_filled"], 1)))
    write("table_s_horizon_workload.tex", r"""
\begin{table}[pos=h]
\centering
\caption{Event-horizon sensitivity of LDSI using the same locked score records. Changing the evaluation horizon changes labels and operational denominators, not the score.}
\label{tab:s-horizon-workload}
\begin{tabular}{@{}lrrrrrr@{}}
\toprule
Horizon & Monitorable $n$ & AUC $n$ & Pre-FPR & Pre-episodes/eng. & Coverage & Proxy advance \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")

    synth = json.loads((ROOT / "logs" / "r1_synthetic.json").read_text(encoding="utf-8"))
    rows = []
    for mech in ("S0", "S1", "S2", "S3", "S4", "S4u", "S5a", "S5b"):
        for branch in ("reference_deviation", "matched_operator"):
            block = synth["summaries"][mech][branch]["ldsi"]
            raw, cond = block["raw"], block["linear"]
            rows.append(row(
                mech,
                branch.replace("_", " "),
                f"{f(raw['post_anchor_alert_incidence'])} / {f(cond['post_anchor_alert_incidence'])}",
                f"{f(raw['post_new_episode_rate'])} / {f(cond['post_new_episode_rate'])}",
                f"{f(raw['post_continuation_rate'])} / {f(cond['post_continuation_rate'])}",
                f"{f(raw['post_new_episode_delay_median'], 1)} / {f(cond['post_new_episode_delay_median'], 1)}",
            ))
    health = synth["health_retention"]["summary"]
    health_s4 = health["S4"]
    health_s4u = health["S4u"]
    write("table_s_synthetic_audit.tex", r"""
\begin{table}[pos=h]
\centering
\caption{Controlled mechanism audit for LDSI. Entries are raw/conditioned values over 100 seeds. Post-anchor alert incidence counts any persistent alert after the reference cycle and is not a correct-degradation rate for S0 or S1. New post-episode rate excludes episodes that began before the reference cycle; continuation is the complementary pre-existing episode stream. New-episode delay is conditional on a new episode; ``--'' denotes no qualifying episode.}
\label{tab:s-synthetic}
\scriptsize
\begin{tabular}{@{}llrrrr@{}}
\toprule
Mechanism & Branch & Post-anchor alert & New episode & Continuation & New delay \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
\smallskip
\noindent S4 confounded-health retention: mean raw slope """ + f(health_s4["raw_slope"], 3) + ", conditioned slope """ + f(health_s4["linear_slope"], 3) + "; mean of per-seed slope ratios """ + f(health_s4["retention_mean_of_ratios"], 3) + " [" + f(health_s4["retention_ratio_q025"], 3) + ", " + f(health_s4["retention_ratio_q975"], 3) + "] and ratio of mean slopes " + f(health_s4["retention_ratio_of_means"], 3) + ", with raw/conditioned post-change correlation " + f(health_s4["raw_corr"], 3) + "/" + f(health_s4["linear_corr"], 3) + ". S4u unconfounded-health control: mean-of-ratios " + f(health_s4u["retention_mean_of_ratios"], 3) + " [" + f(health_s4u["retention_ratio_q025"], 3) + ", " + f(health_s4u["retention_ratio_q975"], 3) + "] and ratio of means " + f(health_s4u["retention_ratio_of_means"], 3) + ".\n""")

    stability = json.loads((ROOT / "logs" / "r1_relation_stability.json").read_text(encoding="utf-8"))
    frozen_path = ROOT / "logs" / "r1_frozen_candidate_stability.json"
    frozen = json.loads(frozen_path.read_text(encoding="utf-8")) if frozen_path.exists() else None
    rows = []
    for cond, label in (("raw", "Raw"), ("linear", "Conditioned")):
        r = stability[cond]
        s = r["engine_presence_summary"]
        rows.append(row(label, r["monitorable_engines"], s["n_relations"], f(r["adjacent_window_jaccard_mean"]), f(r["adjacent_window_jaccard_median"]), f(s["max_engine_presence_fraction"]), f"{r['fdr_zero_records']}/{r['support_records']}"))
    frozen_block = ""
    if frozen is not None:
        frozen_rows = []
        for cond, label in (("raw", "Raw"), ("linear", "Conditioned")):
            for fd in ("FD001", "FD002", "FD003", "FD004", "ALL"):
                item = frozen["by_conditioning"][cond][fd]
                frozen_rows.append(
                    row(
                        label,
                        fd,
                        item["engines"],
                        f(item["pairwise_jaccard_mean"]),
                        f(item["pairwise_jaccard_median"]),
                    )
                )
        frozen_block = r"""
\par\smallskip
\textbf{Frozen calibration top-$M$ candidate overlap}
\par\smallskip
\begin{tabular}{@{}llrrr@{}}
\toprule
Representation & FD & Engines & Pairwise Jaccard mean & Median \\
\midrule
""" + "\n".join(frozen_rows) + r"""
\bottomrule
\end{tabular}
"""
    write("table_s_relation_stability.tex", r"""
\begin{table}[pos=h]
\centering
\caption{Cross-engine and within-engine stability of the LDSI evidence interface. Adjacent-window Jaccard and engine presence use dynamic scored top-$K$ contributors. The frozen calibration top-$M$ candidate overlap is reported separately below; the two quantities are not interchangeable. The final column reports support records with zero BH-retained relations.}
\label{tab:s-relation-stability}
\begin{tabular}{@{}lrrrrrr@{}}
\toprule
Representation & Engines & Relations & Adjacent Jaccard mean & Median & Max engine presence & Zero-BH records \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
""" + frozen_block + r"""
\end{table}
""")
    print("Generated revision supplementary tables.")


if __name__ == "__main__":
    main()
