"""Audit the feasibility grid and freeze a label-free primary replay config."""

from __future__ import annotations

import hashlib
import itertools
import json
import sys
from dataclasses import asdict
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.data import load_cmapss_observed  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402
from rineng_replay.protocol import ReplayConfig, select_primary_config  # noqa: E402


DATA_ROOT = resolve_cmapss_root(ROOT)
GRID_PATH = ROOT / "configs" / "feasibility_grid.yaml"
PRIMARY_PATH = ROOT / "configs" / "primary_protocol.yaml"
HASH_PATH = ROOT / "configs" / "protocol_hash.json"
AUDIT_PATH = ROOT / "logs" / "audits" / "protocol_feasibility.json"


def canonical_yaml(payload: dict) -> str:
    return yaml.safe_dump(payload, sort_keys=True, allow_unicode=False)


def grid_configs(grid: dict) -> list[ReplayConfig]:
    keys = (
        "calibration_cycles",
        "window_size",
        "step",
        "persistence",
        "max_lag",
        "selector_m",
        "aggregation_k",
    )
    configs = []
    for values in itertools.product(*(grid[key] for key in keys)):
        payload = dict(zip(keys, values))
        payload["min_monitor_windows"] = int(grid["min_monitor_windows"])
        configs.append(ReplayConfig(**payload))
    return configs


def main() -> None:
    grid = yaml.safe_load(GRID_PATH.read_text(encoding="utf-8"))
    lengths: list[int] = []
    by_subset: dict[str, list[int]] = {}
    for subset in ("FD001", "FD002", "FD003", "FD004"):
        records = load_cmapss_observed(DATA_ROOT, subset, "train", engine_ids=None)
        subset_lengths = [len(record.cycles) for record in records]
        by_subset[subset] = subset_lengths
        lengths.extend(subset_lengths)
    selected, audit = select_primary_config(lengths, grid_configs(grid))
    payload = asdict(selected)
    payload["score_timestamp"] = "window_end"
    payload["normalization_source"] = "cycles_1_to_C"
    payload["context_source"] = "cycles_1_to_C"
    payload["relation_source"] = "cycles_1_to_C"
    payload["primary_conditioning"] = "linear"
    payload["conditioning_selection_rule"] = (
        "predeclared lowest-complexity operating-context model; "
        "quadratic and regime branches are robustness audits"
    )
    payload["evaluation_fields_visible_to_scoring"] = False
    text = canonical_yaml(payload)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    PRIMARY_PATH.write_text(text, encoding="utf-8")
    HASH_PATH.write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "protocol_sha256": digest,
                "canonical_file": PRIMARY_PATH.name,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
    audit["train_lengths_by_subset"] = {
        subset: {
            "n": len(values),
            "min": min(values),
            "max": max(values),
        }
        for subset, values in by_subset.items()
    }
    audit["protocol_sha256"] = digest
    AUDIT_PATH.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(f"Selected protocol: {payload}")
    print(f"Protocol SHA-256: {digest}")
    print(
        "Monitorable train engines: "
        f"{audit['selected']['monitorable_engines']}/{audit['selected']['total_engines']}"
    )


if __name__ == "__main__":
    main()
