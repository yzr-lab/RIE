"""Operational sensitivity for LDSI under the primary reference threshold.

The output keeps ranking and workload denominators together. C/W/step variants
are rescored from the observed prefix; persistence and horizon variants reuse
the verified primary score records because neither changes the score itself.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, replace
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.data import load_cmapss_observed  # noqa: E402
from rineng_replay.evaluation import apply_threshold_multiplier, ranking_metrics, summarize_alert_workload  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402
from rineng_replay.protocol import ReplayConfig, window_count  # noqa: E402
from rineng_replay.replay import score_trajectory  # noqa: E402

DATA_ROOT = resolve_cmapss_root(ROOT)
SCORE_DIR = ROOT / "logs" / "scores" / "primary"
OUT = ROOT / "logs" / "r1_operational_sensitivity.json"
HORIZON = 125


def base_config() -> ReplayConfig:
    return ReplayConfig(
        calibration_cycles=60, window_size=40, step=10, persistence=3,
        max_lag=3, selector_m=20, aggregation_k=5, min_monitor_windows=5,
    )


def load_trajectories(limit_per_fd: int | None = None) -> list:
    out = []
    for subset in ("FD001", "FD002", "FD003", "FD004"):
        rows = load_cmapss_observed(DATA_ROOT, subset, "train", None)
        if limit_per_fd is not None:
            rows = rows[:limit_per_fd]
        out.extend(rows)
    return out


def _with_endpoints(frame: pd.DataFrame, horizon: int) -> pd.DataFrame:
    rows = frame.copy()
    rows["rul"] = rows["max_cycle"] - rows["score_time"]
    rows["event_label"] = rows["rul"] <= horizon
    return rows


def summarize(frame: pd.DataFrame, horizon: int) -> dict:
    rows = _with_endpoints(frame, horizon)
    summary = {**ranking_metrics(rows), **summarize_alert_workload(rows, horizon=horizon)}
    summary["monitorable_n"] = int(rows[["subset", "engine_id"]].drop_duplicates().shape[0])
    summary["auc_n"] = int(summary["engine_macro_denominator"])
    summary["horizon"] = int(horizon)
    return summary


def _score_variants(trajectories: list, config: ReplayConfig) -> pd.DataFrame:
    rows: list[dict] = []
    for index, trajectory in enumerate(trajectories, start=1):
        if index % 50 == 0:
            print(f"  scored {index}/{len(trajectories)}", flush=True)
        # The same frozen observed trajectory is transformed separately for
        # each representation; this keeps the cohort decision explicit.
        for conditioning in ("raw", "linear"):
            result = score_trajectory(
                trajectory,
                config,
                conditioning=conditioning,
                monitor_names=("ldsi",),
                threshold_branch="reference_deviation",
            )
            for record in result.records["ldsi"]:
                row = asdict(record)
                row["max_cycle"] = int(trajectory.cycles[-1])
                row["monitorable"] = bool(result.audit.monitorable)
                rows.append(row)
    frame = pd.DataFrame(rows)
    return frame[frame["monitorable"]].drop(columns=["monitorable"]).reset_index(drop=True)


def _load_primary() -> pd.DataFrame:
    frames = []
    for conditioning in ("raw", "linear"):
        for subset in ("FD001", "FD002", "FD003", "FD004"):
            path = SCORE_DIR / f"{subset}_{conditioning}_ldsi.jsonl"
            frame = pd.read_json(path, lines=True)
            frames.append(frame)
    rows = pd.concat(frames, ignore_index=True)
    endpoints = []
    for subset in ("FD001", "FD002", "FD003", "FD004"):
        observed = pd.read_csv(DATA_ROOT / f"train_{subset}.txt", sep=r"\s+", header=None, usecols=[0, 1], names=["engine_id", "cycle"])
        endpoint = observed.groupby("engine_id", as_index=False)["cycle"].max().rename(columns={"cycle": "max_cycle"})
        endpoint["subset"] = subset
        endpoints.append(endpoint)
    endpoint = pd.concat(endpoints, ignore_index=True)
    rows = rows.merge(endpoint, on=["subset", "engine_id"], how="left", validate="many_to_one")
    # The score ledger already records the primary cohort; use it rather than
    # redefining monitorability from a later evaluation endpoint.
    counts = rows.groupby(["subset", "engine_id", "conditioning"]).size().rename("n").reset_index()
    monitorable = counts[counts["n"] >= 5][["subset", "engine_id", "conditioning"]]
    rows = rows.merge(monitorable.assign(monitorable=True), on=["subset", "engine_id", "conditioning"], how="inner")
    return rows.drop(columns=["monitorable"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit-per-fd", type=int, default=None)
    args = parser.parse_args()
    base = base_config()
    trajectories = load_trajectories(args.limit_per_fd)
    payload: dict = {"horizon_reference": HORIZON, "configs": {}, "limit_per_fd": args.limit_per_fd}

    primary = _load_primary()
    primary = primary[primary["conditioning"].isin(["raw", "linear"])].copy()
    primary_by_horizon = {}
    for horizon in (100, 125, 150):
        primary_by_horizon[str(horizon)] = {
            cond: summarize(_with_endpoints(primary[primary["conditioning"] == cond], horizon), horizon)
            for cond in ("raw", "linear")
        }

    for tag, config in [
        ("C50", replace(base, calibration_cycles=50)),
        ("C60", base),
        ("C80", replace(base, calibration_cycles=80)),
        ("C90", replace(base, calibration_cycles=90)),
        ("W30", replace(base, window_size=30)),
        ("W40", base),
        ("W50", replace(base, window_size=50)),
        ("s5", replace(base, step=5)),
        ("s10", base),
        ("s20", replace(base, step=20)),
    ]:
        if tag in {"C60", "W40", "s10"} and args.limit_per_fd is None:
            frame = primary.copy()
            # The locked ledger is the authoritative primary reference.
            summary = {cond: summarize(frame[frame["conditioning"] == cond], HORIZON) for cond in ("raw", "linear")}
        else:
            print(f"Running {tag}: {asdict(config)}", flush=True)
            frame = _score_variants(trajectories, config)
            summary = {cond: summarize(frame[frame["conditioning"] == cond], HORIZON) for cond in ("raw", "linear")}
        payload["configs"][tag] = {"config": asdict(config), "inestimable": False, "monitors": {"ldsi": summary}}

    payload["configs"]["primary"] = payload["configs"]["C60"]

    for tag, persistence in (("p2", 2), ("p3", 3), ("p4", 4)):
        rows = apply_threshold_multiplier(primary, multiplier=1.0, persistence=persistence)
        payload["configs"][tag] = {
            "config": asdict(replace(base, persistence=persistence)),
            "inestimable": False,
            "monitors": {"ldsi": {cond: summarize(rows[rows["conditioning"] == cond], HORIZON) for cond in ("raw", "linear")}},
        }
    for horizon in (100, 125, 150):
        payload["configs"][f"H{horizon}"] = {
            "config": asdict(base),
            "inestimable": False,
            "monitors": {"ldsi": primary_by_horizon[str(horizon)]},
        }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
