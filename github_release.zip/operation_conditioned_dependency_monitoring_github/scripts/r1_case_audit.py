"""R1 E6: prespecified case selection (success/neutral/adverse) and contributor
stability for FD002/FD004. Selection rules are fixed before inspection."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.evaluation import join_training_endpoints  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402

DATA_ROOT = resolve_cmapss_root(ROOT)
TRAIN_MANIFEST = ROOT / "logs" / "scores" / "primary_score_manifest.json"
OUT = ROOT / "logs" / "r1_case_audit.json"
STEP = 10


def _first_alert(group: pd.DataFrame) -> float | None:
    p = group[group["persistent_alert"].astype(bool)]
    return float(p["score_time"].min()) if len(p) else None


def _episode_count(group: pd.DataFrame) -> int:
    return int(group["episode_id"].notna().sum() and group.loc[group["episode_id"].notna(), "episode_id"].nunique())


def classify(f_raw, f_lin, ep_raw, ep_lin):
    both = f_raw is not None and f_lin is not None
    if both:
        delta = f_raw - f_lin  # positive = linear earlier
        if delta > 0 and ep_lin <= ep_raw:
            return "success"
        if abs(delta) <= STEP and abs(ep_lin - ep_raw) <= 1:
            return "neutral"
        if delta <= -2 * STEP or ep_lin - ep_raw >= 2:
            return "adverse"
        return None
    if f_lin is None and f_raw is not None:
        return "adverse"
    return None


def contributor_stability(group: pd.DataFrame, k: int = 5) -> dict:
    """Top-K Jaccard and sign-consistency across neighboring windows."""
    rows = group.sort_values("score_time")
    keys: list[set[str]] = []
    for _, r in rows.iterrows():
        try:
            contribs = json.loads(r["contributors_json"])
        except (TypeError, ValueError):
            keys.append(set())
            continue
        keys.append({c["key"] for c in contribs[:k]})
    jaccards = []
    for a, b in zip(keys, keys[1:]):
        if a and b:
            jaccards.append(len(a & b) / len(a | b))
        elif not a and not b:
            jaccards.append(1.0)
        else:
            jaccards.append(0.0)
    return {
        "n_windows": len(keys),
        "median_neighbor_jaccard": float(np.median(jaccards)) if jaccards else None,
    }


def main() -> None:
    joined, _ = join_training_endpoints(TRAIN_MANIFEST, DATA_ROOT, horizon=125)
    ldsi = joined[joined["monitor"] == "ldsi"]

    engine_rows: list[dict] = []
    for (subset, engine_id), group in ldsi.groupby(["subset", "engine_id"], sort=True):
        raw = group[group["conditioning"] == "raw"]
        lin = group[group["conditioning"] == "linear"]
        f_raw = _first_alert(raw)
        f_lin = _first_alert(lin)
        ep_raw = _episode_count(raw)
        ep_lin = _episode_count(lin)
        category = classify(f_raw, f_lin, ep_raw, ep_lin)
        engine_rows.append({
            "subset": subset, "engine_id": int(engine_id),
            "f_raw": f_raw, "f_linear": f_lin,
            "episodes_raw": ep_raw, "episodes_linear": ep_lin,
            "category": category,
        })
    df = pd.DataFrame(engine_rows)

    cases: dict = {}
    for subset in ("FD002", "FD004"):
        sub = df[df["subset"] == subset]
        cases[subset] = {}
        for category in ("success", "neutral", "adverse"):
            candidates = sub[sub["category"] == category].sort_values("engine_id")
            if len(candidates):
                chosen = candidates.iloc[0]
                engine_id = int(chosen["engine_id"])
                group = ldsi[(ldsi["subset"] == subset) & (ldsi["engine_id"] == engine_id)]
                cases[subset][category] = {
                    "engine_id": engine_id,
                    "f_raw": None if chosen["f_raw"] is None else float(chosen["f_raw"]),
                    "f_linear": None if chosen["f_linear"] is None else float(chosen["f_linear"]),
                    "episodes_raw": int(chosen["episodes_raw"]),
                    "episodes_linear": int(chosen["episodes_linear"]),
                    "raw_stability": contributor_stability(group[group["conditioning"] == "raw"]),
                    "linear_stability": contributor_stability(group[group["conditioning"] == "linear"]),
                }
            else:
                cases[subset][category] = {"empty": True}

    payload = {
        "selection_rules": {
            "success": "linear earlier AND total episodes not increased",
            "neutral": "both detected, |f_raw - f_linear| <= step, episode diff <= 1",
            "adverse": "linear late >= 2*step, or linear miss with raw detected, or episodes increased >= 2",
            "tie_break": "smallest engine_id",
        },
        "category_counts": {
            f"{subset}_{cat}": int(((df["subset"] == subset) & (df["category"] == cat)).sum())
            for subset in ("FD002", "FD004") for cat in ("success", "neutral", "adverse")
        },
        "cases": cases,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Wrote {OUT}")
    for subset in ("FD002", "FD004"):
        for cat in ("success", "neutral", "adverse"):
            c = cases[subset][cat]
            if "empty" in c:
                print(f"  {subset} {cat}: EMPTY")
            else:
                print(f"  {subset} {cat}: engine {c['engine_id']} raw f={c['f_raw']} lin f={c['f_linear']}")


if __name__ == "__main__":
    main()
