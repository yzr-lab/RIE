"""Bootstrap operational metrics from the locked primary score ledgers.

This script does not rescore trajectories.  It only aggregates the existing
window-level records into engine-level workload, coverage, lead, and paired
alert-timing summaries, then applies an FD-stratified engine bootstrap.
"""

from __future__ import annotations

import json
import csv
from collections import defaultdict
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SCORE_DIR = ROOT / "logs" / "scores" / "primary"
DATA_DIR = ROOT.parent / "data" / "cmapss"
OUT = ROOT / "logs" / "r1_operational_inference.json"
SUBSETS = ("FD001", "FD002", "FD003", "FD004")
CONDITIONINGS = ("raw", "linear")
MONITORS = ("ldsi", "dynamic_corr", "mewma", "mcusum", "var1")
HORIZON = 125
B = 5000
SEED = 20260917


def _train_end_cycles() -> dict[tuple[str, int], int]:
    ends: dict[tuple[str, int], int] = {}
    for subset in SUBSETS:
        path = DATA_DIR / f"train_{subset}.txt"
        with path.open("r", encoding="utf-8") as stream:
            for line in stream:
                fields = line.split()
                if not fields:
                    continue
                key = (subset, int(fields[0]))
                ends[key] = max(ends.get(key, 0), int(float(fields[1])))
    return ends


def _load_rows() -> dict[tuple[str, int, str, str], list[dict]]:
    groups: dict[tuple[str, int, str, str], list[dict]] = defaultdict(list)
    for path in sorted(SCORE_DIR.glob("FD*_*.jsonl")):
        with path.open("r", encoding="utf-8") as stream:
            for line in stream:
                if line.strip():
                    row = json.loads(line)
                    key = (
                        row["subset"],
                        int(row["engine_id"]),
                        row["monitor"],
                        row["conditioning"],
                    )
                    groups[key].append(row)
    return groups


def _summary(rows: list[dict], terminal: int) -> dict[str, float | int | bool]:
    event_cycle = terminal - HORIZON
    score_times = np.asarray([float(row["score_time"]) for row in rows])
    persistent = np.asarray([bool(row["persistent_alert"]) for row in rows])
    pre = score_times < event_cycle
    pre_persistent = persistent & pre
    episode_ids = [row["episode_id"] for row in rows]
    all_episodes = {value for value in episode_ids if value is not None}
    pre_episodes = {
        row["episode_id"]
        for row, is_pre, is_persistent in zip(rows, pre, persistent, strict=True)
        if is_pre and is_persistent and row["episode_id"] is not None
    }
    first_alerts = score_times[persistent]
    first_alert = float(first_alerts.min()) if len(first_alerts) else None
    event_observed = bool(np.any(~pre))
    event_detected = bool(np.any(persistent & ~pre))
    pre_advance = (
        max(float(event_cycle) - first_alert, 0.0)
        if first_alert is not None
        else 0.0
    )
    failure_lead = float(terminal - first_alert) if first_alert is not None else 0.0
    return {
        "n_windows": len(rows),
        "pre_windows": int(pre.sum()),
        "pre_persistent_windows": int(pre_persistent.sum()),
        "pre_episodes": len(pre_episodes),
        "all_episodes": len(all_episodes),
        "event_observed": event_observed,
        "event_detected": event_detected,
        "pre_advance_fleet": pre_advance,
        "failure_lead_fleet": failure_lead,
        "first_alert": first_alert,
    }


def _mean_ci(values: np.ndarray) -> tuple[float, float, float]:
    return (
        float(np.mean(values)),
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    )


def _bootstrap_engine_metric(
    by_fd: dict[str, list[dict]],
    metric: str,
    denominator: str | None = None,
    rng: np.random.Generator | None = None,
) -> tuple[float, float, float]:
    assert rng is not None
    replicate_values: list[np.ndarray] = []
    replicate_denominators: list[np.ndarray] = []
    point_values: list[float] = []
    for subset in SUBSETS:
        rows = by_fd[subset]
        values = np.asarray([float(row[metric]) for row in rows], dtype=float)
        point_values.append(float(values.sum()))
        idx = rng.integers(0, len(values), size=(B, len(values)))
        sampled = values[idx].sum(axis=1)
        if denominator is not None:
            den = np.asarray([float(row[denominator]) for row in rows], dtype=float)
            sampled_den = den[idx].sum(axis=1)
            replicate_denominators.append(sampled_den)
        replicate_values.append(sampled)
    n_total = sum(len(by_fd[subset]) for subset in SUBSETS)
    if denominator is not None:
        point_num = sum(point_values)
        point_den = sum(
            float(row[denominator]) for subset in SUBSETS for row in by_fd[subset]
        )
        point = point_num / point_den
        draws = np.divide(
            sum(replicate_values),
            sum(replicate_denominators),
            out=np.full(B, np.nan),
            where=sum(replicate_denominators) != 0,
        )
    else:
        point = sum(point_values) / n_total
        draws = sum(replicate_values) / n_total
    return point, float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))


def _bootstrap_mean_difference(
    raw: dict[str, list[dict]], linear: dict[str, list[dict]], metric: str,
    rng: np.random.Generator,
) -> tuple[float, float, float]:
    draws: list[np.ndarray] = []
    point_parts: list[float] = []
    n_parts: list[int] = []
    for subset in SUBSETS:
        raw_rows = {int(row["engine_id"]): row for row in raw[subset]}
        lin_rows = {int(row["engine_id"]): row for row in linear[subset]}
        ids = sorted(set(raw_rows) & set(lin_rows))
        raw_values = np.asarray([float(raw_rows[i][metric]) for i in ids])
        lin_values = np.asarray([float(lin_rows[i][metric]) for i in ids])
        point_parts.append(float(np.mean(lin_values - raw_values)))
        n_parts.append(len(ids))
        idx = rng.integers(0, len(ids), size=(B, len(ids)))
        draws.append(np.mean(lin_values[idx] - raw_values[idx], axis=1))
    total_n = sum(n_parts)
    point = float(sum(value * n for value, n in zip(point_parts, n_parts, strict=True)) / total_n)
    all_draws = sum(draw * n for draw, n in zip(draws, n_parts, strict=True)) / total_n
    return point, float(np.quantile(all_draws, 0.025)), float(np.quantile(all_draws, 0.975))


def _bootstrap_ratio_difference(
    raw: dict[str, list[dict]], linear: dict[str, list[dict]],
    numerator: str, denominator: str, rng: np.random.Generator,
) -> tuple[float, float, float]:
    draws: list[np.ndarray] = []
    raw_num_draws: list[np.ndarray] = []
    raw_den_draws: list[np.ndarray] = []
    lin_num_draws: list[np.ndarray] = []
    lin_den_draws: list[np.ndarray] = []
    raw_num_total = raw_den_total = lin_num_total = lin_den_total = 0.0
    for subset in SUBSETS:
        raw_rows = {int(row["engine_id"]): row for row in raw[subset]}
        lin_rows = {int(row["engine_id"]): row for row in linear[subset]}
        ids = sorted(set(raw_rows) & set(lin_rows))
        raw_num = np.asarray([float(raw_rows[i][numerator]) for i in ids])
        raw_den = np.asarray([float(raw_rows[i][denominator]) for i in ids])
        lin_num = np.asarray([float(lin_rows[i][numerator]) for i in ids])
        lin_den = np.asarray([float(lin_rows[i][denominator]) for i in ids])
        raw_num_total += float(raw_num.sum())
        raw_den_total += float(raw_den.sum())
        lin_num_total += float(lin_num.sum())
        lin_den_total += float(lin_den.sum())
        idx = rng.integers(0, len(ids), size=(B, len(ids)))
        raw_num_draws.append(raw_num[idx].sum(axis=1))
        raw_den_draws.append(raw_den[idx].sum(axis=1))
        lin_num_draws.append(lin_num[idx].sum(axis=1))
        lin_den_draws.append(lin_den[idx].sum(axis=1))
    all_draws = (
        sum(lin_num_draws) / sum(lin_den_draws)
        - sum(raw_num_draws) / sum(raw_den_draws)
    )
    point = float(lin_num_total / lin_den_total - raw_num_total / raw_den_total)
    return point, float(np.quantile(all_draws, 0.025)), float(np.quantile(all_draws, 0.975))


def _paired_bootstrap(monitor: str, rng: np.random.Generator) -> dict:
    """Bootstrap the exact paired cohort used by the metric ledger."""
    path = ROOT / "logs" / "evaluation" / "per_engine_metrics.csv"
    grouped: dict[tuple[str, int], dict[str, float | None]] = defaultdict(dict)
    with path.open("r", encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream):
            if row["monitor"] != monitor:
                continue
            value = row["first_persistent_alert"]
            grouped[(row["subset"], int(row["engine_id"]))][row["conditioning"]] = (
                float(value) if value else None
            )
    rows_by_fd: dict[str, list[float]] = {}
    for subset in SUBSETS:
        values = [
            float(grouped[(subset, engine_id)]["raw"] - grouped[(subset, engine_id)]["linear"])
            for (ss, engine_id), pair in grouped.items()
            if ss == subset and pair.get("raw") is not None and pair.get("linear") is not None
        ]
        rows_by_fd[subset] = values
    draws = []
    points = []
    for subset in SUBSETS:
        values = np.asarray(rows_by_fd[subset], dtype=float)
        points.append(float(np.mean(values)))
        idx = rng.integers(0, len(values), size=(B, len(values)))
        draws.append(np.mean(values[idx], axis=1))
    counts = [len(rows_by_fd[subset]) for subset in SUBSETS]
    combined = sum(draw * n for draw, n in zip(draws, counts, strict=True)) / sum(counts)
    return {
        "paired_mean": float(sum(value * n for value, n in zip(points, counts, strict=True)) / sum(counts)),
        "paired_mean_ci_low": float(np.quantile(combined, 0.025)),
        "paired_mean_ci_high": float(np.quantile(combined, 0.975)),
        "paired_n_by_fd": {subset: len(rows_by_fd[subset]) for subset in SUBSETS},
    }


def main() -> None:
    terminal = _train_end_cycles()
    groups = _load_rows()
    summaries: dict[tuple[str, str, str], dict] = {}
    for (subset, engine_id, monitor, conditioning), rows in groups.items():
        summaries[(subset, engine_id, monitor, conditioning)] = {
            "engine_id": engine_id,
            **_summary(rows, terminal[(subset, engine_id)]),
        }

    output: dict[str, object] = {
        "bootstrap": {"B": B, "seed": SEED, "unit": "engine within FD"},
        "horizon": HORIZON,
        "metrics": {},
    }
    for monitor_index, monitor in enumerate(MONITORS):
        raw_by_fd: dict[str, list[dict]] = defaultdict(list)
        lin_by_fd: dict[str, list[dict]] = defaultdict(list)
        for subset in SUBSETS:
            for conditioning, target in (("raw", raw_by_fd), ("linear", lin_by_fd)):
                for (ss, engine_id, mm, cc), row in summaries.items():
                    if (ss, mm, cc) == (subset, monitor, conditioning) and row["n_windows"] >= 5:
                        target[subset].append(row)
        rng = np.random.default_rng(SEED + monitor_index)
        result: dict[str, object] = {}
        for conditioning, rows_by_fd in (("raw", raw_by_fd), ("linear", lin_by_fd)):
            result[conditioning] = {
                "pre_window_fpr": _bootstrap_engine_metric(
                    rows_by_fd, "pre_persistent_windows", "pre_windows", rng
                ),
                "pre_proxy_episodes_per_engine": _bootstrap_engine_metric(
                    rows_by_fd, "pre_episodes", None, rng
                ),
                "complete_episodes_per_engine": _bootstrap_engine_metric(
                    rows_by_fd, "all_episodes", None, rng
                ),
                "event_coverage": _bootstrap_engine_metric(
                    rows_by_fd, "event_detected", "event_observed", rng
                ),
                "pre_proxy_advance_fleet": _bootstrap_engine_metric(
                    rows_by_fd, "pre_advance_fleet", None, rng
                ),
                "failure_lead_fleet": _bootstrap_engine_metric(
                    rows_by_fd, "failure_lead_fleet", None, rng
                ),
            }
        result["differences_linear_minus_raw"] = {
            "pre_window_fpr": _bootstrap_ratio_difference(
                raw_by_fd, lin_by_fd, "pre_persistent_windows", "pre_windows", rng
            ),
            **{
                metric: _bootstrap_mean_difference(raw_by_fd, lin_by_fd, key, rng)
                for metric, key in (
                    ("pre_proxy_episodes_per_engine", "pre_episodes"),
                    ("complete_episodes_per_engine", "all_episodes"),
                    ("event_coverage", "event_detected"),
                    ("pre_proxy_advance_fleet", "pre_advance_fleet"),
                    ("failure_lead_fleet", "failure_lead_fleet"),
                )
            },
        }
        result["paired_alert_timing"] = _paired_bootstrap(monitor, rng)
        output["metrics"][monitor] = result

    OUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
