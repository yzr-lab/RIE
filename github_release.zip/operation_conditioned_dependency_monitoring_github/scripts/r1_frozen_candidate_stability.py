"""Audit frozen calibration top-M candidate overlap without rescoring trajectories."""

from __future__ import annotations

import json
import sys
from collections import defaultdict
from itertools import combinations
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.conditioning import fit_context_model, fit_engine_scaler, transform_with_support  # noqa: E402
from rineng_replay.data import load_cmapss_observed  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402
from rineng_replay.protocol import ReplayConfig, window_count  # noqa: E402
from rineng_replay.relations import fit_top_strength_relations  # noqa: E402


DATA_ROOT = resolve_cmapss_root(ROOT)
OUTPUT = ROOT / "logs" / "r1_frozen_candidate_stability.json"
CONFIG = ReplayConfig(
    calibration_cycles=60,
    window_size=40,
    step=10,
    persistence=3,
    max_lag=3,
    selector_m=20,
    aggregation_k=5,
    min_monitor_windows=5,
)


def _candidate_set(values: np.ndarray) -> set[str]:
    relation_set = fit_top_strength_relations(
        values,
        max_lag=CONFIG.max_lag,
        m=CONFIG.selector_m,
    )
    return {relation.display_key for relation in relation_set.relations}


def _jaccard(left: set[str], right: set[str]) -> float:
    union = left | right
    return len(left & right) / len(union) if union else 1.0


def _summarize(groups: dict[str, list[set[str]]]) -> dict:
    rows = {}
    for fd, sets in sorted(groups.items()):
        values = [_jaccard(a, b) for a, b in combinations(sets, 2)]
        rows[fd] = {
            "engines": len(sets),
            "pairwise_jaccard_mean": float(np.mean(values)) if values else None,
            "pairwise_jaccard_median": float(np.median(values)) if values else None,
            "pairwise_jaccard_n": len(values),
        }
    all_sets = [item for values in groups.values() for item in values]
    all_values = [_jaccard(a, b) for a, b in combinations(all_sets, 2)]
    rows["ALL"] = {
        "engines": len(all_sets),
        "pairwise_jaccard_mean": float(np.mean(all_values)) if all_values else None,
        "pairwise_jaccard_median": float(np.median(all_values)) if all_values else None,
        "pairwise_jaccard_n": len(all_values),
    }
    return rows


def main() -> None:
    groups: dict[str, dict[str, list[set[str]]]] = {
        "raw": defaultdict(list),
        "linear": defaultdict(list),
    }
    monitorable = 0
    for subset in ("FD001", "FD002", "FD003", "FD004"):
        trajectories = load_cmapss_observed(DATA_ROOT, subset, "train", None)
        for trajectory in trajectories:
            if window_count(len(trajectory.cycles), CONFIG) < CONFIG.min_monitor_windows:
                continue
            monitorable += 1
            scaler = fit_engine_scaler(trajectory, CONFIG.calibration_cycles)
            scaled = scaler.transform(trajectory.sensors)
            mask = trajectory.cycles <= CONFIG.calibration_cycles
            raw_calibration = scaled[mask]
            groups["raw"][subset].append(_candidate_set(raw_calibration))
            context = fit_context_model(
                trajectory.settings[mask], raw_calibration, "linear"
            )
            conditioned = transform_with_support(
                context, trajectory.settings, scaled
            ).residuals
            groups["linear"][subset].append(
                _candidate_set(conditioned[mask])
            )
    payload = {
        "definition": (
            "Pairwise Jaccard overlap of calibration-fixed top-M candidate sets, "
            "computed from the first 60 cycles of each monitorable trajectory; "
            "this is distinct from dynamic scored top-K contributor overlap."
        ),
        "protocol": {
            "calibration_cycles": CONFIG.calibration_cycles,
            "max_lag": CONFIG.max_lag,
            "selector_m": CONFIG.selector_m,
        },
        "monitorable_engines": monitorable,
        "by_conditioning": {
            conditioning: _summarize(dict(groups[conditioning]))
            for conditioning in ("raw", "linear")
        },
    }
    OUTPUT.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    for conditioning in ("raw", "linear"):
        print(conditioning, payload["by_conditioning"][conditioning]["ALL"])
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    main()
