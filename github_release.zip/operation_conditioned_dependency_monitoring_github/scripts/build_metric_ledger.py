"""Join endpoints after score verification and build the sole metric ledger."""

from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.evaluation import (  # noqa: E402
    apply_threshold_multiplier,
    first_persistent_alerts,
    join_training_endpoints,
    normalized_partial_auc,
    paired_advance_metrics,
    ranking_metrics,
    summarize_alert_workload,
)
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402
from rineng_replay.monitors import MONITOR_NAMES  # noqa: E402
from rineng_replay.statistics import fixed_fd_engine_bootstrap  # noqa: E402


DATA_ROOT = resolve_cmapss_root(ROOT)
SCORE_MANIFEST = ROOT / "logs" / "scores" / "primary_score_manifest.json"
METRIC_PATH = ROOT / "logs" / "main_metrics.json"
EVALUATION_DIR = ROOT / "logs" / "evaluation"
METRIC_MANIFEST = ROOT / "logs" / "metrics_manifest.json"
HORIZON = 125


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _scope_rows(frame: pd.DataFrame, scope: str) -> pd.DataFrame:
    return frame if scope == "ALL" else frame[frame["subset"] == scope]


def _engine_ranking_rows(frame: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for (subset, engine_id), group in frame.groupby(["subset", "engine_id"], sort=True):
        labels = group["event_label"].to_numpy(dtype=int)
        if len(np.unique(labels)) < 2:
            auc = float("nan")
            pauc = float("nan")
        else:
            from sklearn.metrics import roc_auc_score

            auc = float(roc_auc_score(labels, group["score"]))
            pauc = normalized_partial_auc(labels, group["score"], max_fpr=0.10)
        persistent = group[group["persistent_alert"].astype(bool)]
        first_alert = float(persistent["score_time"].min()) if len(persistent) else float("nan")
        event_cycle = float(group["max_cycle"].iloc[0] - HORIZON)
        rows.append(
            {
                "subset": subset,
                "engine_id": int(engine_id),
                "auc": auc,
                "normalized_pauc_0_10": pauc,
                "first_persistent_alert": first_alert,
                "event_cycle": event_cycle,
                "pre_event_lead": max(event_cycle - first_alert, 0.0) if np.isfinite(first_alert) else 0.0,
            }
        )
    return pd.DataFrame(rows)


def _clean(value):
    if isinstance(value, dict):
        return {str(key): _clean(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_clean(item) for item in value]
    if isinstance(value, tuple):
        return [_clean(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return None if not math.isfinite(number) else number
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def main() -> None:
    joined, score_manifest = join_training_endpoints(
        SCORE_MANIFEST, DATA_ROOT, horizon=HORIZON
    )
    # Restrict the primary evaluation to the monitorable cohort (>=5 windows);
    # short trajectories are scored (streaming) but not part of this cohort.
    joined = joined[
        joined.groupby(["subset", "engine_id"])["score_time"].transform("nunique") >= 5
    ]
    EVALUATION_DIR.mkdir(parents=True, exist_ok=True)
    metric_rows: list[dict] = []
    per_engine_frames: list[pd.DataFrame] = []
    lookup: dict[tuple[str, str, str], dict] = {}
    scopes = ("ALL", "FD001", "FD002", "FD003", "FD004")

    for monitor in MONITOR_NAMES:
        for conditioning in ("raw", "linear"):
            base = joined[
                (joined["monitor"] == monitor)
                & (joined["conditioning"] == conditioning)
            ]
            engine_metrics = _engine_ranking_rows(base)
            engine_metrics["monitor"] = monitor
            engine_metrics["conditioning"] = conditioning
            per_engine_frames.append(engine_metrics)
            finite_auc = engine_metrics[np.isfinite(engine_metrics["auc"])][
                ["subset", "engine_id", "auc"]
            ].rename(columns={"auc": "value"})
            bootstrap = (
                fixed_fd_engine_bootstrap(
                    finite_auc, n_resamples=1000, seed=20260819
                )
                if len(finite_auc)
                else None
            )
            for scope in scopes:
                group = _scope_rows(base, scope)
                if len(group) == 0:
                    continue
                row = {
                    "scope": scope,
                    "monitor": monitor,
                    "conditioning": conditioning,
                    **ranking_metrics(group),
                    **summarize_alert_workload(group, horizon=HORIZON),
                }
                if scope == "ALL":
                    row["engine_macro_auc_fixed_fd_bootstrap"] = bootstrap
                metric_rows.append(row)
                lookup[(scope, monitor, conditioning)] = row

    per_engine_path = EVALUATION_DIR / "per_engine_metrics.csv"
    pd.concat(per_engine_frames, ignore_index=True).to_csv(per_engine_path, index=False)

    paired_rows: list[dict] = []
    ecdf_rows: list[dict] = []
    for monitor in MONITOR_NAMES:
        monitor_rows = joined[joined["monitor"] == monitor]
        raw_alerts = first_persistent_alerts(
            monitor_rows[monitor_rows["conditioning"] == "raw"]
        ).rename(columns={"first_persistent_alert": "raw_first_alert"})
        linear_alerts = first_persistent_alerts(
            monitor_rows[monitor_rows["conditioning"] == "linear"]
        ).rename(columns={"first_persistent_alert": "linear_first_alert"})
        paired = raw_alerts.merge(
            linear_alerts, on=["subset", "engine_id"], how="inner"
        )
        paired["advance"] = paired["raw_first_alert"] - paired["linear_first_alert"]
        for scope in scopes:
            group = paired if scope == "ALL" else paired[paired["subset"] == scope]
            metrics = paired_advance_metrics(group["advance"].to_numpy())
            metrics.update(
                {
                    "scope": scope,
                    "monitor": monitor,
                    "delta_pre_proxy_advance_fleet": (
                        lookup[(scope, monitor, "linear")]["pre_proxy_advance_fleet_zero_filled"]
                        - lookup[(scope, monitor, "raw")]["pre_proxy_advance_fleet_zero_filled"]
                    ),
                }
            )
            paired_rows.append(metrics)
            ordered = np.sort(group["advance"].to_numpy(dtype=float))
            for rank, value in enumerate(ordered, start=1):
                ecdf_rows.append(
                    {
                        "scope": scope,
                        "monitor": monitor,
                        "advance": value,
                        "ecdf": rank / len(ordered),
                    }
                )
    ecdf_path = EVALUATION_DIR / "paired_advance_ecdf.csv"
    pd.DataFrame(ecdf_rows).to_csv(ecdf_path, index=False)

    conditioning_effects: list[dict] = []
    interactions: list[dict] = []
    for monitor in MONITOR_NAMES:
        for scope in scopes:
            raw = lookup[(scope, monitor, "raw")]
            linear = lookup[(scope, monitor, "linear")]
            conditioning_effects.append(
                {
                    "scope": scope,
                    "monitor": monitor,
                    "delta_engine_macro_auc": linear["engine_macro_auc"] - raw["engine_macro_auc"],
                    "delta_pooled_window_auc": linear["pooled_window_auc"] - raw["pooled_window_auc"],
                    "delta_pre_proxy_advance_fleet": linear["pre_proxy_advance_fleet_zero_filled"] - raw["pre_proxy_advance_fleet_zero_filled"],
                    "delta_all_episode_rate_per_engine": linear["all_episode_rate_per_engine"] - raw["all_episode_rate_per_engine"],
                }
            )
        single = np.mean(
            [
                lookup[(scope, monitor, "linear")]["engine_macro_auc"]
                - lookup[(scope, monitor, "raw")]["engine_macro_auc"]
                for scope in ("FD001", "FD003")
            ]
        )
        multi = np.mean(
            [
                lookup[(scope, monitor, "linear")]["engine_macro_auc"]
                - lookup[(scope, monitor, "raw")]["engine_macro_auc"]
                for scope in ("FD002", "FD004")
            ]
        )
        interactions.append(
            {
                "monitor": monitor,
                "single_condition_mean_delta_auc": float(single),
                "multi_condition_mean_delta_auc": float(multi),
                "multi_minus_single_conditioning_gain": float(multi - single),
            }
        )

    threshold_frontier: list[dict] = []
    for monitor in MONITOR_NAMES:
        for conditioning in ("raw", "linear"):
            base = joined[
                (joined["monitor"] == monitor)
                & (joined["conditioning"] == conditioning)
            ]
            for multiplier in (0.75, 1.0, 1.25, 1.5, 2.0):
                classified = apply_threshold_multiplier(
                    base, multiplier=multiplier, persistence=3
                )
                threshold_frontier.append(
                    {
                        "monitor": monitor,
                        "conditioning": conditioning,
                        "threshold_multiplier": multiplier,
                        **summarize_alert_workload(classified, horizon=HORIZON),
                    }
                )

    monitorability = pd.read_csv(
        ROOT / "logs" / "audits" / "monitorability_flow.csv"
    )
    support = pd.read_csv(
        ROOT / "logs" / "audits" / "conditioning_support.csv"
    )
    protocol_summary: list[dict] = []
    for subset in ("FD001", "FD002", "FD003", "FD004"):
        flow = monitorability[monitorability["subset"] == subset]
        conditioned_support = support[
            (support["subset"] == subset)
            & (support["conditioning"] == "linear")
        ]
        protocol_summary.append(
            {
                "subset": subset,
                "condition_group": "single-condition" if subset in {"FD001", "FD003"} else "multi-condition",
                "fault_mode_group": "one-fault" if subset in {"FD001", "FD002"} else "two-fault",
                "total_train_engines": len(flow),
                "monitorable_train_engines": int(flow["monitorable"].sum()),
                "calibration_cycles": 60,
                "window_size": 40,
                "step": 10,
                "median_unsupported_fraction": float(conditioned_support["unsupported_fraction"].median()),
                "median_residual_energy_ratio": float(conditioned_support["residual_energy_ratio"].median()),
                "median_variance_retention": float(conditioned_support["median_variance_retention"].median()),
                "median_condition_association_before": float(conditioned_support["median_condition_association_before"].median()),
                "median_condition_association_after": float(conditioned_support["median_condition_association_after"].median()),
                "observed_event_region_engines": lookup[(subset, "ldsi", "raw")]["event_observed_engines"],
            }
        )

    audit_dir = ROOT / "logs" / "audits"
    sensitivity_files = {
        "context_model": audit_dir / "context_model_sensitivity.csv",
        "selector_m_k": audit_dir / "selector_m_k_sensitivity.csv",
        "step_horizon": audit_dir / "step_horizon_sensitivity.csv",
        "length_stratified": audit_dir / "length_stratified_sensitivity.csv",
    }
    sensitivity_payload = {
        key: pd.read_csv(path).to_dict(orient="records")
        for key, path in sensitivity_files.items()
        if path.is_file()
    }
    interaction_2x2_path = audit_dir / "fd_2x2_interaction.json"
    if interaction_2x2_path.is_file():
        sensitivity_payload["fd_2x2"] = json.loads(
            interaction_2x2_path.read_text(encoding="utf-8")
        )
    sensitivity_hashes = {
        key: _sha256(path) for key, path in sensitivity_files.items()
        if path.is_file()
    }
    if interaction_2x2_path.is_file():
        sensitivity_hashes["fd_2x2"] = _sha256(interaction_2x2_path)
    censored_path = ROOT / "logs" / "evaluations" / "test_censored_metrics.json"
    censored_payload = json.loads(censored_path.read_text(encoding="utf-8"))

    payload = _clean(
        {
            "schema_version": "1.0",
            "protocol_sha256": score_manifest["protocol_sha256"],
            "source_score_manifest_sha256": _sha256(SCORE_MANIFEST),
            "evaluation_horizon_cycles": HORIZON,
            "score_rows": len(joined),
            "metric_definitions": {
                "score_timestamp": "completed window end",
                "event_label": "training endpoint RUL <= horizon cycles; evaluation only",
                "normalized_pauc_0_10": "McClish-standardized partial ROC AUC at max FPR 0.10",
                "all_episode_count": "distinct persistent-alert episodes across the full trajectory (pre-proxy and event regions combined)",
                "pre_proxy_episode_count": "distinct episodes with at least one persistent-alert window before the proxy event",
                "exposure_engine_cycles": "sum over engines of (observed end - first scheduled score + 1), inclusive",
                "event_region_coverage": "event-region detected engines / event-observed engines",
                "failure_lead_detected_mean": "terminal cycle minus first persistent-alert time, over detected engines only",
                "failure_lead_fleet_zero_filled": "terminal cycle minus first persistent-alert time, undetected engines counted as zero",
                "pre_proxy_advance_fleet_zero_filled": "max(proxy-event cycle - first persistent-alert time, 0), undetected counted as zero (renamed legacy fleet lead)",
                "pre_proxy_advance_detected_mean": "proxy-event cycle - first persistent-alert time, over pre-proxy-detected engines (renamed legacy conditional lead)",
                "paired_advance": "raw first persistent-alert time minus conditioned first persistent-alert time among engines detected by both (raw-versus-conditioned, not an independent corroboration stream)",
            },
            "metrics": metric_rows,
            "paired_advance": paired_rows,
            "paired_advance_ecdf": ecdf_rows,
            "conditioning_effects": conditioning_effects,
            "multi_vs_single_conditioning_gain": interactions,
            "threshold_frontier": threshold_frontier,
            "protocol_summary": protocol_summary,
            "official_test_censored_audit": censored_payload,
            "official_test_censored_sha256": _sha256(censored_path),
            "sensitivity_audits": sensitivity_payload,
            "sensitivity_source_sha256": sensitivity_hashes,
        }
    )
    METRIC_PATH.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    files = [METRIC_PATH, per_engine_path, ecdf_path]
    METRIC_MANIFEST.write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "protocol_sha256": score_manifest["protocol_sha256"],
                "files": [
                    {
                        "path": path.as_posix(),
                        "sha256": _sha256(path),
                        "bytes": path.stat().st_size,
                    }
                    for path in files
                ],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"Locked metric ledger: {METRIC_PATH}")
    print(f"Rows evaluated: {len(joined)}")
    for item in interactions:
        print(
            f"{item['monitor']}: multi-minus-single conditioning gain "
            f"{item['multi_minus_single_conditioning_gain']:+.4f}"
        )


if __name__ == "__main__":
    main()
