"""Generate the three editable main tables from logs/main_metrics.json."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
METRICS_PATH = ROOT / "logs/main_metrics.json"
TABLE_DIR = ROOT / "tables"


DISPLAY = {
    "ldsi": "LDSI",
    "dynamic_corr": "Dynamic correlation",
    "mewma": "MEWMA",
    "mcusum": "MCUSUM",
    "var1": "VAR(1)",
}

DISPLAY_TABLE = {
    "ldsi": r"LDSI",
    "dynamic_corr": r"\makecell[l]{Dynamic\\correlation}",
    "mewma": r"Relation-EWMA",
    "mcusum": r"\makecell[l]{Absolute-deviation\\CUSUM}",
    "var1": r"VAR(1)",
}


def _metric_lookup(payload: dict) -> dict[tuple[str, str, str], dict]:
    return {
        (row["scope"], row["monitor"], row["conditioning"]): row
        for row in payload["metrics"]
    }


def _paired_lookup(payload: dict) -> dict[tuple[str, str], dict]:
    return {
        (row["scope"], row["monitor"]): row
        for row in payload["paired_advance"]
    }


def _write(path: Path, lines: list[str]) -> None:
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _table1(payload: dict) -> list[str]:
    lines = [
        r"\begin{minipage}{\textwidth}",
        r"\centering\scriptsize",
        r"\begin{tabular}{@{}lllrrrrr@{}}",
        r"\toprule",
        r"FD & Operating regime & Fault modes & Train $n$ & Monitorable $n$ & $C/W/s$ & Median unsupported (\%) & Event-region $n$ \\",
        r"\midrule",
    ]
    for row in payload["protocol_summary"]:
        regime = "Single" if row["condition_group"] == "single-condition" else "Multiple"
        faults = "One" if row["fault_mode_group"] == "one-fault" else "Two"
        lines.append(
            f"{row['subset']} & {regime} & {faults} & {row['total_train_engines']} & "
            f"{row['monitorable_train_engines']} & {row['calibration_cycles']}/{row['window_size']}/{row['step']} & "
            f"{100.0 * row['median_unsupported_fraction']:.1f} & {row['observed_event_region_engines']} \\\\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"\par\smallskip\raggedright\footnotesize Denominator: all local training engines for Train $n$; engines with at least five completed monitoring windows for Monitorable $n$. Event-region $n$ counts monitorable engines with at least one scored window at RUL $\leq125$ cycles. $C/W/s$ are calibration, window, and step in cycles.",
            r"\end{minipage}",
        ]
    )
    return lines


def _table2(payload: dict) -> list[str]:
    lookup = _metric_lookup(payload)
    lines = [
        r"\begin{minipage}{\textwidth}",
        r"\centering\scriptsize",
        r"\resizebox{\textwidth}{!}{%",
        r"\begin{tabular}{@{}lrrrrrrrrrr@{}}",
        r"\toprule",
        r"Monitor & AUC raw & AUC cond. & $\Delta$AUC & FPR raw & FPR cond. & Pre-proxy episodes raw & Pre-proxy episodes cond. & Complete episodes raw & Complete episodes cond. & AUC $n$ \\",
        r"\midrule",
    ]
    for monitor in DISPLAY:
        raw = lookup[("ALL", monitor, "raw")]
        conditioned = lookup[("ALL", monitor, "linear")]
        lines.append(
            f"{DISPLAY[monitor]} & {raw['engine_macro_auc']:.3f} & {conditioned['engine_macro_auc']:.3f} & "
            f"{conditioned['engine_macro_auc'] - raw['engine_macro_auc']:+.3f} & "
            f"{raw['persistent_window_rate_pre_proxy']:.3f} & {conditioned['persistent_window_rate_pre_proxy']:.3f} & "
            f"{raw['pre_proxy_episode_rate_per_engine']:.3f} & {conditioned['pre_proxy_episode_rate_per_engine']:.3f} & "
            f"{raw['all_episode_rate_per_engine']:.3f} & {conditioned['all_episode_rate_per_engine']:.3f} & "
            f"{raw['engine_macro_denominator']} \\\\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}%",
            r"}",
            r"\par\smallskip\raggedright\footnotesize AUC $n$ is the number of engines containing both pre-event and event-region windows. FPR is the persistent-alert window rate among pre-event windows. Pre-proxy episodes count distinct persistent-alert episodes with at least one pre-event window; complete episodes include the full observed trajectory. Both episode rates use all 696 monitorable engines. Cond. denotes the prespecified linear operation-conditioned representation.",
            r"\end{minipage}",
        ]
    )
    return lines


def _table3(payload: dict) -> list[str]:
    lookup = _metric_lookup(payload)
    paired = _paired_lookup(payload)
    lines = [
        r"\begin{minipage}{\textwidth}",
        r"\centering\scriptsize",
        r"\resizebox{\textwidth}{!}{%",
        r"\begin{tabular}{@{}lrrrrrrrrrr@{}}",
        r"\toprule",
        r"Monitor & Proxy advance raw & Proxy advance cond. & Gain & Coverage cond. & Complete episodes cond. & Paired $n$ & $P(\Delta>0)$ & $V_{20}$ \\",
        r"\midrule",
    ]
    for monitor in DISPLAY:
        raw = lookup[("ALL", monitor, "raw")]
        conditioned = lookup[("ALL", monitor, "linear")]
        pair = paired[("ALL", monitor)]
        lines.append(
            f"{DISPLAY[monitor]} & {raw['pre_proxy_advance_fleet_zero_filled']:.2f} & {conditioned['pre_proxy_advance_fleet_zero_filled']:.2f} & "
            f"{pair['delta_pre_proxy_advance_fleet']:+.2f} & {conditioned['event_region_coverage']:.3f} & "
            f"{conditioned['all_episode_rate_per_engine']:.3f} & {pair['paired_engines']} & "
            f"{pair['probability_positive']:.3f} & {pair['v20']:.3f} \\\\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}%",
            r"}",
            r"\par\smallskip\raggedright\footnotesize Proxy advance is $\max((T-H)-a,0)$ with zero for engines without a pre-proxy alert, averaged over all 696 monitorable engines; it is not failure lead. Coverage is event-region alert coverage. Paired $n$ includes engines detected by both representations; $\Delta=a_{\rm raw}-a_{\rm cond}$ and $V_{20}=P(\Delta\geq20)$.",
            r"\end{minipage}",
        ]
    )
    return lines


def _table3_readable(payload: dict) -> list[str]:
    """Render the ranking and operational parts as two readable blocks."""
    lookup = _metric_lookup(payload)
    paired = _paired_lookup(payload)
    lines = [
        r"\begin{minipage}{\textwidth}",
        r"\centering\footnotesize",
        r"\textbf{Part A. Ranking}",
        r"\par\smallskip",
        r"\begin{tabular}{@{}lrrrrr@{}}",
        r"\toprule",
        r"\makecell[l]{Monitor} & AUC raw & AUC cond. & $\Delta$AUC & AUC $n$ & Paired $n$ \\",
        r"\midrule",
    ]
    for monitor in DISPLAY:
        raw = lookup[("ALL", monitor, "raw")]
        conditioned = lookup[("ALL", monitor, "linear")]
        pair = paired[("ALL", monitor)]
        lines.append(
            f"{DISPLAY_TABLE[monitor]} & {raw['engine_macro_auc']:.3f} & "
            f"{conditioned['engine_macro_auc']:.3f} & "
            f"{conditioned['engine_macro_auc'] - raw['engine_macro_auc']:+.3f} & "
            f"{raw['engine_macro_denominator']} & {pair['paired_engines']} " + r"\\"
        )
    lines.extend([
        r"\bottomrule",
        r"\end{tabular}",
        r"\par\smallskip",
        r"\textbf{Part B. Operational indicators}",
        r"\par\smallskip",
        r"\begin{tabular}{@{}lrrrrrrr@{}}",
        r"\toprule",
        r"\makecell[l]{Monitor} & \makecell{Fleet proxy\\raw} & \makecell{Fleet proxy\\cond.} & \makecell{Fleet\\gain} & \makecell{Coverage\\cond.} & \makecell{Complete episodes\\per engine} & $P(\Delta>0)$ \\",
        r"\midrule",
    ])
    for monitor in DISPLAY:
        raw = lookup[("ALL", monitor, "raw")]
        conditioned = lookup[("ALL", monitor, "linear")]
        pair = paired[("ALL", monitor)]
        lines.append(
            f"{DISPLAY_TABLE[monitor]} & {raw['pre_proxy_advance_fleet_zero_filled']:.2f} & "
            f"{conditioned['pre_proxy_advance_fleet_zero_filled']:.2f} & "
            f"{pair['delta_pre_proxy_advance_fleet']:+.2f} & "
            f"{conditioned['event_region_coverage']:.3f} & "
            f"{conditioned['all_episode_rate_per_engine']:.3f} & "
            f"{pair['probability_positive']:.3f} " + r"\\"
        )
    lines.extend([
        r"\bottomrule",
        r"\end{tabular}",
        r"\par\smallskip\raggedright\footnotesize Part A uses the all-engine macro-AUC columns; the paired $n$ column identifies the common timing cohort and paired delta-AUC intervals are reported in Results §5.2 and Supplementary Table S20. Part B uses all 696 monitorable engines for fleet proxy advance, coverage, and complete episodes. Proxy advance is $\max((T-H)-a,0)$ with zero for engines without a pre-proxy alert; it is not failure lead. Fleet gain is conditioned minus raw.",
        r"\end{minipage}",
    ])
    return lines


def main() -> None:
    payload = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    _write(TABLE_DIR / "table1_protocol.tex", _table1(payload))
    _write(TABLE_DIR / "table2_raw_conditioned.tex", _table2(payload))
    _write(TABLE_DIR / "table3_operational_frontier.tex", _table3_readable(payload))
    print("Generated three main tables from the locked metric ledger")


if __name__ == "__main__":
    main()
