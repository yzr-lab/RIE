"""R1 E5: controlled synthetic mechanisms separating context shift from true
dependency degradation. Mechanisms S0..S5 (S5 has two sub-panels). """

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.data import ObservedTrajectory, SENSOR_NAMES  # noqa: E402
from rineng_replay.conditioning import fit_context_model, fit_engine_scaler, transform_with_support  # noqa: E402
from rineng_replay.protocol import ReplayConfig  # noqa: E402
from rineng_replay.replay import score_trajectory  # noqa: E402

T = 400
C = 60
TSTAR = 200
TRANSITION = 40
N_SENSOR = len(SENSOR_NAMES)
N_SETTING = 3
OUT = ROOT / "logs" / "r1_synthetic.json"


def _make_o(seed: int, mechanism: str, n: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    centers = np.array(
        [[-1.0, -1.0, -1.0], [1.0, -1.0, -1.0], [-1.0, 1.0, -1.0],
         [1.0, 1.0, -1.0], [-1.0, -1.0, 1.0], [1.0, 1.0, 1.0]]
    )
    if mechanism in ("S1", "S3"):
        # uniform during calibration, then a fixed skewed composition after t*
        idx = rng.choice(6, size=n, p=np.full(6, 1.0 / 6.0))
        idx[TSTAR:] = rng.choice(6, size=n - TSTAR, p=[0.55, 0.15, 0.10, 0.10, 0.05, 0.05])
        o = centers[idx] + rng.normal(scale=0.05, size=(n, N_SETTING))
    elif mechanism == "S5a":
        # after t*, shift to a new cluster far outside calibration support
        idx = rng.choice(6, size=n)
        o = centers[idx] + rng.normal(scale=0.05, size=(n, N_SETTING))
        o[TSTAR:] += np.array([6.0, 0.0, 0.0])
    else:
        idx = rng.choice(6, size=n)
        o = centers[idx] + rng.normal(scale=0.05, size=(n, N_SETTING))
    return o


def _make_x(seed: int, mechanism: str, o: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed + 1000)
    B = rng.normal(size=(N_SETTING, N_SENSOR))
    B = B / np.linalg.norm(B, axis=0, keepdims=True)  # column-normalized
    z = np.empty((T, N_SENSOR))
    for j in range(N_SENSOR):
        state = rng.normal(size=T)
        for t in range(1, T):
            state[t] += 0.4 * state[t - 1]
        z[:, j] = state / np.sqrt(1 + 0.4**2)  # standardized AR(1)
    # lag-1 cross relation z1 -> z2 with strength a(t); a changes at t* for the
    # dependency-degradation mechanisms.
    a = np.full(T, 0.8)
    if mechanism in ("S2", "S3", "S4", "S5b"):
        a[TSTAR:] = 0.2
    eta = rng.normal(size=T)
    for t in range(1, T):
        z[t, 1] = a[t] * z[t - 1, 0] + np.sqrt(max(1.0 - a[t] ** 2, 0.0)) * eta[t]
    # S4 contains a known health component whose calibration-period component
    # is deliberately collinear with the first setting. S4u is a comparable
    # health-only control: the ramp is absent during calibration and therefore
    # is not deliberately confounded with the operating setting.
    health = np.zeros((T, N_SENSOR), dtype=float)
    if mechanism == "S4":
        ramp = np.clip(np.arange(T, dtype=float) - TSTAR, 0.0, None) / (T - TSTAR)
        health[:, 0] = 0.8 * o[:, 0] + ramp
    elif mechanism == "S4u":
        ramp = np.clip(np.arange(T, dtype=float) - TSTAR, 0.0, None) / (T - TSTAR)
        health[:, 0] = ramp
    x = o @ B + z + health + rng.normal(scale=0.05, size=(T, N_SENSOR))
    return x, health


def make_trajectory(seed: int, mechanism: str) -> ObservedTrajectory:
    o = _make_o(seed, mechanism, T)
    x, _ = _make_x(seed, mechanism, o)
    return ObservedTrajectory(
        "SYN", seed + 1, np.arange(1, T + 1), o, x, SENSOR_NAMES
    )


def make_trajectory_with_health(seed: int, mechanism: str) -> tuple[ObservedTrajectory, np.ndarray]:
    o = _make_o(seed, mechanism, T)
    x, health = _make_x(seed, mechanism, o)
    return (
        ObservedTrajectory("SYN", seed + 1, np.arange(1, T + 1), o, x, SENSOR_NAMES),
        health,
    )


def _health_retention(seed: int, mechanism: str, trajectory: ObservedTrajectory, health: np.ndarray) -> dict:
    scaler = fit_engine_scaler(trajectory, C)
    scaled = scaler.transform(trajectory.sensors)
    model = fit_context_model(trajectory.settings[:C], scaled[:C], "linear")
    conditioned = transform_with_support(model, trajectory.settings, scaled).residuals
    target = health[:, 0]
    post = np.arange(T) >= TSTAR

    def fit(signal: np.ndarray) -> tuple[float, float]:
        x = target[post]
        y = signal[post]
        slope = float(np.polyfit(x, y, 1)[0])
        corr = float(np.corrcoef(x, y)[0, 1]) if np.std(y) > 1.0e-12 else 0.0
        return slope, corr

    raw_slope, raw_corr = fit(scaled[:, 0])
    linear_slope, linear_corr = fit(conditioned[:, 0])
    return {
        "seed": seed,
        "mechanism": mechanism,
        "raw_slope": raw_slope,
        "linear_slope": linear_slope,
        "slope_retention_ratio": float(linear_slope / raw_slope) if abs(raw_slope) > 1.0e-12 else None,
        "raw_corr": raw_corr,
        "linear_corr": linear_corr,
        "health_definition": (
            "known post-change ramp in the first retained sensor (original sensor 2); "
            "S4 calibration component is 0.8 times setting 1, whereas S4u has no "
            "calibration-period health component"
        ),
    }


def _summarize(rows: list[dict]) -> dict:
    if not rows:
        return {"n": 0}
    any_post = [r for r in rows if r["post_any_alert"]]
    any_delays = [r["post_any_delay"] for r in any_post if r["post_any_delay"] is not None]
    new_delays = [r["post_new_episode_delay"] for r in rows if r["post_new_episode_delay"] is not None]
    return {
        "n": len(rows),
        "persistent_alert_rate": float(np.mean([r["any_persistent_alert"] for r in rows])),
        "pre_alert_seed_rate": float(np.mean([r["any_pre_alert"] for r in rows])),
        "post_anchor_alert_incidence": float(np.mean([r["post_any_alert"] for r in rows])),
        "post_new_episode_rate": float(np.mean([r["post_new_episode"] for r in rows])),
        "post_continuation_rate": float(np.mean([r["post_continuation"] for r in rows])),
        "post_any_delay_median": float(np.median(any_delays)) if any_delays else None,
        "post_any_delay_n": len(any_delays),
        "post_new_episode_delay_median": float(np.median(new_delays)) if new_delays else None,
        "post_new_episode_delay_n": len(new_delays),
        "mean_pre_alert_windows": float(np.mean([r["pre_alerts"] for r in rows])),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, default=100)
    parser.add_argument("--seed0", type=int, default=0)
    args = parser.parse_args()

    config = ReplayConfig(
        calibration_cycles=60, window_size=40, step=10, persistence=3,
        max_lag=3, selector_m=20, aggregation_k=5, min_monitor_windows=5,
    )
    mechanisms = ("S0", "S1", "S2", "S3", "S4", "S4u", "S5a", "S5b")
    monitors = ("ldsi", "mewma", "mcusum")
    results: dict[str, list[dict]] = {}
    health_rows: list[dict] = []
    summaries: dict[str, dict] = {}

    for mech in mechanisms:
        print(f"Mechanism {mech}", flush=True)
        mech_rows = []
        for seed in range(args.seed0, args.seed0 + args.seeds):
            trajectory, health = make_trajectory_with_health(seed, mech)
            if mech in ("S4", "S4u"):
                health_rows.append(_health_retention(seed, mech, trajectory, health))
            for conditioning in ("raw", "linear"):
                for threshold_branch in ("reference_deviation", "matched_operator"):
                    result = score_trajectory(
                        trajectory, config, conditioning=conditioning,
                        monitor_names=monitors, threshold_branch=threshold_branch,
                    )
                    for monitor in monitors:
                        records = result.records[monitor]
                        persistent_records = [r for r in records if r.persistent_alert]
                        persistent_times = [r.score_time for r in persistent_records]
                        pre_times = [time for time in persistent_times if time < TSTAR]
                        post_times = [time for time in persistent_times if time >= TSTAR]
                        pre_episode_ids = {
                            r.episode_id for r in persistent_records
                            if r.score_time < TSTAR and r.episode_id is not None
                        }
                        post_episode_ids = {
                            r.episode_id for r in persistent_records
                            if r.score_time >= TSTAR and r.episode_id is not None
                        }
                        new_post_records = [
                            r for r in persistent_records
                            if r.score_time >= TSTAR
                            and r.episode_id is not None
                            and r.episode_id not in pre_episode_ids
                        ]
                        continuation = bool(post_episode_ids & pre_episode_ids)
                        new_episode = bool(new_post_records)
                        first_alert = min(persistent_times) if persistent_times else None
                        mech_rows.append({
                            "mechanism": mech, "seed": seed, "conditioning": conditioning,
                            "monitor": monitor, "threshold_branch": threshold_branch,
                            "first_alert": first_alert,
                            "pre_alerts": len(pre_times),
                            "any_pre_alert": bool(pre_times),
                            "any_persistent_alert": bool(persistent_times),
                            "post_any_alert": bool(post_times),
                            "post_new_episode": new_episode,
                            "post_continuation": continuation,
                            "post_any_delay": (min(post_times) - TSTAR) if post_times else None,
                            "post_new_episode_delay": (
                                min(r.score_time for r in new_post_records) - TSTAR
                                if new_post_records else None
                            ),
                            "delay": (first_alert - TSTAR) if (first_alert is not None and first_alert >= TSTAR) else None,
                            "n_unsupported_windows": sum(1 for r in records if r.unsupported_rows_in_window > 0),
                        })
        results[mech] = mech_rows
        summaries[mech] = {}
        for threshold_branch in ("reference_deviation", "matched_operator"):
            summaries[mech][threshold_branch] = {}
            for monitor in monitors:
                summaries[mech][threshold_branch][monitor] = {
                    cond: _summarize([
                        row for row in mech_rows
                        if row["threshold_branch"] == threshold_branch
                        and row["monitor"] == monitor
                        and row["conditioning"] == cond
                    ])
                    for cond in ("raw", "linear")
                }

    OUT.parent.mkdir(parents=True, exist_ok=True)
    health_summaries = {}
    for mechanism in ("S4", "S4u"):
        group = [row for row in health_rows if row["mechanism"] == mechanism]
        ratios = [row["slope_retention_ratio"] for row in group if row["slope_retention_ratio"] is not None]
        raw_slopes = [row["raw_slope"] for row in group]
        linear_slopes = [row["linear_slope"] for row in group]
        health_summaries[mechanism] = {
            "n": len(group),
            "raw_slope": float(np.mean(raw_slopes)),
            "linear_slope": float(np.mean(linear_slopes)),
            "retention_mean_of_ratios": float(np.mean(ratios)),
            "retention_ratio_of_means": float(np.mean(linear_slopes) / np.mean(raw_slopes)),
            "retention_ratio_q025": float(np.quantile(ratios, 0.025)),
            "retention_ratio_median": float(np.median(ratios)),
            "retention_ratio_q975": float(np.quantile(ratios, 0.975)),
            "raw_corr": float(np.mean([row["raw_corr"] for row in group])),
            "linear_corr": float(np.mean([row["linear_corr"] for row in group])),
        }

    payload = {
        **results,
        "summaries": summaries,
        "health_retention": {
            "definition": "per-seed post-change slope retention in original sensor 2; S4 is context-collinear during calibration and S4u is an unconfounded health-only control",
            "rows": health_rows,
            "summary": health_summaries,
        },
    }
    OUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    # quick summary
    for mech in mechanisms:
        rows = results[mech]
        for mon in monitors:
            for cond in ("raw", "linear"):
                sub = [r for r in rows if r["monitor"] == mon and r["conditioning"] == cond and r["threshold_branch"] == "reference_deviation"]
                det = sum(1 for r in sub if r["post_any_alert"])
                pre = sum(r["pre_alerts"] for r in sub)
                print(f"  {mech} {mon} {cond}: detected {det}/{len(sub)}, pre-alerts {pre}", flush=True)
    print(
        "  health mean-of-ratios: "
        + ", ".join(
            f"{key}={value['retention_mean_of_ratios']:.3f}"
            for key, value in payload["health_retention"]["summary"].items()
        ),
        flush=True,
    )
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
