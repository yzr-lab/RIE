"""Execute the prespecified strict-replay sensitivity and 2x2 audits."""

from __future__ import annotations

import json
import sys
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.data import load_cmapss_observed  # noqa: E402
from rineng_replay.evaluation import (  # noqa: E402
    join_training_endpoints,
    ranking_metrics,
    summarize_alert_workload,
)
from rineng_replay.monitors import MONITOR_NAMES  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402
from rineng_replay.protocol import ReplayConfig  # noqa: E402
from rineng_replay.replay import score_trajectory  # noqa: E402


DATA_ROOT = resolve_cmapss_root(ROOT)
AUDIT_DIR = ROOT / "logs" / "audits"
CACHE_DIR = ROOT / "logs" / "sensitivities" / "cache"
PRIMARY_MANIFEST = ROOT / "logs" / "scores" / "primary_score_manifest.json"
HORIZON = 125


def _load_config() -> ReplayConfig:
    payload = yaml.safe_load(
        (ROOT / "configs" / "primary_protocol.yaml").read_text(encoding="utf-8")
    )
    return ReplayConfig(
        **{
            key: payload[key]
            for key in (
                "calibration_cycles",
                "window_size",
                "step",
                "persistence",
                "max_lag",
                "selector_m",
                "aggregation_k",
                "min_monitor_windows",
            )
        }
    )


def _load_trajectories() -> list:
    records: list = []
    for subset in ("FD001", "FD002", "FD003", "FD004"):
        records.extend(load_cmapss_observed(DATA_ROOT, subset, "train", None))
    return records


def _score_cached(
    key: str,
    trajectories: list,
    config: ReplayConfig,
    conditionings: tuple[str, ...],
    monitor_names: tuple[str, ...],
) -> pd.DataFrame:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    path = CACHE_DIR / f"{key}.csv.gz"
    meta_path = CACHE_DIR / f"{key}.json"
    expected = {
        "config": asdict(config),
        "conditionings": list(conditionings),
        "monitor_names": list(monitor_names),
    }
    if path.exists() and meta_path.exists():
        if json.loads(meta_path.read_text(encoding="utf-8")) == expected:
            print(f"Reusing sensitivity cache: {key}")
            return pd.read_csv(path)
    rows: list[dict] = []
    for index, trajectory in enumerate(trajectories, start=1):
        for conditioning in conditionings:
            result = score_trajectory(
                trajectory,
                config,
                conditioning=conditioning,
                monitor_names=monitor_names,
            )
            for records in result.records.values():
                rows.extend(asdict(record) for record in records)
        if index % 50 == 0 or index == len(trajectories):
            print(f"{key}: {index}/{len(trajectories)} engines")
    frame = pd.DataFrame(rows)
    endpoints = pd.DataFrame(
        [
            {
                "subset": item.subset,
                "engine_id": item.engine_id,
                "max_cycle": int(item.cycles[-1]),
            }
            for item in trajectories
        ]
    )
    frame = frame.merge(endpoints, on=["subset", "engine_id"], validate="many_to_one")
    frame["rul"] = frame["max_cycle"] - frame["score_time"]
    frame["event_label"] = frame["rul"] <= HORIZON
    frame.to_csv(path, index=False, compression="gzip")
    meta_path.write_text(
        json.dumps(expected, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return frame


def _summary_row(
    frame: pd.DataFrame,
    *,
    subset: str,
    monitor: str,
    conditioning: str,
    horizon: int,
) -> dict:
    group = frame[
        (frame["monitor"] == monitor)
        & (frame["conditioning"] == conditioning)
    ]
    if subset != "ALL":
        group = group[group["subset"] == subset]
    ranking = ranking_metrics(group)
    workload = summarize_alert_workload(group, horizon=horizon)
    return {
        "subset": subset,
        "monitor": monitor,
        "conditioning": conditioning,
        **ranking,
        **workload,
    }


def _write_context_sensitivity(
    primary: pd.DataFrame,
    trajectories: list,
    config: ReplayConfig,
) -> None:
    extra = _score_cached(
        "context_quadratic_regime",
        trajectories,
        config,
        ("quadratic", "regime"),
        MONITOR_NAMES,
    )
    combined = pd.concat([primary, extra], ignore_index=True, sort=False)
    rows: list[dict] = []
    for conditioning in ("raw", "linear", "quadratic", "regime"):
        for monitor in MONITOR_NAMES:
            for subset in ("ALL", "FD001", "FD002", "FD003", "FD004"):
                rows.append(
                    _summary_row(
                        combined,
                        subset=subset,
                        monitor=monitor,
                        conditioning=conditioning,
                        horizon=HORIZON,
                    )
                )
    pd.DataFrame(rows).to_csv(AUDIT_DIR / "context_model_sensitivity.csv", index=False)


def _write_step_horizon_sensitivity(
    primary: pd.DataFrame,
    trajectories: list,
    config: ReplayConfig,
) -> None:
    rows: list[dict] = []
    step_frames = {10: primary}
    for step in (5, 20):
        step_frames[step] = _score_cached(
            f"step_{step}",
            trajectories,
            replace(config, step=step),
            ("raw", "linear"),
            MONITOR_NAMES,
        )
    for step, frame in step_frames.items():
        for monitor in MONITOR_NAMES:
            for conditioning in ("raw", "linear"):
                rows.append(
                    {
                        "analysis": "step",
                        "step": step,
                        "horizon": np.nan,
                        **_summary_row(
                            frame,
                            subset="ALL",
                            monitor=monitor,
                            conditioning=conditioning,
                            horizon=HORIZON,
                        ),
                    }
                )
    for horizon in (100, 125, 150):
        relabeled = primary.copy()
        relabeled["event_label"] = relabeled["rul"] <= horizon
        for monitor in MONITOR_NAMES:
            for conditioning in ("raw", "linear"):
                rows.append(
                    {
                        "analysis": "horizon",
                        "step": np.nan,
                        "horizon": horizon,
                        **_summary_row(
                            relabeled,
                            subset="ALL",
                            monitor=monitor,
                            conditioning=conditioning,
                            horizon=horizon,
                        ),
                    }
                )
    pd.DataFrame(rows).to_csv(AUDIT_DIR / "step_horizon_sensitivity.csv", index=False)


def _write_selector_sensitivity(
    primary: pd.DataFrame,
    trajectories: list,
    config: ReplayConfig,
) -> None:
    rows: list[dict] = []
    grid = ((5, 5), (10, 5), (20, 5), (40, 5), (20, 3), (20, 10), (20, 20))
    for selector_m, aggregation_k in grid:
        if (selector_m, aggregation_k) == (
            config.selector_m,
            config.aggregation_k,
        ):
            branch = primary[primary["monitor"] == "ldsi"]
        else:
            branch = _score_cached(
                f"selector_m{selector_m}_k{aggregation_k}",
                trajectories,
                replace(config, selector_m=selector_m, aggregation_k=aggregation_k),
                ("raw", "linear"),
                ("ldsi",),
            )
        for conditioning in ("raw", "linear"):
            rows.append(
                {
                    "selector_m": selector_m,
                    "aggregation_k": aggregation_k,
                    **_summary_row(
                        branch,
                        subset="ALL",
                        monitor="ldsi",
                        conditioning=conditioning,
                        horizon=HORIZON,
                    ),
                }
            )
    pd.DataFrame(rows).to_csv(AUDIT_DIR / "selector_m_k_sensitivity.csv", index=False)


def _write_length_sensitivity(primary: pd.DataFrame) -> None:
    engine_lengths = (
        primary[["subset", "engine_id", "max_cycle"]]
        .drop_duplicates()
        .copy()
    )
    engine_lengths["length_quartile"] = pd.qcut(
        engine_lengths["max_cycle"],
        4,
        labels=["Q1", "Q2", "Q3", "Q4"],
    )
    frame = primary.merge(
        engine_lengths[["subset", "engine_id", "length_quartile"]],
        on=["subset", "engine_id"],
        validate="many_to_one",
    )
    rows: list[dict] = []
    for subset in ("FD001", "FD002", "FD003", "FD004"):
        for quartile in ("Q1", "Q2", "Q3", "Q4"):
            cell = frame[
                (frame["subset"] == subset)
                & (frame["length_quartile"] == quartile)
            ]
            for monitor in MONITOR_NAMES:
                for conditioning in ("raw", "linear"):
                    group = cell[
                        (cell["monitor"] == monitor)
                        & (cell["conditioning"] == conditioning)
                    ]
                    if len(group) == 0:
                        continue
                    rows.append(
                        {
                            "subset": subset,
                            "length_quartile": quartile,
                            "monitor": monitor,
                            "conditioning": conditioning,
                            **ranking_metrics(group),
                            **summarize_alert_workload(group, horizon=HORIZON),
                        }
                    )
    pd.DataFrame(rows).to_csv(AUDIT_DIR / "length_stratified_sensitivity.csv", index=False)


def _engine_auc(frame: pd.DataFrame) -> pd.DataFrame:
    from sklearn.metrics import roc_auc_score

    rows: list[dict] = []
    for keys, group in frame.groupby(
        ["subset", "engine_id", "monitor", "conditioning"], sort=True
    ):
        labels = group["event_label"].to_numpy(dtype=int)
        if len(np.unique(labels)) < 2:
            continue
        rows.append(
            {
                "subset": keys[0],
                "engine_id": keys[1],
                "monitor": keys[2],
                "conditioning": keys[3],
                "auc": float(roc_auc_score(labels, group["score"])),
            }
        )
    return pd.DataFrame(rows)


def _write_2x2(primary: pd.DataFrame) -> None:
    engine = _engine_auc(primary)
    payload: dict[str, object] = {
        "definition": "difference-in-differences on paired per-engine AUC gains: (FD004-FD003)-(FD002-FD001)",
        "n_bootstrap": 1000,
        "seed": 20260819,
        "monitors": {},
    }
    rng = np.random.default_rng(20260819)
    for monitor in MONITOR_NAMES:
        subset = engine[engine["monitor"] == monitor]
        pivot = subset.pivot_table(
            index=["subset", "engine_id"],
            columns="conditioning",
            values="auc",
        ).dropna(subset=["raw", "linear"])
        pivot["delta"] = pivot["linear"] - pivot["raw"]
        cells = {
            fd: pivot.xs(fd, level="subset")["delta"].to_numpy(dtype=float)
            for fd in ("FD001", "FD002", "FD003", "FD004")
        }
        means = {fd: float(np.mean(values)) for fd, values in cells.items()}
        interaction = (means["FD004"] - means["FD003"]) - (
            means["FD002"] - means["FD001"]
        )
        samples = np.empty(1000, dtype=float)
        for index in range(len(samples)):
            sampled = {
                fd: float(np.mean(rng.choice(values, len(values), replace=True)))
                for fd, values in cells.items()
            }
            samples[index] = (sampled["FD004"] - sampled["FD003"]) - (
                sampled["FD002"] - sampled["FD001"]
            )
        low = min(float(np.quantile(samples, 0.025)), interaction)
        high = max(float(np.quantile(samples, 0.975)), interaction)
        payload["monitors"][monitor] = {
            "cell_mean_delta_auc": means,
            "cell_engine_counts": {fd: len(values) for fd, values in cells.items()},
            "single_to_multi_one_fault": means["FD002"] - means["FD001"],
            "single_to_multi_two_fault": means["FD004"] - means["FD003"],
            "interaction": float(interaction),
            "interaction_ci_low": low,
            "interaction_ci_high": high,
        }
    (AUDIT_DIR / "fd_2x2_interaction.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def main() -> None:
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)
    config = _load_config()
    trajectories = _load_trajectories()
    primary, _ = join_training_endpoints(
        PRIMARY_MANIFEST, DATA_ROOT, horizon=HORIZON
    )
    _write_context_sensitivity(primary, trajectories, config)
    _write_step_horizon_sensitivity(primary, trajectories, config)
    _write_selector_sensitivity(primary, trajectories, config)
    _write_length_sensitivity(primary)
    _write_2x2(primary)
    print("Completed strict sensitivity and 2x2 audits")


if __name__ == "__main__":
    main()
