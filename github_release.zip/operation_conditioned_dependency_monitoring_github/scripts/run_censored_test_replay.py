"""Score and evaluate the official C-MAPSS censored test trajectories."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from dataclasses import asdict, fields
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.censored import (  # noqa: E402
    join_official_test_endpoints,
    score_censored_trajectory,
)
from rineng_replay.data import load_cmapss_observed  # noqa: E402
from rineng_replay.evaluation import ranking_metrics, summarize_alert_workload  # noqa: E402
from rineng_replay.ledger import write_score_ledger  # noqa: E402
from rineng_replay.monitors import MONITOR_NAMES  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402
from rineng_replay.protocol import ReplayConfig, window_count  # noqa: E402


DATA_ROOT = resolve_cmapss_root(ROOT)
SUBSETS = ("FD001", "FD002", "FD003", "FD004")
CONDITIONINGS = ("raw", "linear")
HORIZON = 125


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_protocol() -> tuple[ReplayConfig, str]:
    payload = yaml.safe_load(
        (ROOT / "configs" / "primary_protocol.yaml").read_text(encoding="utf-8")
    )
    names = {item.name for item in fields(ReplayConfig)}
    config = ReplayConfig(**{key: payload[key] for key in names})
    digest = json.loads(
        (ROOT / "configs" / "protocol_hash.json").read_text(encoding="utf-8")
    )["protocol_sha256"]
    return config, digest


def _clean(value):
    if isinstance(value, dict):
        return {str(key): _clean(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_clean(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return None if not math.isfinite(number) else number
    return value


def _score_test(
    config: ReplayConfig,
    protocol_hash: str,
    *,
    smoke: bool,
    engines_per_fd: int,
) -> Path:
    run_name = "test_censored_smoke" if smoke else "test_censored"
    score_dir = ROOT / "logs" / "scores" / run_name
    score_dir.mkdir(parents=True, exist_ok=True)
    partitions = {
        (subset, conditioning, monitor): []
        for subset in SUBSETS
        for conditioning in CONDITIONINGS
        for monitor in MONITOR_NAMES
    }
    flow_rows: list[dict] = []
    total_loaded = 0
    for subset in SUBSETS:
        trajectories = load_cmapss_observed(DATA_ROOT, subset, "test", None)
        if smoke:
            trajectories = [
                item
                for item in trajectories
                if window_count(len(item.cycles), config) >= config.min_monitor_windows
            ][:engines_per_fd]
        total_loaded += len(trajectories)
        for index, trajectory in enumerate(trajectories, start=1):
            raw_audit = None
            for conditioning in CONDITIONINGS:
                result = score_censored_trajectory(
                    trajectory, config, conditioning=conditioning
                )
                if conditioning == "raw":
                    raw_audit = result.audit
                for monitor, records in result.records.items():
                    partitions[(subset, conditioning, monitor)].extend(records)
            if raw_audit is None:
                raise RuntimeError("raw censored audit is missing")
            flow_rows.append(
                {
                    "subset": subset,
                    "engine_id": trajectory.engine_id,
                    "observed_end": int(trajectory.cycles[-1]),
                    "monitor_windows": raw_audit.monitor_windows,
                    "monitorable": raw_audit.monitorable,
                }
            )
            if index % 25 == 0 or index == len(trajectories):
                print(f"{run_name}: {subset} {index}/{len(trajectories)}")

    manifests: list[dict] = []
    for (subset, conditioning, monitor), records in sorted(partitions.items()):
        locked = write_score_ledger(
            records,
            score_dir / f"{subset}_{conditioning}_{monitor}.jsonl",
            protocol_hash,
        )
        manifests.append(asdict(locked))
    flow_path = ROOT / "logs" / "audits" / f"{run_name}_monitorability.csv"
    flow_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(flow_rows).to_csv(flow_path, index=False)
    monitorable = int(pd.DataFrame(flow_rows)["monitorable"].sum())
    manifest_path = ROOT / "logs" / "scores" / f"{run_name}_score_manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "run_name": run_name,
                "source_split": "test",
                "protocol_sha256": protocol_hash,
                "total_loaded_engines": total_loaded,
                "monitorable_engines": monitorable,
                "score_rows": int(sum(item["row_count"] for item in manifests)),
                "partitions": manifests,
                "monitorability_audit": {
                    "path": flow_path.as_posix(),
                    "sha256": _sha256(flow_path),
                },
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    return manifest_path


def _evaluate_test(manifest_path: Path, *, smoke: bool) -> None:
    joined, manifest = join_official_test_endpoints(
        manifest_path, DATA_ROOT, horizon=HORIZON
    )
    rows: list[dict] = []
    per_engine: list[dict] = []
    for monitor in MONITOR_NAMES:
        for conditioning in CONDITIONINGS:
            base = joined[
                (joined["monitor"] == monitor)
                & (joined["conditioning"] == conditioning)
            ]
            for subset in ("ALL", *SUBSETS):
                group = base if subset == "ALL" else base[base["subset"] == subset]
                if len(group) == 0:
                    continue
                trajectories = group.groupby(["subset", "engine_id"], sort=True)
                observed_alert_rate = float(
                    trajectories["persistent_alert"].any().mean()
                )
                near_censor_changes: list[float] = []
                censor_lags: list[float] = []
                for (fd, engine_id), engine in trajectories:
                    ordered = engine.sort_values("score_time")
                    near_censor_changes.append(
                        float(ordered["score"].iloc[-1] - ordered["score"].iloc[0])
                    )
                    censor_lags.append(
                        float(ordered["observed_end"].iloc[0] - ordered["score_time"].iloc[-1])
                    )
                    if subset == "ALL":
                        per_engine.append(
                            {
                                "subset": fd,
                                "engine_id": engine_id,
                                "monitor": monitor,
                                "conditioning": conditioning,
                                "observed_end": float(ordered["observed_end"].iloc[0]),
                                "official_additional_rul": float(ordered["additional_rul"].iloc[0]),
                                "last_score_time": float(ordered["score_time"].iloc[-1]),
                                "any_persistent_alert": bool(ordered["persistent_alert"].any()),
                                "near_censor_score_change": near_censor_changes[-1],
                            }
                        )
                rows.append(
                    {
                        "subset": subset,
                        "monitor": monitor,
                        "conditioning": conditioning,
                        "observed_alert_engine_rate": observed_alert_rate,
                        "near_censor_score_change_mean": float(np.mean(near_censor_changes)),
                        "near_censor_score_change_median": float(np.median(near_censor_changes)),
                        "last_score_to_censor_lag_mean": float(np.mean(censor_lags)),
                        **ranking_metrics(group),
                        **summarize_alert_workload(group, horizon=HORIZON),
                    }
                )
    output_dir = ROOT / "logs" / "evaluations"
    output_dir.mkdir(parents=True, exist_ok=True)
    suffix = "_smoke" if smoke else ""
    per_engine_path = output_dir / f"test_censored_per_engine{suffix}.csv"
    pd.DataFrame(per_engine).to_csv(per_engine_path, index=False)
    output_path = output_dir / f"test_censored_metrics{suffix}.json"
    output_path.write_text(
        json.dumps(
            _clean(
                {
                    "schema_version": "1.0",
                    "protocol_sha256": manifest["protocol_sha256"],
                    "score_manifest_sha256": _sha256(manifest_path),
                    "interpretation": "official truncated-trajectory audit, not a complete run-to-failure lead experiment",
                    "evaluation_horizon_cycles": HORIZON,
                    "total_test_engines": manifest["total_loaded_engines"],
                    "monitorable_test_engines": manifest["monitorable_engines"],
                    "score_rows": manifest["score_rows"],
                    "metrics": rows,
                    "per_engine_path": per_engine_path.as_posix(),
                    "per_engine_sha256": _sha256(per_engine_path),
                }
            ),
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    print(
        f"Locked censored test audit: {manifest['monitorable_engines']}/"
        f"{manifest['total_loaded_engines']} engines, {manifest['score_rows']} rows"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--engines-per-fd", type=int, default=1)
    args = parser.parse_args()
    config, protocol_hash = _load_protocol()
    manifest_path = _score_test(
        config,
        protocol_hash,
        smoke=args.smoke,
        engines_per_fd=args.engines_per_fd,
    )
    _evaluate_test(manifest_path, smoke=args.smoke)


if __name__ == "__main__":
    main()
