"""Run the strict training replay and lock partitioned score ledgers."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict, fields
from pathlib import Path

import pandas as pd
import yaml


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.data import load_cmapss_observed  # noqa: E402
from rineng_replay.ledger import (  # noqa: E402
    LedgerManifest,
    verify_locked_ledger,
    write_score_ledger,
)
from rineng_replay.monitors import MONITOR_NAMES  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402
from rineng_replay.protocol import ReplayConfig, window_count  # noqa: E402
from rineng_replay.replay import score_trajectory  # noqa: E402


DATA_ROOT = resolve_cmapss_root(ROOT)
SUBSETS = ("FD001", "FD002", "FD003", "FD004")
CONDITIONINGS = ("raw", "linear")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_protocol() -> tuple[ReplayConfig, str]:
    payload = yaml.safe_load(
        (ROOT / "configs" / "primary_protocol.yaml").read_text(encoding="utf-8")
    )
    config_fields = {item.name for item in fields(ReplayConfig)}
    config = ReplayConfig(**{key: payload[key] for key in config_fields})
    digest = json.loads(
        (ROOT / "configs" / "protocol_hash.json").read_text(encoding="utf-8")
    )["protocol_sha256"]
    return config, digest


def _select_smoke(records: list, config: ReplayConfig, count: int) -> list:
    selected = [
        record
        for record in records
        if window_count(len(record.cycles), config) >= config.min_monitor_windows
    ]
    return selected[:count]


def _validate_run_manifest(manifest_path: Path, protocol_hash: str) -> None:
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if payload["protocol_sha256"] != protocol_hash:
        raise RuntimeError("run manifest uses a different protocol hash")
    for item in payload["partitions"]:
        manifest = LedgerManifest(**item)
        verify_locked_ledger(Path(item["path"]), manifest)
    for audit in payload["audits"]:
        if _sha256(Path(audit["path"])) != audit["sha256"]:
            raise RuntimeError(f"audit hash mismatch: {audit['path']}")
    print(
        f"Validated {len(payload['partitions'])} partitions, "
        f"{payload['score_rows']} rows, protocol {protocol_hash}"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--engines-per-fd", type=int, default=1)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    config, protocol_hash = _load_protocol()
    run_name = "smoke" if args.smoke else "primary"
    score_dir = ROOT / "logs" / "scores" / run_name
    score_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = (
        ROOT / "logs" / "scores" / f"{run_name}_score_manifest.json"
    )
    if args.validate_only:
        _validate_run_manifest(manifest_path, protocol_hash)
        return
    if manifest_path.exists() and not args.force:
        existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        if existing.get("protocol_sha256") == protocol_hash:
            print(f"Verified run manifest already exists: {manifest_path}")
            return

    partitions: dict[tuple[str, str, str], list] = {}
    for subset in SUBSETS:
        for conditioning in CONDITIONINGS:
            for monitor in MONITOR_NAMES:
                partitions[(subset, conditioning, monitor)] = []
    monitorability_rows: list[dict] = []
    support_rows: list[dict] = []

    for subset in SUBSETS:
        trajectories = load_cmapss_observed(
            DATA_ROOT, subset, "train", engine_ids=None
        )
        if args.smoke:
            trajectories = _select_smoke(
                trajectories, config, args.engines_per_fd
            )
        for index, trajectory in enumerate(trajectories, start=1):
            raw_audit = None
            for conditioning in CONDITIONINGS:
                result = score_trajectory(
                    trajectory, config, conditioning=conditioning
                )
                if conditioning == "raw":
                    raw_audit = result.audit
                support_rows.append(asdict(result.audit))
                for monitor, records in result.records.items():
                    partitions[(subset, conditioning, monitor)].extend(records)
            if raw_audit is None:
                raise RuntimeError("raw replay audit was not produced")
            monitorability_rows.append(
                {
                    "subset": subset,
                    "engine_id": trajectory.engine_id,
                    "monitor_windows": raw_audit.monitor_windows,
                    "monitorable": raw_audit.monitorable,
                    "exclusion_reason": "" if raw_audit.monitorable else "fewer_than_min_monitor_windows",
                }
            )
            if index % 25 == 0 or index == len(trajectories):
                print(f"{run_name}: {subset} {index}/{len(trajectories)} engines")

    ledger_manifests: list[dict] = []
    for (subset, conditioning, monitor), records in sorted(partitions.items()):
        path = score_dir / f"{subset}_{conditioning}_{monitor}.jsonl"
        manifest = write_score_ledger(records, path, protocol_hash)
        ledger_manifests.append(asdict(manifest))

    monitorability_path = ROOT / "logs" / "audits" / (
        "monitorability_flow.csv" if run_name == "primary" else "smoke_monitorability_flow.csv"
    )
    support_path = ROOT / "logs" / "audits" / (
        "conditioning_support.csv" if run_name == "primary" else "smoke_conditioning_support.csv"
    )
    monitorability_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(monitorability_rows).to_csv(monitorability_path, index=False)
    pd.DataFrame(support_rows).to_csv(support_path, index=False)
    monitorable_count = int(
        pd.DataFrame(monitorability_rows)["monitorable"].sum()
    )
    if not args.smoke and monitorable_count != 696:
        raise RuntimeError(
            f"strict denominator changed: expected 696 monitorable engines, found {monitorable_count}"
        )
    payload = {
        "schema_version": "1.0",
        "run_name": run_name,
        "protocol_sha256": protocol_hash,
        "source_split": "train",
        "subsets": list(SUBSETS),
        "conditionings": list(CONDITIONINGS),
        "monitors": list(MONITOR_NAMES),
        "total_loaded_engines": len(monitorability_rows),
        "monitorable_engines": monitorable_count,
        "score_rows": int(sum(item["row_count"] for item in ledger_manifests)),
        "partitions": ledger_manifests,
        "audits": [
            {
                "path": monitorability_path.as_posix(),
                "sha256": _sha256(monitorability_path),
            },
            {
                "path": support_path.as_posix(),
                "sha256": _sha256(support_path),
            },
        ],
    }
    manifest_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        f"Locked {payload['score_rows']} score rows for "
        f"{monitorable_count}/{len(monitorability_rows)} engines"
    )


if __name__ == "__main__":
    main()
