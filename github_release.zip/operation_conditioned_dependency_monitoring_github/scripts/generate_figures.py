"""Generate deterministic publication figures from logs/main_metrics.json."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.evaluation import join_training_endpoints  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402


METRICS_PATH = ROOT / "logs/main_metrics.json"
FIGURE_DIR = ROOT / "figures"
DATA_ROOT = resolve_cmapss_root(ROOT)
PRIMARY_MANIFEST = ROOT / "logs" / "scores" / "primary_score_manifest.json"


COLORS = {
    "navy": "#17365D",
    "blue": "#3F6FA3",
    "blue_light": "#DCE8F3",
    "teal": "#16847D",
    "teal_light": "#DCEFEB",
    "orange": "#D97721",
    "orange_light": "#F8E8D7",
    "red": "#B64B4B",
    "grey": "#66727D",
    "grey_mid": "#A9B1B8",
    "grey_light": "#EEF1F3",
    "black": "#20262C",
    "white": "#FFFFFF",
}
MONITOR_COLORS = {
    "ldsi": "#17365D",
    "dynamic_corr": "#16847D",
    "mewma": "#8C6BB1",
    "mcusum": "#D97721",
    "var1": "#B64B4B",
}
DISPLAY = {
    "ldsi": "LDSI",
    "dynamic_corr": "Dyn. corr.",
    "mewma": "MEWMA",
    "mcusum": "MCUSUM",
    "var1": "VAR(1)",
}


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "font.size": 7.5,
        "axes.labelsize": 8,
        "axes.titlesize": 8.5,
        "axes.titleweight": "bold",
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "legend.fontsize": 7,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.7,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "legend.frameon": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
    }
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _save(fig: plt.Figure, stem: str) -> list[Path]:
    paths = [FIGURE_DIR / f"{stem}.{suffix}" for suffix in ("pdf", "svg", "png")]
    fig.savefig(paths[0], bbox_inches="tight", pad_inches=0.03)
    fig.savefig(paths[1], bbox_inches="tight", pad_inches=0.03)
    fig.savefig(paths[2], dpi=600, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)
    return paths


def _panel(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.10,
        1.06,
        label,
        transform=ax.transAxes,
        fontsize=9,
        fontweight="bold",
        va="top",
        ha="left",
    )


def _rounded(ax: plt.Axes, xy, width, height, face, edge, radius=0.02, lw=0.9):
    patch = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle=f"round,pad=0.008,rounding_size={radius}",
        transform=ax.transAxes,
        facecolor=face,
        edgecolor=edge,
        linewidth=lw,
    )
    ax.add_patch(patch)
    return patch


def _arrow(ax: plt.Axes, start, end, color=None, lw=1.2):
    arrow = FancyArrowPatch(
        start,
        end,
        transform=ax.transAxes,
        arrowstyle="-|>",
        mutation_scale=10,
        linewidth=lw,
        color=color or COLORS["navy"],
        shrinkA=2,
        shrinkB=2,
    )
    ax.add_patch(arrow)


def figure1_workflow() -> list[Path]:
    fig, ax = plt.subplots(figsize=(7.2, 3.90))
    ax.set_axis_off()
    zones = [
        (0.015, 0.10, 0.27, 0.82, COLORS["blue_light"], COLORS["blue"]),
        (0.34, 0.10, 0.33, 0.82, COLORS["teal_light"], COLORS["teal"]),
        (0.725, 0.10, 0.26, 0.82, "#F5F7F8", COLORS["grey"]),
    ]
    for x, y, w, h, face, edge in zones:
        _rounded(ax, (x, y), w, h, face, edge, radius=0.018, lw=1.0)
    for x, number in ((0.035, "1"), (0.360, "2"), (0.745, "3")):
        ax.add_patch(
            plt.Circle((x, 0.875), 0.021, transform=ax.transAxes, color=COLORS["navy"])
        )
        ax.text(x, 0.875, number, transform=ax.transAxes, color="white", ha="center", va="center", fontweight="bold", fontsize=7.2)

    ax.text(0.16, 0.855, "Mixed-regime\nobservations", transform=ax.transAxes, ha="center", va="top", fontweight="bold", fontsize=7.6, linespacing=1.05)
    ax.text(0.515, 0.855, "Frozen calibration\nand transparent monitors", transform=ax.transAxes, ha="center", va="top", fontweight="bold", fontsize=7.6, linespacing=1.05)
    ax.text(0.865, 0.855, "Evidence and\ngoverned review", transform=ax.transAxes, ha="center", va="top", fontweight="bold", fontsize=7.6, linespacing=1.05)

    rng = np.random.default_rng(12)
    x = np.linspace(0, 1, 80)
    for offset, color, label in ((0.66, COLORS["navy"], "Sensors"), (0.51, COLORS["teal"], "Settings")):
        y = offset + 0.03 * np.sin(12 * x) + 0.012 * rng.normal(size=len(x))
        ax.plot(0.05 + 0.20 * x, y, transform=ax.transAxes, color=color, lw=1.0, clip_on=False)
        ax.text(0.045, offset + 0.055, label, transform=ax.transAxes, color=color, fontsize=7, fontweight="bold")
    for ypos, text in ((0.335, "Single condition"), (0.250, "Multiple conditions"), (0.165, "One / two fault modes")):
        _rounded(ax, (0.055, ypos), 0.19, 0.050, "white", COLORS["grey_mid"], radius=0.012, lw=0.7)
        ax.text(0.15, ypos + 0.025, text, transform=ax.transAxes, ha="center", va="center", fontsize=6.2)

    _rounded(ax, (0.37, 0.59), 0.105, 0.14, "white", COLORS["navy"], radius=0.012)
    ax.text(0.422, 0.675, "Cycles 1–60", transform=ax.transAxes, ha="center", va="center", fontweight="bold", fontsize=7.0)
    ax.text(0.422, 0.625, "fit and freeze", transform=ax.transAxes, ha="center", va="center", color=COLORS["grey"], fontsize=6.0)
    _arrow(ax, (0.48, 0.66), (0.515, 0.66), COLORS["teal"])
    _rounded(ax, (0.52, 0.59), 0.12, 0.14, "white", COLORS["teal"], radius=0.012)
    ax.text(0.58, 0.675, "Context model", transform=ax.transAxes, ha="center", va="center", fontweight="bold", fontsize=7.0)
    ax.text(0.58, 0.625, "raw → residual", transform=ax.transAxes, ha="center", va="center", color=COLORS["grey"], fontsize=6.0)
    _rounded(ax, (0.39, 0.395), 0.22, 0.105, "white", COLORS["teal"], radius=0.012)
    ax.text(0.50, 0.463, "Top-strength relations", transform=ax.transAxes, ha="center", va="center", fontweight="bold", fontsize=6.7)
    ax.text(0.50, 0.422, "M candidates  •  K contributors", transform=ax.transAxes, ha="center", va="center", color=COLORS["grey"], fontsize=5.9)
    monitor_labels = ["LDSI", "Dyn.\ncorr.", "MEWMA", "MCUSUM", "VAR(1)"]
    for index, label in enumerate(monitor_labels):
        xpos = 0.354 + index * 0.061
        _rounded(ax, (xpos, 0.205), 0.055, 0.078, "white", COLORS["blue"], radius=0.010, lw=0.7)
        ax.text(xpos + 0.0275, 0.244, label, transform=ax.transAxes, ha="center", va="center", fontsize=4.5, linespacing=0.92)
    _arrow(ax, (0.285, 0.52), (0.34, 0.52), COLORS["navy"], lw=1.4)
    _arrow(ax, (0.67, 0.52), (0.725, 0.52), COLORS["navy"], lw=1.4)

    _rounded(ax, (0.75, 0.61), 0.21, 0.14, "white", COLORS["teal"], radius=0.012)
    ax.text(0.855, 0.695, "Ranked advisory evidence", transform=ax.transAxes, ha="center", va="center", fontweight="bold", fontsize=7.0)
    ax.text(0.855, 0.645, "score  •  relation cues", transform=ax.transAxes, ha="center", va="center", color=COLORS["grey"], fontsize=6.0)
    _arrow(ax, (0.855, 0.595), (0.855, 0.535), COLORS["teal"])
    _rounded(ax, (0.75, 0.385), 0.21, 0.14, "white", COLORS["navy"], radius=0.012)
    ax.text(0.855, 0.470, "Workload-aware review", transform=ax.transAxes, ha="center", va="center", fontweight="bold", fontsize=7.0)
    ax.text(0.855, 0.420, "lead  ↔  episodes", transform=ax.transAxes, ha="center", va="center", color=COLORS["grey"], fontsize=6.0)
    _rounded(ax, (0.75, 0.165), 0.21, 0.12, COLORS["orange_light"], COLORS["orange"], radius=0.012)
    ax.text(0.855, 0.235, "Local action gate", transform=ax.transAxes, ha="center", va="center", color=COLORS["orange"], fontweight="bold", fontsize=6.0)
    ax.text(0.855, 0.190, "review before action", transform=ax.transAxes, ha="center", va="center", color=COLORS["grey"], fontsize=5.7)
    return _save(fig, "figure1_workflow")


def figure2_timeline() -> list[Path]:
    fig = plt.figure(figsize=(7.2, 3.45))
    ax = fig.add_axes([0.07, 0.16, 0.88, 0.74])
    ax.set_xlim(0, 255)
    ax.set_ylim(0, 2.35)
    ax.set_yticks([])
    ax.set_xlabel("Observed cycle")
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_color(COLORS["grey_mid"])
    ax.axvspan(0, 60, ymin=0.57, ymax=0.86, color=COLORS["blue_light"], zorder=0)
    ax.text(30, 1.98, "Fixed calibration\nfit once and freeze", ha="center", va="center", color=COLORS["navy"], fontweight="bold", fontsize=7.2, linespacing=1.05)
    ax.axvline(60, color=COLORS["navy"], lw=1.0, ls="--")
    ax.text(64, 2.10, "$C=60$", ha="left", va="bottom", color=COLORS["navy"], fontweight="bold", fontsize=7.2)
    for start, end, alpha in ((61, 100, 0.32), (71, 110, 0.42), (81, 120, 0.52), (91, 130, 0.62)):
        ax.add_patch(Rectangle((start, 1.55), end - start, 0.28, facecolor=COLORS["teal"], alpha=alpha, edgecolor=COLORS["teal"], lw=0.6))
        ax.plot(end, 1.48, marker="o", ms=4, mfc="white", mec=COLORS["teal"], mew=1.0)
    ax.text(128, 1.95, "Completed windows", ha="center", va="center", color=COLORS["teal"], fontweight="bold", fontsize=7.2)
    ax.text(128, 1.86, "score only at window end", ha="center", va="center", color=COLORS["grey"], fontsize=6.2)
    ax.text(145, 1.40, "locked score ledger", ha="center", va="center", color=COLORS["navy"], fontweight="bold", fontsize=6.4)

    ax.text(0, 1.25, "Training replay", color=COLORS["black"], fontweight="bold", va="center")
    ax.hlines(1.15, 0, 220, color=COLORS["grey_mid"], lw=1.0)
    ax.plot([220], [1.15], marker="|", ms=10, color=COLORS["black"])
    ax.text(220, 1.00, "run end", ha="center", color=COLORS["grey"], fontsize=6.0)
    ax.annotate("RUL / event labels", xy=(220, 1.15), xytext=(239, 1.15), color=COLORS["orange"], fontweight="bold", fontsize=6.2, ha="center", va="center", arrowprops=dict(arrowstyle="-|>", color=COLORS["orange"], lw=0.9))

    ax.text(0, 0.62, "Official test replay", color=COLORS["black"], fontweight="bold", va="center")
    ax.hlines(0.52, 0, 175, color=COLORS["grey_mid"], lw=1.0)
    ax.axvspan(0, 60, ymin=0.12, ymax=0.30, color=COLORS["blue_light"])
    for end in (100, 110, 120, 130, 140, 150, 160, 170):
        ax.plot(end, 0.52, marker="o", ms=2.8, mfc=COLORS["teal"], mec=COLORS["teal"])
    ax.plot(175, 0.52, marker="|", ms=12, mew=1.2, color=COLORS["red"])
    ax.text(171, 0.34, "observed\ncensor", ha="right", va="top", color=COLORS["red"], fontweight="bold", fontsize=6.0, linespacing=0.95)
    ax.hlines(0.52, 175, 220, color=COLORS["grey_mid"], lw=0.8, ls="--")
    ax.text(199, 0.34, "unobserved\ncontinuation", ha="center", va="top", color=COLORS["grey"], fontsize=6.0, linespacing=0.95)
    ax.text(240, 0.56, "Official RUL\njoined after lock", color=COLORS["orange"], ha="center", va="center", fontweight="bold", fontsize=6.1, linespacing=1.0)
    ax.text(4, 2.31, "Observable scoring layer", color=COLORS["teal"], fontweight="bold", fontsize=7.4, va="top")
    ax.text(240, 2.31, "Evaluation only", color=COLORS["orange"], fontweight="bold", fontsize=7.4, ha="center", va="top")
    ax.axvline(226, color=COLORS["orange"], ls=(0, (2, 2)), lw=1.0, alpha=0.8)
    return _save(fig, "figure2_information_timeline")


def figure3_condition_effects(payload: dict) -> list[Path]:
    fig = plt.figure(figsize=(7.2, 5.75))
    gs = fig.add_gridspec(2, 2, left=0.08, right=0.98, bottom=0.09, top=0.96, wspace=0.34, hspace=0.42)
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])

    gains = pd.DataFrame(payload["multi_vs_single_conditioning_gain"]).set_index("monitor")
    order = list(DISPLAY)
    values = [gains.loc[name, "multi_minus_single_conditioning_gain"] for name in order]
    y = np.arange(len(order))
    colors = [COLORS["teal"] if value >= 0 else COLORS["red"] for value in values]
    ax_a.barh(y, values, color=colors, height=0.62, edgecolor="white")
    ax_a.axvline(0, color=COLORS["grey_mid"], lw=0.8)
    ax_a.set_yticks(y, [DISPLAY[name] for name in order])
    ax_a.invert_yaxis()
    ax_a.set_xlabel("Multi-condition minus single-condition $\Delta$AUC")
    ax_a.set_title("Condition-specific ranking gain", loc="left")
    for yi, value in zip(y, values, strict=True):
        ax_a.text(value + 0.004, yi, f"{value:+.3f}", va="center", fontsize=6.8, color=COLORS["black"])
    _panel(ax_a, "a")

    interaction = payload["sensitivity_audits"]["fd_2x2"]["monitors"]
    matrix = np.array(
        [[interaction[name]["cell_mean_delta_auc"][fd] for fd in ("FD001", "FD002", "FD003", "FD004")] for name in order]
    )
    limit = max(abs(matrix.min()), abs(matrix.max()), 0.01)
    image = ax_b.imshow(matrix, cmap="RdBu_r", vmin=-limit, vmax=limit, aspect="auto")
    ax_b.set_xticks(range(4), ["FD001\n1 cond./1 fault", "FD002\nMulti/1", "FD003\n1/2", "FD004\nMulti/2"], fontsize=6.3)
    ax_b.set_yticks(range(len(order)), [DISPLAY[name] for name in order])
    for row in range(matrix.shape[0]):
        for col in range(matrix.shape[1]):
            ax_b.text(col, row, f"{matrix[row, col]:+.3f}", ha="center", va="center", fontsize=6.2, color="white" if abs(matrix[row, col]) > 0.55 * limit else COLORS["black"])
    ax_b.set_title("Paired AUC effect across the 2×2 design", loc="left")
    colorbar = fig.colorbar(image, ax=ax_b, fraction=0.035, pad=0.03)
    colorbar.set_label("Linear minus raw AUC", fontsize=6.5)
    _panel(ax_b, "b")

    protocol = pd.DataFrame(payload["protocol_summary"])
    xpos = np.array([0, 1])
    end_labels = []
    energy_entries = []
    for _, row in protocol.iterrows():
        multi = row["condition_group"] == "multi-condition"
        color = COLORS["teal"] if multi else COLORS["grey"]
        marker = "s" if multi else "o"
        values_pair = [row["median_condition_association_before"], row["median_condition_association_after"]]
        ax_c.plot(xpos, values_pair, color=color, lw=1.5, marker=marker, ms=4, mfc="white" if not multi else color, mec=color)
        end_labels.append((row["subset"], values_pair[1], color))
        energy_entries.append(f"{row['subset']} {row['median_residual_energy_ratio']:.3f}")
    for (subset, actual_y, color), label_y in zip(
        sorted(end_labels, key=lambda item: item[1], reverse=True),
        (0.18, 0.14, 0.10, 0.06),
        strict=True,
    ):
        ax_c.plot([1.0, 1.05], [actual_y, label_y], color=color, lw=0.55, alpha=0.8)
        ax_c.text(1.07, label_y, subset, va="center", fontsize=6.0, color=color, fontweight="bold")
    ax_c.set_xlim(-0.12, 1.46)
    ax_c.set_ylim(0, 1.0)
    ax_c.set_xticks(xpos, ["Raw", "Linear residual"])
    ax_c.set_ylabel("Median max |setting correlation|")
    ax_c.set_title("Context removal and signal-retention audit", loc="left")
    ax_c.text(0.02, 0.96, "Unsupported monitoring rows: 0.0% median", transform=ax_c.transAxes, va="top", fontsize=6.5, color=COLORS["grey"])
    ax_c.text(
        0.98,
        0.62,
        "Residual-energy ratio  $E_r/E_x$\n" + "   ".join(energy_entries[:2]) + "\n" + "   ".join(energy_entries[2:]),
        transform=ax_c.transAxes,
        ha="right",
        va="top",
        fontsize=5.7,
        color=COLORS["grey"],
        bbox=dict(boxstyle="round,pad=0.28", facecolor="white", edgecolor=COLORS["grey_mid"], linewidth=0.55),
    )
    _panel(ax_c, "c")

    context = pd.DataFrame(payload["sensitivity_audits"]["context_model"])
    context = context[context["subset"] == "ALL"]
    branches = ["raw", "linear", "regime", "quadratic"]
    for monitor in order:
        rows = context[context["monitor"] == monitor].set_index("conditioning")
        aucs = [rows.loc[branch, "engine_macro_auc"] for branch in branches]
        ax_d.plot(range(len(branches)), aucs, marker="o", ms=3.5, lw=1.35, color=MONITOR_COLORS[monitor], label=DISPLAY[monitor])
    ax_d.set_xticks(range(len(branches)), ["Raw", "Linear", "Regime", "Quadratic"])
    ax_d.set_ylabel("Engine-macro AUC")
    ax_d.set_ylim(0.45, 1.03)
    ax_d.set_title("Model-form robustness", loc="left")
    ax_d.legend(ncol=2, loc="lower right", columnspacing=0.8, handlelength=1.5)
    _panel(ax_d, "d")
    return _save(fig, "figure3_condition_effects")


def figure4_lead_workload(payload: dict) -> list[Path]:
    fig = plt.figure(figsize=(7.2, 5.55))
    gs = fig.add_gridspec(2, 2, left=0.08, right=0.98, bottom=0.10, top=0.96, wspace=0.35, hspace=0.40)
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])

    frontier = pd.DataFrame(payload["threshold_frontier"])
    ldsi = frontier[frontier["monitor"] == "ldsi"]
    for conditioning, color, marker in (("raw", COLORS["grey"], "o"), ("linear", COLORS["teal"], "s")):
        group = ldsi[ldsi["conditioning"] == conditioning].sort_values("threshold_multiplier")
        ax_a.plot(group["pre_proxy_episode_rate_per_engine"], group["pre_proxy_advance_fleet_zero_filled"], color=color, marker=marker, ms=4, lw=1.5, label="Raw" if conditioning == "raw" else "Conditioned")
        for _, row in group.iterrows():
            if row["threshold_multiplier"] in {0.75, 1.0, 2.0}:
                ax_a.annotate(f"×{row['threshold_multiplier']:.2g}", (row["pre_proxy_episode_rate_per_engine"], row["pre_proxy_advance_fleet_zero_filled"]), xytext=(3, 3), textcoords="offset points", fontsize=6, color=color)
    ax_a.set_xlabel("Pre-proxy episodes per engine")
    ax_a.set_ylabel("Proxy advance (cycles)")
    ax_a.set_title("LDSI threshold frontier", loc="left")
    ax_a.legend(loc="best")
    _panel(ax_a, "a")

    metrics = pd.DataFrame(payload["metrics"])
    metrics = metrics[metrics["scope"] == "ALL"]
    for monitor in DISPLAY:
        raw = metrics[(metrics["monitor"] == monitor) & (metrics["conditioning"] == "raw")].iloc[0]
        conditioned = metrics[(metrics["monitor"] == monitor) & (metrics["conditioning"] == "linear")].iloc[0]
        ax_b.annotate("", xy=(conditioned["pre_proxy_episode_rate_per_engine"], conditioned["pre_proxy_advance_fleet_zero_filled"]), xytext=(raw["pre_proxy_episode_rate_per_engine"], raw["pre_proxy_advance_fleet_zero_filled"]), arrowprops=dict(arrowstyle="-|>", color=MONITOR_COLORS[monitor], lw=1.0, alpha=0.85))
        ax_b.scatter(raw["pre_proxy_episode_rate_per_engine"], raw["pre_proxy_advance_fleet_zero_filled"], s=28, facecolor="white", edgecolor=MONITOR_COLORS[monitor], linewidth=1.1, marker="o")
        ax_b.scatter(conditioned["pre_proxy_episode_rate_per_engine"], conditioned["pre_proxy_advance_fleet_zero_filled"], s=28, facecolor=MONITOR_COLORS[monitor], edgecolor="white", linewidth=0.5, marker="s")
        ax_b.text(conditioned["pre_proxy_episode_rate_per_engine"] + 0.006, conditioned["pre_proxy_advance_fleet_zero_filled"] + 0.25, DISPLAY[monitor], fontsize=6.2, color=MONITOR_COLORS[monitor])
    ax_b.set_xlabel("Pre-proxy episodes per engine")
    ax_b.set_ylabel("Proxy advance (cycles)")
    ax_b.set_title("Locked operating points", loc="left")
    ax_b.legend(handles=[Line2D([0], [0], marker="o", color="none", markeredgecolor=COLORS["grey"], markerfacecolor="white", label="Raw"), Line2D([0], [0], marker="s", color="none", markeredgecolor="white", markerfacecolor=COLORS["grey"], label="Conditioned")], loc="lower right")
    _panel(ax_b, "b")

    paired = pd.DataFrame(payload["paired_advance"])
    paired = paired[paired["scope"] == "ALL"].set_index("monitor")
    probability_names = ["probability_positive", "v20", "v40", "v60"]
    labels = ["$P(\Delta>0)$", "$V_{20}$", "$V_{40}$", "$V_{60}$"]
    x = np.arange(len(DISPLAY))
    width = 0.18
    bar_colors = [COLORS["navy"], COLORS["teal"], COLORS["orange"], COLORS["grey_mid"]]
    for index, (field, label, color) in enumerate(zip(probability_names, labels, bar_colors, strict=True)):
        values = [paired.loc[monitor, field] for monitor in DISPLAY]
        ax_c.bar(x + (index - 1.5) * width, values, width=width, label=label, color=color)
    ax_c.set_xticks(x, [DISPLAY[name] for name in DISPLAY], rotation=20, ha="right")
    ax_c.set_ylim(0, max(0.45, ax_c.get_ylim()[1]))
    ax_c.set_ylabel("Fraction of paired engines")
    ax_c.set_title("Advance is not a single threshold event", loc="left")
    ax_c.legend(ncol=2, loc="upper right", columnspacing=0.8)
    _panel(ax_c, "c")

    ecdf = pd.DataFrame(payload["paired_advance_ecdf"])
    ecdf = ecdf[ecdf["scope"] == "ALL"]
    for monitor in DISPLAY:
        group = ecdf[ecdf["monitor"] == monitor]
        if len(group):
            ax_d.step(group["advance"], group["ecdf"], where="post", lw=1.2, color=MONITOR_COLORS[monitor], label=f"{DISPLAY[monitor]} (n={len(group)})")
    ax_d.axvline(0, color=COLORS["grey_mid"], lw=0.8, ls="--")
    low, high = np.quantile(ecdf["advance"], [0.01, 0.99])
    margin = max(10.0, 0.08 * (high - low))
    ax_d.set_xlim(low - margin, high + margin)
    ax_d.set_ylim(0, 1.01)
    ax_d.set_xlabel("Paired advance $\Delta$ (cycles)")
    ax_d.set_ylabel("Empirical CDF")
    ax_d.set_title("Distribution, not only the mean", loc="left")
    ax_d.legend(loc="lower right", fontsize=6.2)
    _panel(ax_d, "d")
    return _save(fig, "figure4_lead_workload")


def figure5_optional(payload: dict) -> list[Path]:
    per_engine = pd.read_csv(ROOT / "logs" / "evaluation" / "per_engine_metrics.csv")
    ldsi = per_engine[per_engine["monitor"] == "ldsi"]
    raw = ldsi[ldsi["conditioning"] == "raw"].rename(columns={"auc": "auc_raw", "first_persistent_alert": "alert_raw"})
    linear = ldsi[ldsi["conditioning"] == "linear"].rename(columns={"auc": "auc_linear", "first_persistent_alert": "alert_linear"})
    candidates = raw[["subset", "engine_id", "auc_raw", "alert_raw"]].merge(linear[["subset", "engine_id", "auc_linear", "alert_linear"]], on=["subset", "engine_id"])
    joined, _ = join_training_endpoints(PRIMARY_MANIFEST, DATA_ROOT, horizon=125)
    joined = joined[joined["monitor"] == "ldsi"]
    pre_proxy_episode = (
        joined[joined["persistent_alert"].astype(bool) & ~joined["event_label"].astype(bool) & joined["episode_id"].notna()]
        .groupby(["subset", "engine_id", "conditioning"])["episode_id"]
        .nunique()
        .unstack(fill_value=0)
        .reset_index()
    )
    complete_episode = (
        joined[joined["persistent_alert"].astype(bool) & joined["episode_id"].notna()]
        .groupby(["subset", "engine_id", "conditioning"])["episode_id"]
        .nunique()
        .unstack(fill_value=0)
        .reset_index()
    )
    for column in ("raw", "linear"):
        if column not in pre_proxy_episode:
            pre_proxy_episode[column] = 0
        if column not in complete_episode:
            complete_episode[column] = 0
    candidates = candidates.merge(
        pre_proxy_episode[["subset", "engine_id", "raw", "linear"]].rename(columns={"raw": "pre_raw", "linear": "pre_linear"}),
        on=["subset", "engine_id"],
        how="left",
    )
    candidates = candidates.merge(
        complete_episode[["subset", "engine_id", "raw", "linear"]].rename(columns={"raw": "complete_raw", "linear": "complete_linear"}),
        on=["subset", "engine_id"],
        how="left",
    ).fillna({"pre_raw": 0, "pre_linear": 0, "complete_raw": 0, "complete_linear": 0})
    candidates["advance"] = candidates["alert_raw"] - candidates["alert_linear"]
    candidates["auc_gain"] = candidates["auc_linear"] - candidates["auc_raw"]
    eligible = candidates[
        candidates["subset"].isin(["FD002", "FD004"])
        & candidates["alert_raw"].notna()
        & candidates["alert_linear"].notna()
        & (candidates["advance"] >= 20)
        & (candidates["pre_linear"] <= candidates["pre_raw"])
        & candidates["auc_gain"].notna()
    ].copy()
    rule_hash = _sha256(ROOT / "docs" / "figure5_selection_rule.md")
    audit_path = ROOT / "logs" / "audits" / "figure5_case_selection.json"
    if len(eligible) == 0:
        audit_path.write_text(json.dumps({"rule_sha256": rule_hash, "eligible_engines": 0, "selected": None}, indent=2) + "\n", encoding="utf-8")
        return []
    median_gain = float(eligible["auc_gain"].median())
    eligible["distance_to_median"] = abs(eligible["auc_gain"] - median_gain)
    selected = eligible.sort_values(["distance_to_median", "subset", "engine_id"]).iloc[0]
    audit_path.write_text(
        json.dumps(
            {
                "rule_sha256": rule_hash,
                "eligible_engines": len(eligible),
                "eligible_median_auc_gain": median_gain,
                "selected": {
                    "subset": selected["subset"],
                    "engine_id": int(selected["engine_id"]),
                    "advance_cycles": float(selected["advance"]),
                    "auc_gain": float(selected["auc_gain"]),
                    "raw_pre_proxy_episodes": int(selected["pre_raw"]),
                    "conditioned_pre_proxy_episodes": int(selected["pre_linear"]),
                    "raw_complete_episodes": int(selected["complete_raw"]),
                    "conditioned_complete_episodes": int(selected["complete_linear"]),
                },
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    case = joined[(joined["subset"] == selected["subset"]) & (joined["engine_id"] == selected["engine_id"])].copy()
    fig = plt.figure(figsize=(7.2, 3.55))
    gs = fig.add_gridspec(1, 3, left=0.07, right=0.98, bottom=0.16, top=0.90, width_ratios=[1.7, 1.0, 0.8], wspace=0.38)
    ax_a, ax_b, ax_c = (fig.add_subplot(gs[0, index]) for index in range(3))
    for conditioning, color, marker in (("raw", COLORS["grey"], "o"), ("linear", COLORS["teal"], "s")):
        group = case[case["conditioning"] == conditioning].sort_values("score_time")
        ratio = group["score"] / group["threshold"]
        ax_a.plot(group["score_time"], ratio, color=color, lw=1.4, marker=marker, ms=2.8, markevery=max(1, len(group) // 8), label="Raw" if conditioning == "raw" else "Conditioned")
    event_cycle = float(case["max_cycle"].iloc[0] - 125)
    ax_a.axhline(1.0, color=COLORS["orange"], lw=0.8, ls="--", label="Alert threshold")
    ax_a.axvline(event_cycle, color=COLORS["red"], lw=0.8, ls=":", label="Proxy-event cycle")
    ax_a.set_xlabel("Cycle")
    ax_a.set_ylabel("Score / calibrated threshold")
    ax_a.set_title("Representative advisory trajectory", loc="left")
    ax_a.legend(ncol=2, fontsize=6.1)
    _panel(ax_a, "a")

    linear_case = case[case["conditioning"] == "linear"]
    selected_row = linear_case[linear_case["score_time"] == selected["alert_linear"]]
    if len(selected_row) == 0:
        selected_row = linear_case.iloc[[-1]]
    contributors = json.loads(selected_row.iloc[0]["contributors_json"])
    contributors = sorted(contributors, key=lambda item: item["value"], reverse=True)[:5]
    ax_b.barh(range(len(contributors)), [item["value"] for item in contributors], color=COLORS["teal"], height=0.62)
    ax_b.set_yticks(range(len(contributors)), [item["key"].replace("->", "→") for item in contributors], fontsize=6.0)
    ax_b.invert_yaxis()
    ax_b.set_xlabel("Instability contribution")
    ax_b.set_title("Relation-level review cues", loc="left")
    _panel(ax_b, "b")

    ax_c.set_axis_off()
    _rounded(ax_c, (0.02, 0.06), 0.95, 0.88, "#F5F7F8", COLORS["grey_mid"], radius=0.03)
    ax_c.text(0.10, 0.84, "Review card", transform=ax_c.transAxes, fontweight="bold", fontsize=8.5, color=COLORS["navy"])
    summary_lines = [
        f"Subset  {selected['subset']}",
        f"Engine  {int(selected['engine_id'])}",
        f"Advance  {selected['advance']:.0f} cycles",
        f"AUC gain  {selected['auc_gain']:+.3f}",
        f"Pre-proxy episodes  {int(selected['pre_raw'])} → {int(selected['pre_linear'])}",
        f"Complete episodes  {int(selected['complete_raw'])} → {int(selected['complete_linear'])}",
    ]
    for index, line in enumerate(summary_lines):
        ax_c.text(0.10, 0.70 - index * 0.102, line, transform=ax_c.transAxes, fontsize=6.4, color=COLORS["black"])
    ax_c.text(0.10, 0.09, "Operator cue only", transform=ax_c.transAxes, color=COLORS["orange"], fontweight="bold", fontsize=7.0)
    _panel(ax_c, "c")
    return _save(fig, "figure5_review_case")


def _write_claim_map(payload: dict, figure5_present: bool) -> Path:
    metric_hash = _sha256(METRICS_PATH)
    lines = [
        "# Claim-Evidence Map",
        "",
        f"Locked metric ledger SHA-256: `{metric_hash}`.",
        "",
        "| Claim | Evidence | Artifact | Boundary |",
        "|---|---|---|---|",
        "| The workflow separates fixed calibration, transparent monitoring, and governed review | Frozen three-stage engineering architecture | Figure 1 | The review lane does not imply autonomous action |",
        "| Scoring is trajectory-length-independent and endpoint-isolated | Fixed C/W/s protocol, window-end timestamps, verified score ledgers | Figure 2; Table 1 | Endpoint labels enter evaluation only |",
        "| Operating-context correction primarily benefits multi-condition monitoring | Positive multi-minus-single paired AUC gain across five monitors | Figure 3a-b; Table 2 | The condition-by-fault difference-in-differences is near zero and uncertainty intervals cross zero |",
        "| Residualization removes operating association without erasing single-condition variance | Per-FD association, energy, variance, and support audits | Figure 3c; Table 1 | Multi-condition residual energy is intentionally lower and is reported |",
        "| Ranking improvements coexist with monitor-specific review burden | Threshold frontiers, proxy advance, episodes, coverage, and paired advance | Figure 4; Table 3 | The advisory is not a low-false-alert action policy |",
        "| Independent truncated trajectories provide a separate audit | 363/707 official test engines monitorable; locked test score namespace | Results text and supplement | This is a censored audit, not complete run-to-failure validation |",
    ]
    if figure5_present:
        lines.append("| Relation contributions can organize operator review | Prespecified median representative multi-condition case | Figure 5 | Review cues are not fault localization or physical attribution |")
    path = ROOT / "docs" / "claim_evidence_map.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _write_manifest(artifact_paths: list[Path]) -> None:
    manifest = {
        "schema_version": "1.0",
        "metric_ledger": METRICS_PATH.relative_to(ROOT).as_posix(),
        "metric_ledger_sha256": _sha256(METRICS_PATH),
        "artifacts": [
            {
                "path": path.relative_to(ROOT).as_posix(),
                "sha256": _sha256(path),
                "bytes": path.stat().st_size,
            }
            for path in artifact_paths
        ],
    }
    (FIGURE_DIR / "artifact_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def main() -> None:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    payload = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    artifacts: list[Path] = []
    artifacts.extend(figure1_workflow())
    artifacts.extend(figure2_timeline())
    artifacts.extend(figure3_condition_effects(payload))
    artifacts.extend(figure4_lead_workload(payload))
    optional = figure5_optional(payload)
    artifacts.extend(optional)
    claim_map = _write_claim_map(payload, bool(optional))
    artifacts.append(claim_map)
    artifacts.extend(
        [
            ROOT / "tables" / "table1_protocol.tex",
            ROOT / "tables" / "table2_raw_conditioned.tex",
            ROOT / "tables" / "table3_operational_frontier.tex",
        ]
    )
    selection_audit = ROOT / "logs" / "audits" / "figure5_case_selection.json"
    if selection_audit.exists():
        artifacts.append(selection_audit)
    _write_manifest(artifacts)
    print(f"Generated {len(artifacts)} tracked figure/table artifacts")


if __name__ == "__main__":
    main()
