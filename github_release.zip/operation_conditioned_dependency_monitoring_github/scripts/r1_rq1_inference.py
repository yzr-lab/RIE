"""FD-stratified uncertainty for the multi-minus-single conditioning gain."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "logs" / "evaluation" / "per_engine_metrics.csv"
OUTPUT = ROOT / "logs" / "r1_rq1_inference.json"
B = 5000
SEED = 20260917
MONITORS = ("ldsi", "dynamic_corr", "mewma", "mcusum", "var1")


def _fd_mean(delta: pd.DataFrame, fd: str, rng: np.random.Generator) -> float:
    values = delta.loc[delta["subset"] == fd, "delta_auc"].dropna().to_numpy(float)
    if not len(values):
        return float("nan")
    return float(np.mean(rng.choice(values, size=len(values), replace=True)))


def main() -> None:
    frame = pd.read_csv(INPUT)
    frame = frame[frame["conditioning"].isin(["raw", "linear"])].copy()
    rows: dict[str, dict] = {}
    for monitor in MONITORS:
        subset = frame[frame["monitor"] == monitor]
        pivot = subset.pivot_table(
            index=["subset", "engine_id"], columns="conditioning", values="auc", aggfunc="first"
        ).dropna(subset=["raw", "linear"])
        pivot = pivot.reset_index()
        pivot["delta_auc"] = pivot["linear"] - pivot["raw"]
        fds_single = ("FD001", "FD003")
        fds_multi = ("FD002", "FD004")
        point_single = float(np.mean([pivot.loc[pivot["subset"] == fd, "delta_auc"].mean() for fd in fds_single]))
        point_multi = float(np.mean([pivot.loc[pivot["subset"] == fd, "delta_auc"].mean() for fd in fds_multi]))
        point = point_multi - point_single
        rng = np.random.default_rng(SEED)
        draws = np.empty(B, dtype=float)
        for b in range(B):
            single = np.mean([_fd_mean(pivot, fd, rng) for fd in fds_single])
            multi = np.mean([_fd_mean(pivot, fd, rng) for fd in fds_multi])
            draws[b] = multi - single
        rows[monitor] = {
            "statistic": "multi_minus_single_conditioning_gain",
            "estimate": point,
            "single_condition_mean_delta_auc": point_single,
            "multi_condition_mean_delta_auc": point_multi,
            "ci_low": float(np.quantile(draws, 0.025)),
            "ci_high": float(np.quantile(draws, 0.975)),
            "n_bootstrap": B,
            "seed": SEED,
            "fd_counts": {fd: int((pivot["subset"] == fd).sum()) for fd in (*fds_single, *fds_multi)},
        }
    OUTPUT.write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Wrote {OUTPUT}")
    for monitor, row in rows.items():
        print(f"{monitor}: {row['estimate']:+.4f} [{row['ci_low']:+.4f}, {row['ci_high']:+.4f}]")


if __name__ == "__main__":
    main()
