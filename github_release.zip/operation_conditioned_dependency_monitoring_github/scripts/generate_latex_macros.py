"""Generate LaTeX result macros from the locked RINENG metric ledger."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
METRICS = ROOT / "logs" / "main_metrics.json"
PROTOCOL = ROOT / "configs" / "primary_protocol.yaml"
PAIRED = ROOT / "logs" / "r1_paired_inference.json"
OUTPUT = ROOT / "generated_metrics.tex"

PREFIX = {
    "ldsi": "LDSI",
    "dynamic_corr": "DynamicCorr",
    "mewma": "MEWMA",
    "mcusum": "MCUSUM",
    "var1": "VAROne",
}

SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.censored import join_official_test_endpoints  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402


def _paired_test_means() -> dict[str, dict[str, float | int]]:
    """Return raw/conditioned means on the same 208-engine test cohort.

    The official-test ledger also contains an unpaired descriptive macro-AUC
    summary.  The manuscript's test change is a paired engine-level quantity,
    so the displayed columns must use the same eligible engines and weights as
    the paired bootstrap interval.
    """
    manifest = ROOT / "logs" / "scores" / "test_censored_score_manifest.json"
    frame, _ = join_official_test_endpoints(
        manifest, resolve_cmapss_root(ROOT), horizon=125
    )
    means: dict[str, dict[str, float | int]] = {}
    for monitor, prefix in PREFIX.items():
        rows = []
        for conditioning in ("raw", "linear"):
            part = frame[
                (frame["monitor"] == monitor)
                & (frame["conditioning"] == conditioning)
            ]
            for (subset, engine_id), group in part.groupby(
                ["subset", "engine_id"], sort=True
            ):
                if group["score_time"].nunique() < 5:
                    continue
                if group["event_label"].nunique() < 2:
                    continue
                from sklearn.metrics import roc_auc_score

                rows.append(
                    {
                        "subset": subset,
                        "engine_id": int(engine_id),
                        "conditioning": conditioning,
                        "auc": float(
                            roc_auc_score(
                                group["event_label"], group["score"]
                            )
                        ),
                    }
                )
        aucs = pd.DataFrame(rows)
        raw = aucs[aucs["conditioning"] == "raw"]
        linear = aucs[aucs["conditioning"] == "linear"]
        paired = raw.merge(
            linear,
            on=["subset", "engine_id"],
            suffixes=("_raw", "_linear"),
        )
        means[monitor] = {
            "raw": float(paired["auc_raw"].mean()),
            "linear": float(paired["auc_linear"].mean()),
            "n": int(len(paired)),
        }
    return means


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _macro(name: str, value: str) -> str:
    return rf"\newcommand{{\{name}}}{{{value}}}"


def _f(value: float, digits: int = 3) -> str:
    return f"{float(value):.{digits}f}"


def main() -> None:
    payload = json.loads(METRICS.read_text(encoding="utf-8"))
    protocol = json.loads((ROOT / "configs" / "protocol_hash.json").read_text(encoding="utf-8"))
    metrics_all = {
        (row["monitor"], row["conditioning"]): row
        for row in payload["metrics"]
        if row["scope"] == "ALL"
    }
    paired_all = {
        row["monitor"]: row
        for row in payload["paired_advance"]
        if row["scope"] == "ALL"
    }
    gains = {row["monitor"]: row for row in payload["multi_vs_single_conditioning_gain"]}
    test_metrics = {
        (row["monitor"], row["conditioning"]): row
        for row in payload["official_test_censored_audit"]["metrics"]
        if row["subset"] == "ALL"
    }
    paired_payload = json.loads(PAIRED.read_text(encoding="utf-8")) if PAIRED.exists() else {}
    test_paired_means = _paired_test_means()

    lines = [
        "% Generated from logs/main_metrics.json. Do not edit manually.",
        f"% Metrics ledger SHA-256: {_sha256(METRICS)}",
        f"% Protocol SHA-256: {protocol['protocol_sha256']}",
        _macro("MetricsLedgerHash", _sha256(METRICS)),
        _macro("ProtocolHash", protocol["protocol_sha256"]),
        _macro("PrimaryCalibrationCycles", "60"),
        _macro("PrimaryWindowCycles", "40"),
        _macro("PrimaryStepCycles", "10"),
        _macro("PrimaryPersistenceWindows", "3"),
        _macro("PrimaryRelationCandidates", "20"),
        _macro("PrimaryContributors", "5"),
        _macro("TrainEngines", "709"),
        _macro("MonitorableTrainEngines", "696"),
        _macro("LockedTrainingScores", f"{int(payload['score_rows']):,}"),
        _macro("OfficialTestEngines", str(payload["official_test_censored_audit"]["total_test_engines"])),
        _macro("MonitorableTestEngines", str(payload["official_test_censored_audit"]["monitorable_test_engines"])),
        f"% Paired-inference SHA-256: {_sha256(PAIRED)}" if PAIRED.exists() else "% Paired-inference: unavailable",
    ]

    for monitor, prefix in PREFIX.items():
        raw = metrics_all[(monitor, "raw")]
        linear = metrics_all[(monitor, "linear")]
        pair = paired_all[monitor]
        gain = gains[monitor]
        test_raw = test_metrics[(monitor, "raw")]
        test_linear = test_metrics[(monitor, "linear")]
        paired_test = test_paired_means[monitor]
        for conditioning_name, row in (("Raw", raw), ("Linear", linear)):
            lines.extend(
                [
                    _macro(f"{conditioning_name}{prefix}AUC", _f(row["engine_macro_auc"])),
                    _macro(f"{conditioning_name}{prefix}FPR", _f(row["persistent_window_rate_pre_proxy"])),
                    _macro(f"{conditioning_name}{prefix}Coverage", _f(row["event_region_coverage"])),
                    _macro(f"{conditioning_name}{prefix}FleetLead", _f(row["pre_proxy_advance_fleet_zero_filled"], 2)),
                    _macro(f"{conditioning_name}{prefix}ConditionalLead", _f(row["pre_proxy_advance_detected_mean"], 1)),
                    _macro(f"{conditioning_name}{prefix}Episodes", _f(row["all_episode_rate_per_engine"], 3)),
                ]
            )
        lines.extend(
            [
                _macro(f"{prefix}MultiConditionGain", _f(gain["multi_minus_single_conditioning_gain"])),
                _macro(f"{prefix}PairedCount", str(pair["paired_engines"])),
                _macro(f"{prefix}PositiveAdvance", _f(pair["probability_positive"])),
                _macro(f"{prefix}VTwenty", _f(pair["v20"])),
                _macro(f"{prefix}VForty", _f(pair["v40"])),
                _macro(f"{prefix}VSixty", _f(pair["v60"])),
                _macro(f"{prefix}PairedMean", _f(pair["paired_mean"], 2)),
                _macro(f"{prefix}FleetGain", _f(pair["delta_pre_proxy_advance_fleet"], 2)),
                _macro(f"TestRaw{prefix}AUC", _f(paired_test["raw"])),
                _macro(f"TestLinear{prefix}AUC", _f(paired_test["linear"])),
                _macro(
                    f"TestDelta{prefix}AUC",
                    _f(paired_test["linear"] - paired_test["raw"]),
                ),
            ]
        )
        if paired_payload:
            for split in ("train", "test"):
                paired = paired_payload[split][monitor]["paired_delta_auc"]
                split_prefix = "Train" if split == "train" else "Test"
                lines.extend(
                    [
                        _macro(f"{split_prefix}Paired{prefix}DeltaAUC", _f(paired["estimate"])),
                        _macro(f"{split_prefix}Paired{prefix}DeltaLow", _f(paired["ci_low"])),
                        _macro(f"{split_prefix}Paired{prefix}DeltaHigh", _f(paired["ci_high"])),
                        _macro(f"{split_prefix}Paired{prefix}AUCN", str(paired["n_two_class"])),
                    ]
                )

    OUTPUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {OUTPUT} from metrics {_sha256(METRICS)}")


if __name__ == "__main__":
    main()
