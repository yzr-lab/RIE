"""R1 E4: LDSI design sensitivity (memory alpha, max lag) and alternative
stratified-random selector, on a label-free engine sample. Signal retention is
summarized from the primary conditioning-support audit."""

from __future__ import annotations

import json
import sys
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.data import load_cmapss_observed  # noqa: E402
from rineng_replay.evaluation import ranking_metrics, summarize_alert_workload  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402
from rineng_replay.protocol import ReplayConfig, window_count  # noqa: E402
from rineng_replay.replay import score_trajectory  # noqa: E402

DATA_ROOT = resolve_cmapss_root(ROOT)
OUT = ROOT / "logs" / "r1_design_sensitivity.json"
HORIZON = 125


def base_config() -> ReplayConfig:
    return ReplayConfig(
        calibration_cycles=60, window_size=40, step=10, persistence=3,
        max_lag=3, selector_m=20, aggregation_k=5, min_monitor_windows=5,
    )


def sample_trajectories(n_per_fd: int = 20):
    out = []
    for subset in ("FD001", "FD002", "FD003", "FD004"):
        trajs = load_cmapss_observed(DATA_ROOT, subset, "train", None)
        cfg = base_config()
        mon = [t for t in trajs if window_count(len(t.cycles), cfg) >= 5]
        out.extend(mon[:n_per_fd])
    return out


def score_ldsi(trajectories, config, **kwargs):
    rows = []
    for trajectory in trajectories:
        for conditioning in ("raw", "linear"):
            result = score_trajectory(
                trajectory, config, conditioning=conditioning,
                monitor_names=("ldsi",), **kwargs,
            )
            for r in result.records["ldsi"]:
                d = asdict(r)
                d["max_cycle"] = int(trajectory.cycles[-1])
                rows.append(d)
    return pd.DataFrame(rows)


def summarize(frame):
    if frame.empty:
        return {}
    rows = frame.copy()
    rows["event_label"] = rows["max_cycle"] - rows["score_time"] <= HORIZON
    out = {}
    for conditioning in ("raw", "linear"):
        g = rows[rows["conditioning"] == conditioning]
        out[conditioning] = {
            **ranking_metrics(g),
            **summarize_alert_workload(g, horizon=HORIZON),
        }
    return out


def annotate_sample(summary: dict, sampled_engines: int) -> dict:
    """Attach the sampling and AUC-eligibility denominators to each branch."""
    for conditioning in ("raw", "linear"):
        summary[conditioning]["sampled_engines"] = sampled_engines
        summary[conditioning]["monitorable_engines"] = sampled_engines
        summary[conditioning]["auc_valid_n"] = summary[conditioning].get(
            "engine_macro_denominator", 0
        )
    return summary


def signal_retention() -> dict:
    support = pd.read_csv(ROOT / "logs" / "audits" / "conditioning_support.csv")
    linear = support[support["conditioning"] == "linear"]
    raw = support[support["conditioning"] == "raw"]
    return {
        "linear_median_variance_retention": float(linear["median_variance_retention"].median()),
        "linear_median_condition_assoc_before": float(linear["median_condition_association_before"].median()),
        "linear_median_condition_assoc_after": float(linear["median_condition_association_after"].median()),
        "raw_median_variance_retention": float(raw["median_variance_retention"].median()),
    }


def main() -> None:
    trajectories = sample_trajectories()
    cfg = base_config()
    payload: dict = {"sample_engines": len(trajectories), "variants": {}}

    print("top-strength reference", flush=True)
    reference = summarize(score_ldsi(trajectories, cfg))
    payload["top_strength_reference"] = annotate_sample(reference, len(trajectories))

    # memory alpha sensitivity
    for tag, (sa, la) in {
        "alpha_0.30_0.05": (0.30, 0.05),
        "alpha_0.40_0.10": (0.40, 0.10),
        "alpha_0.60_0.15": (0.60, 0.15),
    }.items():
        print(f"alpha {tag}", flush=True)
        frame = score_ldsi(trajectories, cfg, short_alpha=sa, long_alpha=la)
        payload["variants"][tag] = annotate_sample(summarize(frame), len(trajectories))

    # max lag sensitivity
    for lag in (1, 3, 5):
        tag = f"lag_{lag}"
        print(f"lag {lag}", flush=True)
        frame = score_ldsi(trajectories, replace(cfg, max_lag=lag))
        payload["variants"][tag] = annotate_sample(summarize(frame), len(trajectories))

    # stratified random selector (5 fixed seeds)
    for seed in range(5):
        tag = f"selector_seed_{seed}"
        print(f"selector seed {seed}", flush=True)
        frame = score_ldsi(trajectories, cfg, selector_mode="stratified_random", selector_seed=seed)
        payload["variants"][tag] = annotate_sample(summarize(frame), len(trajectories))

    payload["signal_retention"] = signal_retention()

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
