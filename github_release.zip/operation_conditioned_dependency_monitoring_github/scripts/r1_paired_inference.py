"""R1 E2: paired inference, age-only control, horizon sensitivity, cohort audit.

Reads the matched-threshold primary (and censored test) score ledgers and produces
the FD-stratified engine-paired bootstrap intervals, age-only / cross-engine AUC
controls, H=100/125/150 sensitivity, and a full cohort denominator audit.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rineng_replay.censored import join_official_test_endpoints  # noqa: E402
from rineng_replay.evaluation import (  # noqa: E402
    join_training_endpoints,
    summarize_alert_workload,
)
from rineng_replay.monitors import MONITOR_NAMES  # noqa: E402
from rineng_replay.paths import resolve_cmapss_root  # noqa: E402

DATA_ROOT = resolve_cmapss_root(ROOT)
TRAIN_MANIFEST = ROOT / "logs" / "scores" / "primary_score_manifest.json"
TEST_MANIFEST = ROOT / "logs" / "scores" / "test_censored_score_manifest.json"
OUT = ROOT / "logs" / "r1_paired_inference.json"
B = 5000
SEED = 20260917
HORIZONS = (100, 125, 150)


def per_engine_auc(frame: pd.DataFrame) -> pd.DataFrame:
    """Per-engine AUC restricted to the monitorable (>=5 windows) two-class subset."""
    rows: list[dict] = []
    for (subset, engine_id), group in frame.groupby(
        ["subset", "engine_id"], sort=True
    ):
        if group["score_time"].nunique() < 5:
            continue
        labels = group["event_label"].to_numpy(dtype=int)
        if len(np.unique(labels)) < 2:
            continue
        rows.append(
            {
                "subset": subset,
                "engine_id": int(engine_id),
                "auc": float(roc_auc_score(labels, group["score"])),
            }
        )
    return pd.DataFrame(rows)


def paired_delta(frame: pd.DataFrame) -> pd.DataFrame:
    raw = per_engine_auc(frame[frame["conditioning"] == "raw"])
    linear = per_engine_auc(frame[frame["conditioning"] == "linear"])
    merged = raw.merge(
        linear, on=["subset", "engine_id"], suffixes=("_raw", "_linear")
    )
    merged["delta"] = merged["auc_linear"] - merged["auc_raw"]
    return merged


def fd_stratified_bootstrap(values_by_fd: dict[str, np.ndarray]) -> dict:
    all_values = np.concatenate(list(values_by_fd.values()))
    rng = np.random.default_rng(SEED)
    estimates = np.empty(B, dtype=float)
    for i in range(B):
        sampled = [rng.choice(v, size=len(v), replace=True) for v in values_by_fd.values()]
        estimates[i] = float(np.mean(np.concatenate(sampled)))
    return {
        "estimate": float(all_values.mean()),
        "ci_low": float(np.quantile(estimates, 0.025)),
        "ci_high": float(np.quantile(estimates, 0.975)),
        "bootstrap_mean": float(estimates.mean()),
    }


def delta_auc_summary(frame: pd.DataFrame, monitor: str) -> dict:
    delta = paired_delta(frame[frame["monitor"] == monitor])
    by_fd = {
        fd: g["delta"].to_numpy(dtype=float)
        for fd, g in delta.groupby("subset", sort=True)
    }
    result = {"n_two_class": int(len(delta))}
    result.update(fd_stratified_bootstrap(by_fd))
    result["fd_counts"] = {fd: int(len(v)) for fd, v in by_fd.items()}
    return result


def age_only_auc(frame: pd.DataFrame) -> float:
    """score=cycle gives AUC=1 on every two-class engine (structural property)."""
    rows = frame.copy()
    rows["score"] = rows["score_time"]
    engine = per_engine_auc(rows)
    return float(engine["auc"].mean())


def cross_engine_auc(frame: pd.DataFrame, monitor: str) -> dict:
    """Same-FD, same-score-time cross-engine ranking against the proxy label."""
    base = frame[(frame["monitor"] == monitor) & (frame["conditioning"] == "linear")]
    cells: list[dict] = []
    aucs_by_fd: dict[str, list[float]] = {}
    for fd, fd_group in base.groupby("subset", sort=True):
        fd_aucs: list[float] = []
        for t, cell in fd_group.groupby("score_time", sort=True):
            labels = cell["event_label"].to_numpy(dtype=int)
            if len(np.unique(labels)) < 2 or (labels.sum() < 5) or ((~labels.astype(bool)).sum() < 5):
                continue
            fd_aucs.append(float(roc_auc_score(labels, cell["score"])))
            cells.append({"subset": fd, "score_time": int(t), "n": len(cell), "auc": fd_aucs[-1]})
        if fd_aucs:
            aucs_by_fd[fd] = fd_aucs
    fd_means = {fd: float(np.mean(v)) for fd, v in aucs_by_fd.items()}
    return {
        "n_cells": len(cells),
        "fd_mean_auc": fd_means,
        "overall_mean_auc": float(np.mean(list(fd_means.values()))) if fd_means else None,
        "n_fds": len(fd_means),
    }


def denominator_audit(frame: pd.DataFrame) -> dict:
    engines = frame.groupby(["subset", "engine_id"])["score_time"].nunique()
    monitorable = int((engines >= 5).sum())
    total = int(len(engines))
    two_class = 0
    event_observed = 0
    for (subset, engine_id), group in frame.groupby(["subset", "engine_id"], sort=True):
        if group["score_time"].nunique() < 5:
            continue
        if group["event_label"].nunique() == 2:
            two_class += 1
        if group["event_label"].any():
            event_observed += 1
    return {
        "total_scored_engines": total,
        "monitorable_engines": monitorable,
        "two_class_engines": two_class,
        "event_observed_engines": event_observed,
    }


def main() -> None:
    global B
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-bootstrap", type=int, default=5000)
    args = parser.parse_args()
    B = args.n_bootstrap

    train, _ = join_training_endpoints(TRAIN_MANIFEST, DATA_ROOT, horizon=125)

    payload: dict = {"seed": SEED, "n_bootstrap": B, "train": {}, "test": {}}

    for monitor in MONITOR_NAMES:
        payload["train"][monitor] = {
            "paired_delta_auc": delta_auc_summary(train, monitor),
            "age_only_auc": age_only_auc(train[train["monitor"] == monitor]),
            "cross_engine_auc": cross_engine_auc(train, monitor),
        }

    # cohort denominator audit (same across monitors since cohort is trajectory-defined)
    payload["train"]["cohort_audit"] = denominator_audit(train[train["monitor"] == "ldsi"])

    # horizon sensitivity (reuses locked scores; relabels only)
    horizon_rows: dict = {}
    for h in HORIZONS:
        joined, _ = join_training_endpoints(TRAIN_MANIFEST, DATA_ROOT, horizon=h)
        for monitor in MONITOR_NAMES:
            horizon_rows.setdefault(monitor, {})[h] = delta_auc_summary(joined, monitor)
    payload["train"]["horizon_sensitivity"] = horizon_rows

    # test (censored) paired delta AUC
    if TEST_MANIFEST.exists():
        test, _ = join_official_test_endpoints(TEST_MANIFEST, DATA_ROOT, horizon=125)
        for monitor in MONITOR_NAMES:
            payload["test"][monitor] = {
                "paired_delta_auc": delta_auc_summary(test, monitor),
                "age_only_auc": age_only_auc(test[test["monitor"] == monitor]),
            }
        payload["test"]["cohort_audit"] = denominator_audit(test[test["monitor"] == "ldsi"])

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Wrote {OUT}")
    for monitor in MONITOR_NAMES:
        d = payload["train"][monitor]["paired_delta_auc"]
        print(
            f"  {monitor}: train dAUC {d['estimate']:+.4f} "
            f"[{d['ci_low']:+.4f}, {d['ci_high']:+.4f}] n={d['n_two_class']}"
        )


if __name__ == "__main__":
    main()
