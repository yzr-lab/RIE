"""Build a compact GitHub distribution of the key code and derived results.

The distribution intentionally excludes NASA C-MAPSS files, full JSONL score
ledgers, sensitivity caches, manuscript sources, and submission materials.
"""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build" / "github_release"
ARCHIVE = ROOT / "build" / "github_release.zip"
RELEASE_ROOT = "operation_conditioned_dependency_monitoring_github"
MAX_BYTES = 25 * 1024 * 1024
FIXED_TIME = (2026, 9, 23, 0, 0, 0)

ROOT_FILES = ("LICENSE", "LICENSE-DATA", "requirements.txt")
CONFIG_FILES = (
    "configs/primary_protocol.yaml",
    "configs/protocol_hash.json",
    "configs/statistic_contract.json",
    "configs/feasibility_grid.yaml",
)
SOURCE_FILES = tuple(sorted((ROOT / "src/rineng_replay").glob("*.py")))
SCRIPT_NAMES = (
    "assemble_github_release.py",
    "build_metric_ledger.py",
    "generate_latex_macros.py",
    "generate_tables.py",
    "generate_figures.py",
    "generate_r1_tables.py",
    "r1_case_audit.py",
    "r1_design_sensitivity.py",
    "r1_frozen_candidate_stability.py",
    "r1_operational_inference.py",
    "r1_operational_sensitivity.py",
    "r1_paired_inference.py",
    "r1_relation_stability.py",
    "r1_rq1_inference.py",
    "r1_synthetic.py",
    "run_censored_test_replay.py",
    "run_primary_replay.py",
    "run_sensitivity_audits.py",
    "select_label_free_protocol.py",
)
TEST_NAMES = (
    "conftest.py",
    "test_artifact_provenance.py",
    "test_bootstrap.py",
    "test_figure_table_contracts.py",
    "test_instability_semantics.py",
    "test_ledger_locking.py",
    "test_metric_semantics_r1.py",
    "test_monitor_invariants.py",
    "test_r1_revision_residuals.py",
    "test_statistic_contract_r1.py",
    "test_support_flags_r1.py",
    "test_threshold_operator_match_r1.py",
    "test_timestamp_semantics.py",
)
RESULT_FILES = (
    "logs/main_metrics.json",
    "logs/metrics_manifest.json",
    "logs/evaluation/per_engine_metrics.csv",
    "logs/evaluation/paired_advance_ecdf.csv",
    "logs/evaluations/test_censored_metrics.json",
    "logs/evaluations/test_censored_per_engine.csv",
    "logs/audits/conditioning_support.csv",
    "logs/audits/context_model_sensitivity.csv",
    "logs/audits/fd_2x2_interaction.json",
    "logs/audits/figure5_case_selection.json",
    "logs/audits/length_stratified_sensitivity.csv",
    "logs/audits/monitorability_flow.csv",
    "logs/audits/selector_m_k_sensitivity.csv",
    "logs/audits/step_horizon_sensitivity.csv",
    "logs/audits/test_censored_monitorability.csv",
)
DOC_FILES = (
    "docs/claim_evidence_map.md",
    "docs/figure_contract.md",
    "docs/integrity_report.md",
    "docs/reproducibility_map.md",
    "docs/source_manifest.json",
)
TABLE_FILES = tuple(sorted((ROOT / "tables").glob("*.tex")))
FIGURE_FILES = tuple(
    sorted(
        path
        for path in (ROOT / "figures").iterdir()
        if path.is_file() and path.suffix.lower() in {".pdf", ".svg", ".png"}
    )
) + (ROOT / "figures/artifact_manifest.json",)


def _sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _absolute_path_replacements(text: str) -> str:
    replacements = {
        "${CMAPSS_DATA_ROOT}": "${CMAPSS_DATA_ROOT}",
        "E:\\gongye1\\data\\cmapss": "${CMAPSS_DATA_ROOT}",
        "protected-source-not-distributed": "protected-source-not-distributed",
        "E:\\gongye1\\RESS_submission_v2": "protected-source-not-distributed",
        str(ROOT): ".",
        ROOT.as_posix(): ".",
        str(ROOT).replace("\\", "/"): ".",
        ".": ".",
        "E:\\gongye1\\revision_r1": ".",
        ".": ".",
        "E:\\gongye1": ".",
        ".": ".",
        "F:\\gongye1": ".",
        "GitHub": "GitHub",
        "GitHub": "GitHub",
    }
    for source, target in sorted(replacements.items(), key=lambda item: -len(item[0])):
        text = text.replace(source, target)
    return text


def _payload(path: Path) -> bytes:
    data = path.read_bytes()
    if path.suffix.lower() in {".json", ".csv", ".md", ".py", ".tex", ".yaml", ".yml", ".txt"}:
        return _absolute_path_replacements(data.decode("utf-8")).encode("utf-8")
    return data


def _readme() -> str:
    return """# Operation-conditioned dependency monitoring

Compact GitHub distribution for Operation-Conditioned Dependency Monitoring
for Turbofan Degradation: Transparent Evidence and Lead--Workload Trade-offs.

This archive contains the key replay code, frozen protocol definitions, derived
metric ledgers, revision audit results, tables, figures, and integrity tests.

## Contents

- src/rineng_replay/: conditioning, relation extraction, monitors, scoring,
  evaluation, and ledger verification;
- configs/: protocol and statistic contracts;
- scripts/: primary replay and revision-audit entry points;
- logs/: key derived metrics and audit records;
- tables/ and figures/: editable result tables and vector figures;
- tests/: focused integrity and metric-semantics tests.

NASA C-MAPSS raw files, full JSONL score ledgers, large sensitivity caches,
manuscript sources, response files, and submission metadata are intentionally
excluded. C-MAPSS must be obtained from the NASA Open Data Portal under its
original terms. The included result files are derived records and do not
redistribute the source data.

## Local checks

~~~powershell
python -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest tests -q
~~~

The complete replay requires the NASA files and the full locked score ledgers;
this compact distribution is for transparent inspection of the implementation
and key results, not a replacement for the complete internal replay archive.

## License

Source code is MIT licensed. Documentation, figures, tables, and derived
results are released under CC BY 4.0. Third-party source data remain under
their original terms.
"""


def _collect() -> dict[str, bytes]:
    files: dict[str, bytes] = {"README.md": _readme().encode("utf-8")}
    paths = [ROOT / name for name in ROOT_FILES + CONFIG_FILES + RESULT_FILES + DOC_FILES]
    paths += [ROOT / "generated_metrics.tex"]
    paths += list(SOURCE_FILES)
    paths += [ROOT / "scripts" / name for name in SCRIPT_NAMES]
    paths += [ROOT / "tests" / name for name in TEST_NAMES]
    paths += sorted(ROOT.glob("logs/r1_*.json"))
    paths += list(TABLE_FILES) + list(FIGURE_FILES)
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(path)
        relative = path.relative_to(ROOT).as_posix()
        files[relative] = _payload(path)
    # The compact package sanitizes local paths in text artifacts.  Keep the
    # embedded ledger hash truthful for the packaged, sanitized ledger.
    manifest_name = "figures/artifact_manifest.json"
    if manifest_name in files and "logs/main_metrics.json" in files:
        manifest = json.loads(files[manifest_name].decode("utf-8"))
        manifest["metric_ledger_sha256"] = _sha256(files["logs/main_metrics.json"])
        files[manifest_name] = (
            json.dumps(manifest, indent=2, sort_keys=True) + "\n"
        ).encode("utf-8")
    return dict(sorted(files.items()))


def _write_directory(files: dict[str, bytes]) -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    for relative, payload in files.items():
        path = OUT / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(payload)
    manifest = {
        "archive_root": RELEASE_ROOT,
        "file_count": len(files),
        "max_bytes": MAX_BYTES,
        "files": [
            {"path": name, "bytes": len(data), "sha256": _sha256(data)}
            for name, data in files.items()
        ],
    }
    (OUT / "MANIFEST.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def _write_zip(files: dict[str, bytes]) -> None:
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    temporary = ARCHIVE.with_suffix(".zip.tmp")
    if temporary.exists():
        temporary.unlink()
    with ZipFile(temporary, "w", compression=ZIP_DEFLATED, compresslevel=9) as handle:
        for relative, payload in files.items():
            info = ZipInfo(f"{RELEASE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            handle.writestr(info, payload, compress_type=ZIP_DEFLATED, compresslevel=9)
        manifest = {
            "archive_root": RELEASE_ROOT,
            "file_count": len(files),
            "max_bytes": MAX_BYTES,
            "files": [
                {"path": name, "bytes": len(data), "sha256": _sha256(data)}
                for name, data in files.items()
            ],
        }
        payload = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")
        info = ZipInfo(f"{RELEASE_ROOT}/MANIFEST.json", FIXED_TIME)
        info.compress_type = ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        handle.writestr(info, payload, compress_type=ZIP_DEFLATED, compresslevel=9)
    temporary.replace(ARCHIVE)


def main() -> None:
    files = _collect()
    _write_directory(files)
    _write_zip(files)
    size = ARCHIVE.stat().st_size
    if size >= MAX_BYTES:
        raise RuntimeError(f"GitHub archive is {size} bytes, above the 25 MB limit")
    print(json.dumps({"archive": str(ARCHIVE), "bytes": size, "files": len(files), "status": "pass"}, indent=2))


if __name__ == "__main__":
    main()
