"""Cross-engine relation-selection stability audit for the frozen LDSI ledger."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SCORE_DIR = ROOT / "logs" / "scores" / "primary"
OUTPUT = ROOT / "logs" / "r1_relation_stability.json"


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    return len(a & b) / len(a | b) if a | b else 1.0


def _audit(paths: list[Path], support: pd.DataFrame, conditioning: str) -> dict:
    frame = pd.concat([pd.read_json(path, lines=True) for path in paths], ignore_index=True)
    keys = ["subset", "engine_id"]
    frame = frame.sort_values(keys + ["score_time"])
    by_engine: dict[tuple[str, int], list[set[str]]] = defaultdict(list)
    for row in frame.itertuples(index=False):
        items = json.loads(row.contributors_json)
        by_engine[(row.subset, int(row.engine_id))].append(
            {str(item["key"]) for item in items if item.get("key")}
        )
    monitorable = support[
        (support["conditioning"] == conditioning) & support["monitorable"].astype(bool)
    ][["subset", "engine_id"]].drop_duplicates()
    monitorable_keys = [(str(r.subset), int(r.engine_id)) for r in monitorable.itertuples()]
    union_sets: list[set[str]] = []
    adjacent: list[float] = []
    for key in monitorable_keys:
        sets = by_engine[key]
        if not sets:
            continue
        union = set().union(*sets)
        union_sets.append(union)
        adjacent.extend(_jaccard(a, b) for a, b in zip(sets, sets[1:]))
    presence: dict[str, int] = defaultdict(int)
    for union in union_sets:
        for relation in union:
            presence[relation] += 1
    values = np.asarray(list(presence.values()), dtype=float)
    support_sub = support[support["conditioning"] == conditioning]
    return {
        "monitorable_engines": len(monitorable_keys),
        "engines_with_contributors": len(union_sets),
        "engine_presence_summary": {
            "n_relations": int(len(presence)),
            "max_engine_presence": int(values.max()) if len(values) else 0,
            "max_engine_presence_fraction": float(values.max() / len(union_sets)) if len(values) and union_sets else 0.0,
            "median_engine_presence_fraction": float(np.median(values / len(union_sets))) if len(values) and union_sets else 0.0,
            "relations_present_in_at_least_half_engines": int(np.sum(values >= 0.5 * len(union_sets))) if union_sets else 0,
            "top_relations": sorted(
                ({"relation": rel, "engines": int(count), "fraction": float(count / len(union_sets))} for rel, count in presence.items()),
                key=lambda item: (-item["fraction"], item["relation"]),
            )[:10],
        },
        "adjacent_window_jaccard_mean": float(np.mean(adjacent)) if adjacent else float("nan"),
        "adjacent_window_jaccard_median": float(np.median(adjacent)) if adjacent else float("nan"),
        "adjacent_window_jaccard_n": len(adjacent),
        "fdr_zero_records": int((support_sub["fdr_retained_count"] == 0).sum()),
        "support_records": int(len(support_sub)),
    }


def main() -> None:
    support = pd.read_csv(ROOT / "logs" / "audits" / "conditioning_support.csv")
    payload = {
        conditioning: _audit(
            sorted(SCORE_DIR.glob(f"FD00[1-4]_{conditioning}_ldsi.jsonl")),
            support,
            conditioning,
        )
        for conditioning in ("raw", "linear")
    }
    OUTPUT.write_text(json.dumps(payload, indent=2, sort_keys=True, allow_nan=True) + "\n", encoding="utf-8")
    for conditioning, row in payload.items():
        s = row["engine_presence_summary"]
        print(conditioning, row["monitorable_engines"], row["adjacent_window_jaccard_mean"], s["n_relations"], s["max_engine_presence_fraction"])
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    main()
