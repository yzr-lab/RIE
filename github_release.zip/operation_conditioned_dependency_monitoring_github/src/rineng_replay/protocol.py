"""Trajectory-length-independent replay configuration and window iteration."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import median
from typing import Iterable, Iterator, Sequence

import numpy as np

from .data import ObservedTrajectory


@dataclass(frozen=True)
class ReplayConfig:
    calibration_cycles: int
    window_size: int
    step: int
    persistence: int
    max_lag: int
    selector_m: int
    aggregation_k: int
    min_monitor_windows: int = 5

    def __post_init__(self) -> None:
        values = asdict(self)
        if any(int(value) <= 0 for value in values.values()):
            raise ValueError("all replay parameters must be positive")
        if self.aggregation_k > self.selector_m:
            raise ValueError("aggregation_k cannot exceed selector_m")
        if self.max_lag >= self.window_size:
            raise ValueError("max_lag must be smaller than the monitoring window")


@dataclass(frozen=True)
class WindowRecord:
    subset: str
    engine_id: int
    window_index: int
    window_start: int
    window_end: int
    score_time: int
    settings: np.ndarray
    sensors: np.ndarray

    @property
    def window_size(self) -> int:
        return int(len(self.sensors))


def window_count(length: int, config: ReplayConfig) -> int:
    first_end = config.calibration_cycles + config.window_size
    if length < first_end:
        return 0
    return 1 + (length - first_end) // config.step


def iter_completed_windows(
    trajectory: ObservedTrajectory, config: ReplayConfig
) -> Iterator[WindowRecord]:
    """Yield non-overlapping-with-calibration windows when their end is observed."""

    n_rows = len(trajectory.cycles)
    first_end_row = config.calibration_cycles + config.window_size
    for window_index, end_row in enumerate(
        range(first_end_row, n_rows + 1, config.step)
    ):
        start_row = end_row - config.window_size
        start_cycle = int(trajectory.cycles[start_row])
        end_cycle = int(trajectory.cycles[end_row - 1])
        yield WindowRecord(
            subset=trajectory.subset,
            engine_id=trajectory.engine_id,
            window_index=window_index,
            window_start=start_cycle,
            window_end=end_cycle,
            score_time=end_cycle,
            settings=trajectory.settings[start_row:end_row].copy(),
            sensors=trajectory.sensors[start_row:end_row].copy(),
        )


def assess_length_feasibility(
    lengths: Iterable[int], config: ReplayConfig
) -> dict[str, float | int]:
    counts = [window_count(int(length), config) for length in lengths]
    monitorable = [count for count in counts if count >= config.min_monitor_windows]
    return {
        "total_engines": len(counts),
        "monitorable_engines": len(monitorable),
        "monitorability_rate": float(len(monitorable) / len(counts)) if counts else 0.0,
        "median_monitor_windows": float(median(monitorable)) if monitorable else 0.0,
        "total_monitor_windows": int(sum(monitorable)),
        "cost_proxy": int(
            sum(monitorable)
            * config.window_size
            * config.max_lag
            * config.selector_m
        ),
    }


def select_primary_config(
    lengths: Iterable[int], candidates: Sequence[ReplayConfig]
) -> tuple[ReplayConfig, dict]:
    """Select by label-free coverage and stability floors fixed before evaluation."""

    audits = [
        {"config": asdict(config), **assess_length_feasibility(lengths, config)}
        for config in candidates
    ]
    eligible = [
        (config, audit)
        for config, audit in zip(candidates, audits)
        if config.calibration_cycles >= 60
        and config.window_size - config.max_lag >= 30
        and config.step == 10
        and config.persistence == 3
    ]
    if not eligible:
        raise ValueError("no candidate satisfies the prespecified stability floors")
    selected, selected_audit = max(
        eligible,
        key=lambda pair: (
            pair[1]["monitorable_engines"],
            pair[1]["median_monitor_windows"],
            -pair[1]["cost_proxy"],
        ),
    )
    return selected, {
        "selection_uses_outcomes": False,
        "selection_rule": (
            "C>=60, W-L>=30, step=10, persistence=3; maximize monitorable "
            "engines, then median windows, then minimize cost proxy. The "
            "C=80, W=60 branch is retained as a stability sensitivity."
        ),
        "selected": selected_audit,
        "candidates": audits,
    }
