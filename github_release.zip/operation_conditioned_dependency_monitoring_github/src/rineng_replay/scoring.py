"""Scoring-stage namespace. Evaluation-only data are intentionally absent."""

from .ledger import ScoreRecord


__all__ = ["ScoreRecord"]

