"""Calibration-only operating-context conditioning and support diagnostics."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.cluster import KMeans

from .data import ObservedTrajectory


_EPS = np.finfo(float).eps


@dataclass(frozen=True)
class FrozenScaler:
    """Per-engine sensor scaling fitted on a fixed calibration prefix."""

    center: np.ndarray
    scale: np.ndarray
    fit_cycle_min: int
    fit_cycle_max: int
    n_fit_rows: int

    def transform(self, sensors: np.ndarray) -> np.ndarray:
        values = np.asarray(sensors, dtype=float)
        if values.ndim != 2 or values.shape[1] != len(self.center):
            raise ValueError("sensor matrix is incompatible with the frozen scaler")
        return (values - self.center) / self.scale


@dataclass(frozen=True)
class FrozenContextModel:
    """Operating-context model fitted once and then held fixed."""

    branch: str
    setting_center: np.ndarray
    setting_scale: np.ndarray
    coefficients: np.ndarray
    intercept: np.ndarray
    calibration_settings_scaled: np.ndarray
    support_radius: float
    regime_centers: np.ndarray | None = None

    def predict(self, settings: np.ndarray) -> np.ndarray:
        standardized = _standardize_settings(
            settings, self.setting_center, self.setting_scale
        )
        if self.branch == "raw":
            return np.zeros((len(standardized), len(self.intercept)), dtype=float)
        if self.branch == "linear":
            return standardized @ self.coefficients + self.intercept
        if self.branch == "quadratic":
            return _quadratic_features(standardized) @ self.coefficients + self.intercept
        if self.branch == "regime":
            if self.regime_centers is None:
                raise RuntimeError("regime model is missing its calibration centers")
            distances = _pairwise_distances(standardized, self.regime_centers)
            labels = np.argmin(distances, axis=1)
            return self.coefficients[labels]
        raise ValueError(f"unsupported context branch: {self.branch}")


@dataclass(frozen=True)
class ConditionedResult:
    residuals: np.ndarray
    support_distance: np.ndarray
    supported: np.ndarray
    residual_energy_ratio: float


@dataclass(frozen=True)
class ConditioningAudit:
    sensor_residual_energy_ratio: np.ndarray
    sensor_variance_retention: np.ndarray
    condition_association_before: np.ndarray
    condition_association_after: np.ndarray
    unsupported_rows: int
    unsupported_fraction: float


def fit_engine_scaler(
    trajectory: ObservedTrajectory, calibration_cycles: int
) -> FrozenScaler:
    """Fit a sensor scaler using exactly cycles 1 through C."""

    mask = trajectory.cycles <= int(calibration_cycles)
    fit_rows = trajectory.sensors[mask]
    fit_cycles = trajectory.cycles[mask]
    if len(fit_rows) != calibration_cycles:
        raise ValueError("calibration prefix must contain exactly cycles 1 through C")
    if fit_cycles[0] != 1 or fit_cycles[-1] != calibration_cycles:
        raise ValueError("calibration cycles are not contiguous from cycle 1")
    center = np.mean(fit_rows, axis=0)
    scale = np.std(fit_rows, axis=0, ddof=1)
    scale = np.where(scale > 1.0e-12, scale, 1.0)
    return FrozenScaler(
        center=center,
        scale=scale,
        fit_cycle_min=int(fit_cycles[0]),
        fit_cycle_max=int(fit_cycles[-1]),
        n_fit_rows=len(fit_rows),
    )


def fit_context_model(
    settings: np.ndarray,
    sensors: np.ndarray,
    branch: str,
    *,
    ridge_alpha: float = 1.0e-3,
    max_regimes: int = 6,
) -> FrozenContextModel:
    """Fit one context branch using calibration rows only."""

    setting_values = np.asarray(settings, dtype=float)
    sensor_values = np.asarray(sensors, dtype=float)
    if setting_values.ndim != 2 or setting_values.shape[1] != 3:
        raise ValueError("settings must have shape (n_rows, 3)")
    if sensor_values.ndim != 2 or len(sensor_values) != len(setting_values):
        raise ValueError("sensor and setting calibration rows must align")
    if branch not in {"raw", "linear", "quadratic", "regime"}:
        raise ValueError(f"unsupported context branch: {branch}")

    setting_center = np.mean(setting_values, axis=0)
    setting_scale = np.std(setting_values, axis=0, ddof=1)
    setting_scale = np.where(setting_scale > 1.0e-12, setting_scale, 1.0)
    standardized = _standardize_settings(
        setting_values, setting_center, setting_scale
    )
    support_radius = _calibration_support_radius(standardized)
    n_outputs = sensor_values.shape[1]

    if branch == "raw":
        coefficients = np.zeros((0, n_outputs), dtype=float)
        intercept = np.zeros(n_outputs, dtype=float)
        regime_centers = None
    elif branch == "linear":
        coefficients, intercept = _ridge_fit(
            standardized, sensor_values, ridge_alpha
        )
        regime_centers = None
    elif branch == "quadratic":
        coefficients, intercept = _ridge_fit(
            _quadratic_features(standardized), sensor_values, ridge_alpha
        )
        regime_centers = None
    else:
        n_regimes = min(max_regimes, max(1, int(round(np.sqrt(len(standardized) / 2)))))
        estimator = KMeans(
            n_clusters=n_regimes,
            random_state=20260819,
            n_init=10,
        )
        labels = estimator.fit_predict(standardized)
        coefficients = np.vstack(
            [np.mean(sensor_values[labels == index], axis=0) for index in range(n_regimes)]
        )
        intercept = np.zeros(n_outputs, dtype=float)
        regime_centers = estimator.cluster_centers_

    return FrozenContextModel(
        branch=branch,
        setting_center=setting_center,
        setting_scale=setting_scale,
        coefficients=coefficients,
        intercept=intercept,
        calibration_settings_scaled=standardized.copy(),
        support_radius=support_radius,
        regime_centers=regime_centers,
    )


def transform_with_support(
    model: FrozenContextModel,
    settings: np.ndarray,
    sensors: np.ndarray,
) -> ConditionedResult:
    """Apply a frozen context model and report calibration-support distance."""

    setting_values = np.asarray(settings, dtype=float)
    sensor_values = np.asarray(sensors, dtype=float)
    if sensor_values.ndim != 2 or len(sensor_values) != len(setting_values):
        raise ValueError("sensor and setting rows must align")
    standardized = _standardize_settings(
        setting_values, model.setting_center, model.setting_scale
    )
    distances = _pairwise_distances(
        standardized, model.calibration_settings_scaled
    )
    support_distance = np.min(distances, axis=1)
    supported = support_distance <= model.support_radius
    residuals = sensor_values - model.predict(setting_values)
    input_energy = float(np.sum(np.square(sensor_values)))
    residual_energy = float(np.sum(np.square(residuals)))
    energy_ratio = residual_energy / max(input_energy, _EPS)
    return ConditionedResult(
        residuals=residuals,
        support_distance=support_distance,
        supported=supported,
        residual_energy_ratio=float(energy_ratio),
    )


def audit_conditioning(
    settings: np.ndarray,
    sensors: np.ndarray,
    result: ConditionedResult,
) -> ConditioningAudit:
    """Summarize signal preservation and operating-context removal by sensor."""

    setting_values = np.asarray(settings, dtype=float)
    sensor_values = np.asarray(sensors, dtype=float)
    residuals = np.asarray(result.residuals, dtype=float)
    if sensor_values.shape != residuals.shape:
        raise ValueError("sensor and residual matrices must have the same shape")
    if len(setting_values) != len(sensor_values):
        raise ValueError("setting and sensor rows must align")

    input_energy = np.sum(np.square(sensor_values), axis=0)
    residual_energy = np.sum(np.square(residuals), axis=0)
    energy_ratio = residual_energy / np.maximum(input_energy, _EPS)
    input_variance = np.var(sensor_values, axis=0, ddof=1)
    residual_variance = np.var(residuals, axis=0, ddof=1)
    variance_retention = residual_variance / np.maximum(input_variance, _EPS)
    association_before = _maximum_absolute_correlation(setting_values, sensor_values)
    association_after = _maximum_absolute_correlation(setting_values, residuals)
    unsupported_rows = int(np.count_nonzero(~result.supported))
    return ConditioningAudit(
        sensor_residual_energy_ratio=energy_ratio,
        sensor_variance_retention=variance_retention,
        condition_association_before=association_before,
        condition_association_after=association_after,
        unsupported_rows=unsupported_rows,
        unsupported_fraction=unsupported_rows / max(len(result.supported), 1),
    )


def _standardize_settings(
    settings: np.ndarray, center: np.ndarray, scale: np.ndarray
) -> np.ndarray:
    values = np.asarray(settings, dtype=float)
    if values.ndim != 2 or values.shape[1] != 3:
        raise ValueError("settings must have shape (n_rows, 3)")
    return (values - center) / scale


def _ridge_fit(
    features: np.ndarray, targets: np.ndarray, alpha: float
) -> tuple[np.ndarray, np.ndarray]:
    feature_center = np.mean(features, axis=0)
    target_center = np.mean(targets, axis=0)
    centered_features = features - feature_center
    centered_targets = targets - target_center
    gram = centered_features.T @ centered_features
    penalty = float(alpha) * np.eye(gram.shape[0])
    coefficients = np.linalg.solve(
        gram + penalty, centered_features.T @ centered_targets
    )
    intercept = target_center - feature_center @ coefficients
    return coefficients, intercept


def _quadratic_features(settings: np.ndarray) -> np.ndarray:
    x0, x1, x2 = settings.T
    return np.column_stack(
        (x0, x1, x2, x0 * x0, x0 * x1, x0 * x2, x1 * x1, x1 * x2, x2 * x2)
    )


def _pairwise_distances(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    differences = left[:, None, :] - right[None, :, :]
    return np.sqrt(np.sum(np.square(differences), axis=2))


def _calibration_support_radius(settings: np.ndarray) -> float:
    if len(settings) < 2:
        return 1.0
    distances = _pairwise_distances(settings, settings)
    np.fill_diagonal(distances, np.inf)
    nearest = np.min(distances, axis=1)
    positive = nearest[np.isfinite(nearest) & (nearest > 1.0e-12)]
    if len(positive) == 0:
        return 1.0
    return float(max(1.5 * np.quantile(positive, 0.99), 1.0e-6))


def _maximum_absolute_correlation(
    settings: np.ndarray, signals: np.ndarray
) -> np.ndarray:
    output = np.zeros(signals.shape[1], dtype=float)
    for sensor_index in range(signals.shape[1]):
        correlations: list[float] = []
        signal = signals[:, sensor_index]
        if np.std(signal) <= 1.0e-12:
            continue
        for setting_index in range(settings.shape[1]):
            setting = settings[:, setting_index]
            if np.std(setting) <= 1.0e-12:
                continue
            correlations.append(float(abs(np.corrcoef(setting, signal)[0, 1])))
        if correlations:
            output[sensor_index] = max(correlations)
    return output
