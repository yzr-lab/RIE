"""Endpoint-isolated evaluation and maintenance-workload metrics."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from .ledger import LedgerManifest, verify_locked_ledger


def load_verified_scores(manifest_path: Path) -> tuple[pd.DataFrame, dict]:
    """Verify every score partition before parsing any score rows."""

    payload = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    manifests = [LedgerManifest(**item) for item in payload["partitions"]]
    for manifest in manifests:
        if manifest.protocol_sha256 != payload["protocol_sha256"]:
            raise ValueError("score partition protocol hash is inconsistent")
        verify_locked_ledger(Path(manifest.path), manifest)
    frames = [pd.read_json(manifest.path, lines=True) for manifest in manifests]
    return pd.concat(frames, ignore_index=True), payload


def join_training_endpoints(
    manifest_path: Path,
    data_root: Path,
    *,
    horizon: int,
) -> tuple[pd.DataFrame, dict]:
    """Join training endpoints only after all score ledgers pass verification."""

    scores, manifest = load_verified_scores(manifest_path)
    endpoints: list[pd.DataFrame] = []
    for subset in sorted(scores["subset"].unique()):
        path = Path(data_root) / f"train_{subset}.txt"
        observed = pd.read_csv(
            path,
            sep=r"\s+",
            header=None,
            usecols=[0, 1],
            names=["engine_id", "cycle"],
        )
        maxima = observed.groupby("engine_id", as_index=False)["cycle"].max()
        maxima = maxima.rename(columns={"cycle": "max_cycle"})
        maxima["subset"] = subset
        endpoints.append(maxima)
    endpoint_frame = pd.concat(endpoints, ignore_index=True)
    joined = scores.merge(
        endpoint_frame,
        on=["subset", "engine_id"],
        how="left",
        validate="many_to_one",
    )
    if joined["max_cycle"].isna().any():
        raise ValueError("one or more score rows lack a training endpoint")
    joined["rul"] = joined["max_cycle"] - joined["score_time"]
    joined["event_label"] = joined["rul"] <= int(horizon)
    return joined, manifest


def normalized_partial_auc(
    labels: np.ndarray | pd.Series,
    scores: np.ndarray | pd.Series,
    *,
    max_fpr: float,
) -> float:
    y_true = np.asarray(labels, dtype=int)
    y_score = np.asarray(scores, dtype=float)
    if len(np.unique(y_true)) < 2:
        return float("nan")
    return float(roc_auc_score(y_true, y_score, max_fpr=max_fpr))


def ranking_metrics(frame: pd.DataFrame, *, max_fpr: float = 0.10) -> dict[str, float | int]:
    labels = frame["event_label"].to_numpy(dtype=int)
    scores = frame["score"].to_numpy(dtype=float)
    pooled_auc = float(roc_auc_score(labels, scores)) if len(np.unique(labels)) == 2 else float("nan")
    pooled_pauc = normalized_partial_auc(labels, scores, max_fpr=max_fpr)
    engine_auc: list[float] = []
    engine_pauc: list[float] = []
    for _, group in frame.groupby(["subset", "engine_id"], sort=False):
        engine_labels = group["event_label"].to_numpy(dtype=int)
        if len(np.unique(engine_labels)) < 2:
            continue
        engine_auc.append(float(roc_auc_score(engine_labels, group["score"])))
        engine_pauc.append(
            normalized_partial_auc(
                engine_labels, group["score"], max_fpr=max_fpr
            )
        )
    return {
        "pooled_window_auc": pooled_auc,
        "normalized_pauc_0_10": pooled_pauc,
        "engine_macro_auc": float(np.mean(engine_auc)) if engine_auc else float("nan"),
        "engine_macro_pauc_0_10": float(np.mean(engine_pauc)) if engine_pauc else float("nan"),
        "engine_macro_denominator": len(engine_auc),
        "window_count": len(frame),
    }


def summarize_alert_workload(
    frame: pd.DataFrame,
    *,
    horizon: int,
) -> dict[str, float | int]:
    """Compute workload, coverage, and separately defined lead quantities.

    ``event_label`` is derived from ``max_cycle - score_time <= horizon``; an
    engine's proxy-event cycle is ``max_cycle - horizon``. Exposure is the
    inclusive range ``[first scheduled score, observed end]``.
    """
    rows = frame.copy().reset_index(drop=True)
    engine_keys = ["subset", "engine_id"]
    fleet_engines = len(rows[engine_keys].drop_duplicates())

    persistent = rows["persistent_alert"].astype(bool).to_numpy(dtype=bool)
    raw_alert = rows["alert"].astype(bool).to_numpy(dtype=bool)
    score_time = rows["score_time"].to_numpy(dtype=float)
    max_cycle = rows["max_cycle"].to_numpy(dtype=float)
    event_label = (max_cycle - score_time) <= float(horizon)
    pre_proxy = ~event_label
    episode_notna = rows["episode_id"].notna().to_numpy(dtype=bool)

    pre_proxy_count = int(pre_proxy.sum())
    event_count = int(event_label.sum())
    raw_exceedance_rate_pre_proxy = (
        float(raw_alert[pre_proxy].mean()) if pre_proxy_count else float("nan")
    )
    persistent_window_rate_pre_proxy = (
        float(persistent[pre_proxy].mean()) if pre_proxy_count else float("nan")
    )

    # Episodes are counted once by (subset, engine_id, episode_id).
    all_episode_count = len(
        rows.loc[episode_notna, [*engine_keys, "episode_id"]].drop_duplicates()
    )
    pre_proxy_episode_count = len(
        rows.loc[
            episode_notna & pre_proxy, [*engine_keys, "episode_id"]
        ].drop_duplicates()
    )

    exposure = 0.0
    failure_detected: list[float] = []
    failure_fleet: list[float] = []
    pre_proxy_advance_fleet: list[float] = []
    pre_proxy_advance_detected: list[float] = []
    first_persistent: list[float] = []
    for _, group in rows.groupby(engine_keys, sort=False):
        t_obs = float(group["max_cycle"].iloc[0])
        t_first = float(group["score_time"].min())
        exposure += max(t_obs - t_first + 1.0, 0.0)
        e = t_obs - float(horizon)
        f_series = group.loc[
            group["persistent_alert"].astype(bool), "score_time"
        ]
        if len(f_series):
            f = float(f_series.min())
            first_persistent.append(f)
            failure_detected.append(t_obs - f)
            failure_fleet.append(t_obs - f)
            pre_proxy_advance_fleet.append(max(e - f, 0.0))
            if f <= e:
                pre_proxy_advance_detected.append(e - f)
        else:
            failure_fleet.append(0.0)
            pre_proxy_advance_fleet.append(0.0)

    event_observed = len(rows.loc[event_label, engine_keys].drop_duplicates())
    event_detected = len(
        rows.loc[persistent & event_label, engine_keys].drop_duplicates()
    )

    def _mean(values: list[float]) -> float:
        return float(np.mean(values)) if values else float("nan")

    return {
        "fleet_engines": fleet_engines,
        "event_observed_engines": int(event_observed),
        "event_detected_engines": int(event_detected),
        "pre_proxy_window_count": pre_proxy_count,
        "event_window_count": event_count,
        "exposure_engine_cycles": float(exposure),
        "raw_exceedance_rate_pre_proxy": raw_exceedance_rate_pre_proxy,
        "persistent_window_rate_pre_proxy": persistent_window_rate_pre_proxy,
        "all_episode_count": int(all_episode_count),
        "pre_proxy_episode_count": int(pre_proxy_episode_count),
        "all_episode_rate_per_engine": (
            float(all_episode_count / fleet_engines) if fleet_engines else float("nan")
        ),
        "all_episode_rate_per_1000_engine_cycles": (
            float(1000.0 * all_episode_count / exposure) if exposure else float("nan")
        ),
        "pre_proxy_episode_rate_per_engine": (
            float(pre_proxy_episode_count / fleet_engines) if fleet_engines else float("nan")
        ),
        "pre_proxy_episode_rate_per_1000_engine_cycles": (
            float(1000.0 * pre_proxy_episode_count / exposure) if exposure else float("nan")
        ),
        "event_region_coverage": (
            float(event_detected / event_observed) if event_observed else float("nan")
        ),
        "failure_lead_detected_mean": _mean(failure_detected),
        "failure_lead_detected_n": len(failure_detected),
        "failure_lead_fleet_zero_filled": _mean(failure_fleet),
        "pre_proxy_advance_detected_mean": _mean(pre_proxy_advance_detected),
        "pre_proxy_advance_detected_n": len(pre_proxy_advance_detected),
        "pre_proxy_advance_fleet_zero_filled": _mean(pre_proxy_advance_fleet),
        "first_persistent_time_mean": _mean(first_persistent),
        "first_persistent_time_n": len(first_persistent),
    }


def paired_advance_metrics(delta: np.ndarray | pd.Series) -> dict[str, float | int]:
    values = np.asarray(delta, dtype=float)
    if len(values) == 0:
        return {
            "paired_engines": 0,
            "probability_positive": float("nan"),
            "v20": float("nan"),
            "v40": float("nan"),
            "v60": float("nan"),
            "paired_mean": float("nan"),
            "paired_median": float("nan"),
        }
    return {
        "paired_engines": len(values),
        "probability_positive": float(np.mean(values > 0.0)),
        "v20": float(np.mean(values >= 20.0)),
        "v40": float(np.mean(values >= 40.0)),
        "v60": float(np.mean(values >= 60.0)),
        "paired_mean": float(np.mean(values)),
        "paired_median": float(np.median(values)),
    }


def apply_threshold_multiplier(
    frame: pd.DataFrame,
    *,
    multiplier: float,
    persistence: int,
) -> pd.DataFrame:
    """Reclassify locked scores under a threshold multiplier and persistence rule."""

    if multiplier <= 0.0 or persistence < 1:
        raise ValueError("multiplier and persistence must be positive")
    rows = frame.copy().reset_index(drop=True)
    rows["_original_order"] = np.arange(len(rows))
    alerts = rows["score"] > multiplier * rows["threshold"]
    rows["alert"] = alerts.astype(bool)
    persistent_values = np.zeros(len(rows), dtype=bool)
    episode_values = np.empty(len(rows), dtype=object)
    episode_values[:] = None
    group_keys = ["subset", "engine_id", "monitor", "conditioning"]
    for _, group in rows.groupby(group_keys, sort=False):
        ordered = group.sort_values("score_time")
        consecutive = 0
        next_episode = 1
        active_episode: int | None = None
        for row_index, is_alert in zip(ordered.index, ordered["alert"], strict=True):
            consecutive = consecutive + 1 if bool(is_alert) else 0
            persistent = consecutive >= persistence
            if persistent and active_episode is None:
                active_episode = next_episode
                next_episode += 1
            if not is_alert:
                active_episode = None
            persistent_values[row_index] = persistent
            episode_values[row_index] = active_episode if persistent else None
    rows["persistent_alert"] = persistent_values
    rows["episode_id"] = pd.Series(episode_values, index=rows.index, dtype=object)
    return rows.sort_values("_original_order").drop(columns="_original_order")


def first_persistent_alerts(frame: pd.DataFrame) -> pd.DataFrame:
    alerts = frame[frame["persistent_alert"].astype(bool)]
    return (
        alerts.groupby(["subset", "engine_id"], as_index=False)["score_time"]
        .min()
        .rename(columns={"score_time": "first_persistent_alert"})
    )
