"""Observed-data loaders that deliberately exclude evaluation endpoints."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


COLUMNS = ["unit", "time", "op1", "op2", "op3"] + [
    f"sensor{i}" for i in range(1, 22)
]
CONSTANT_SENSORS = {
    "sensor1",
    "sensor5",
    "sensor6",
    "sensor10",
    "sensor16",
    "sensor18",
    "sensor19",
}
SENSOR_NAMES = tuple(
    name for name in COLUMNS if name.startswith("sensor") and name not in CONSTANT_SENSORS
)
# Original NASA C-MAPSS sensor identifiers, in the same order as SENSOR_NAMES.
# SENSOR_NAMES excludes constant channels, so these are the non-constant subset
# of s1..s21. A compressed relation index i refers to SENSOR_ORIGINAL_LABELS[i].
SENSOR_ORIGINAL_LABELS = tuple(
    name.replace("sensor", "s") for name in SENSOR_NAMES
)


@dataclass(frozen=True)
class ObservedTrajectory:
    subset: str
    engine_id: int
    cycles: np.ndarray
    settings: np.ndarray
    sensors: np.ndarray
    sensor_names: tuple[str, ...]

    def __post_init__(self) -> None:
        n_rows = len(self.cycles)
        if self.settings.shape != (n_rows, 3):
            raise ValueError("settings must have shape (n_rows, 3)")
        if self.sensors.shape != (n_rows, len(self.sensor_names)):
            raise ValueError("sensor matrix does not match cycles and sensor names")
        if n_rows and np.any(np.diff(self.cycles) <= 0):
            raise ValueError("cycles must be strictly increasing")
        if not np.isfinite(self.settings).all() or not np.isfinite(self.sensors).all():
            raise ValueError("observed data contain non-finite values")


def load_cmapss_observed(
    data_root: Path,
    subset: str,
    split: str,
    engine_ids: Iterable[int] | None,
) -> list[ObservedTrajectory]:
    """Load only signal and operating-setting columns from a C-MAPSS split."""

    if subset not in {"FD001", "FD002", "FD003", "FD004"}:
        raise ValueError(f"unsupported subset: {subset}")
    if split not in {"train", "test"}:
        raise ValueError("split must be 'train' or 'test'")
    path = Path(data_root) / f"{split}_{subset}.txt"
    frame = pd.read_csv(path, sep=r"\s+", header=None, names=COLUMNS)
    if engine_ids is not None:
        selected = {int(value) for value in engine_ids}
        frame = frame[frame["unit"].isin(selected)]
    records: list[ObservedTrajectory] = []
    for engine_id, group in frame.groupby("unit", sort=True):
        group = group.sort_values("time")
        records.append(
            ObservedTrajectory(
                subset=subset,
                engine_id=int(engine_id),
                cycles=group["time"].to_numpy(dtype=int, copy=True),
                settings=group[["op1", "op2", "op3"]].to_numpy(dtype=float, copy=True),
                sensors=group[list(SENSOR_NAMES)].to_numpy(dtype=float, copy=True),
                sensor_names=SENSOR_NAMES,
            )
        )
    return records

