"""Engine-level uncertainty procedures with fixed FD composition."""

from __future__ import annotations

import numpy as np
import pandas as pd


def fixed_fd_engine_bootstrap(
    frame: pd.DataFrame,
    *,
    n_resamples: int,
    seed: int,
    confidence: float = 0.95,
) -> dict[str, object]:
    required = {"subset", "engine_id", "value"}
    if not required.issubset(frame.columns):
        raise ValueError(f"bootstrap frame must contain {sorted(required)}")
    if frame.duplicated(["subset", "engine_id"]).any():
        raise ValueError("bootstrap requires one value per engine")
    if n_resamples < 10:
        raise ValueError("n_resamples must be at least 10")
    rng = np.random.default_rng(seed)
    groups = {
        subset: group["value"].to_numpy(dtype=float)
        for subset, group in frame.groupby("subset", sort=True)
    }
    estimates = np.empty(n_resamples, dtype=float)
    for index in range(n_resamples):
        sampled = [
            rng.choice(values, size=len(values), replace=True)
            for values in groups.values()
        ]
        estimates[index] = float(np.mean(np.concatenate(sampled)))
    alpha = (1.0 - confidence) / 2.0
    return {
        "estimate": float(frame["value"].mean()),
        "ci_low": float(np.quantile(estimates, alpha)),
        "ci_high": float(np.quantile(estimates, 1.0 - alpha)),
        "confidence": confidence,
        "n_resamples": n_resamples,
        "seed": seed,
        "fd_counts": {key: len(value) for key, value in groups.items()},
    }
