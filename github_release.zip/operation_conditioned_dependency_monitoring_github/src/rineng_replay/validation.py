"""Static validation for the strict scoring boundary."""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterable


FORBIDDEN_IDENTIFIERS = {
    "rul",
    "event_label",
    "trajectory_length",
    "final_length",
    "max_cycle",
    "first_alert_rul",
    "paired_advance",
}


def audit_scoring_source(paths: Iterable[Path]) -> dict:
    references: list[dict[str, str | int]] = []
    for path_value in paths:
        path = Path(path_value)
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            name = None
            if isinstance(node, ast.Name):
                name = node.id
            elif isinstance(node, ast.arg):
                name = node.arg
            elif isinstance(node, ast.Attribute):
                name = node.attr
            if name is not None and name.lower() in FORBIDDEN_IDENTIFIERS:
                references.append(
                    {
                        "path": path.as_posix(),
                        "line": int(getattr(node, "lineno", 0)),
                        "identifier": name,
                    }
                )
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                module = getattr(node, "module", "") or ""
                if "evaluation" in module.lower():
                    references.append(
                        {
                            "path": path.as_posix(),
                            "line": int(getattr(node, "lineno", 0)),
                            "identifier": module,
                        }
                    )
    return {"passed": not references, "forbidden_references": references}

