"""Calibration-fixed lagged-relation screening and window feature extraction."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.stats import t as student_t

from .data import SENSOR_ORIGINAL_LABELS


@dataclass(frozen=True)
class Relation:
    rank: int
    source: int
    target: int
    lag: int
    strength: float
    sign: int
    p_value: float

    @property
    def key(self) -> str:
        """Legacy compressed-index key (e.g. s3->s0@1), retained for traceability."""
        return f"s{self.source}->s{self.target}@{self.lag}"

    @property
    def source_name(self) -> str:
        return SENSOR_ORIGINAL_LABELS[self.source]

    @property
    def target_name(self) -> str:
        return SENSOR_ORIGINAL_LABELS[self.target]

    @property
    def display_key(self) -> str:
        """Original NASA sensor-identifier key (e.g. s14->s13@1)."""
        return f"{self.source_name}->{self.target_name}@{self.lag}"


@dataclass(frozen=True)
class RelationSet:
    relations: tuple[Relation, ...]
    candidate_count: int
    fdr_retained_count: int
    sensor_count: int
    max_lag: int
    calibration_rows: int


def fit_top_strength_relations(
    calibration: np.ndarray,
    max_lag: int,
    m: int,
    *,
    fdr_alpha: float = 0.05,
) -> RelationSet:
    """Lock the strongest directed lagged associations on calibration data."""

    values = _validate_signals(calibration)
    if max_lag < 1 or max_lag >= len(values):
        raise ValueError("max_lag must be positive and shorter than calibration")
    if m < 1:
        raise ValueError("m must be positive")

    raw: list[tuple[int, int, int, float, float]] = []
    for source in range(values.shape[1]):
        for target in range(values.shape[1]):
            if source == target:
                continue
            for lag in range(1, max_lag + 1):
                coefficient = _correlation(values[:-lag, source], values[lag:, target])
                raw.append((source, target, lag, coefficient, _correlation_p_value(coefficient, len(values) - lag)))

    retained_count = _benjamini_hochberg_count(
        np.asarray([item[4] for item in raw], dtype=float), fdr_alpha
    )
    ordered = sorted(raw, key=lambda item: (-abs(item[3]), item[0], item[1], item[2]))
    selected: list[Relation] = []
    for rank, (source, target, lag, coefficient, p_value) in enumerate(
        ordered[: min(m, len(ordered))], start=1
    ):
        selected.append(
            Relation(
                rank=rank,
                source=source,
                target=target,
                lag=lag,
                strength=float(abs(coefficient)),
                sign=1 if coefficient >= 0.0 else -1,
                p_value=float(p_value),
            )
        )
    return RelationSet(
        relations=tuple(selected),
        candidate_count=len(raw),
        fdr_retained_count=retained_count,
        sensor_count=values.shape[1],
        max_lag=max_lag,
        calibration_rows=len(values),
    )


def fit_stratified_random_relations(
    calibration: np.ndarray,
    max_lag: int,
    m: int,
    *,
    seed: int = 0,
) -> RelationSet:
    """Label-free target-sensor-stratified random relation set (alternative selector).

    Picks one random (source, lag) per target, then fills to ``m`` from the
    remaining candidates with a fixed seed. Used only as an ablation, not the
    primary selector.
    """
    values = _validate_signals(calibration)
    if max_lag < 1 or max_lag >= len(values):
        raise ValueError("max_lag must be positive and shorter than calibration")
    n_sensor = values.shape[1]
    candidates: list[tuple[int, int, int]] = []
    for source in range(n_sensor):
        for target in range(n_sensor):
            if source == target:
                continue
            for lag in range(1, max_lag + 1):
                candidates.append((source, target, lag))
    rng = np.random.default_rng(seed)
    chosen: set[tuple[int, int, int]] = set()
    ordered: list[tuple[int, int, int]] = []
    for target in range(n_sensor):
        pool = [c for c in candidates if c[1] == target and c not in chosen]
        if pool:
            pick = pool[int(rng.integers(0, len(pool)))]
            chosen.add(pick)
            ordered.append(pick)
    remaining = [c for c in candidates if c not in chosen]
    for _ in range(m - len(ordered)):
        if not remaining:
            break
        pick = remaining.pop(int(rng.integers(0, len(remaining))))
        chosen.add(pick)
        ordered.append(pick)
    ordered = ordered[:m]
    selected: list[Relation] = []
    for rank, (source, target, lag) in enumerate(ordered, start=1):
        coefficient = _correlation(
            values[:-lag, source], values[lag:, target]
        )
        selected.append(
            Relation(
                rank=rank, source=source, target=target, lag=lag,
                strength=float(abs(coefficient)),
                sign=1 if coefficient >= 0.0 else -1,
                p_value=_correlation_p_value(coefficient, len(values) - lag),
            )
        )
    return RelationSet(
        relations=tuple(selected),
        candidate_count=len(candidates),
        fdr_retained_count=0,
        sensor_count=n_sensor,
        max_lag=max_lag,
        calibration_rows=len(values),
    )


def relation_strengths(window: np.ndarray, relation_set: RelationSet) -> np.ndarray:
    """Return signed lagged association strengths in locked relation order."""

    values = _validate_signals(window)
    if values.shape[1] != relation_set.sensor_count:
        raise ValueError("window sensor count differs from the locked relation set")
    features = np.empty(len(relation_set.relations), dtype=float)
    for index, relation in enumerate(relation_set.relations):
        if relation.lag >= len(values):
            raise ValueError("window is too short for a locked relation lag")
        features[index] = _correlation(
            values[:-relation.lag, relation.source],
            values[relation.lag:, relation.target],
        )
    return features


def _validate_signals(signals: np.ndarray) -> np.ndarray:
    values = np.asarray(signals, dtype=float)
    if values.ndim != 2 or values.shape[0] < 3 or values.shape[1] < 2:
        raise ValueError("signals must be a finite 2D matrix with at least two channels")
    if not np.isfinite(values).all():
        raise ValueError("signals contain non-finite values")
    return values


def _correlation(left: np.ndarray, right: np.ndarray) -> float:
    left_centered = left - np.mean(left)
    right_centered = right - np.mean(right)
    denominator = np.sqrt(
        np.sum(np.square(left_centered)) * np.sum(np.square(right_centered))
    )
    if denominator <= np.finfo(float).eps:
        return 0.0
    return float(np.clip(np.sum(left_centered * right_centered) / denominator, -1.0, 1.0))


def _correlation_p_value(coefficient: float, n_rows: int) -> float:
    if n_rows <= 2:
        return 1.0
    magnitude = min(abs(coefficient), 1.0 - 1.0e-15)
    statistic = magnitude * np.sqrt((n_rows - 2) / max(1.0 - magnitude * magnitude, 1.0e-15))
    return float(2.0 * student_t.sf(statistic, df=n_rows - 2))


def _benjamini_hochberg_count(p_values: np.ndarray, alpha: float) -> int:
    if len(p_values) == 0:
        return 0
    ordered = np.sort(p_values)
    thresholds = alpha * np.arange(1, len(ordered) + 1) / len(ordered)
    accepted = np.flatnonzero(ordered <= thresholds)
    return int(accepted[-1] + 1) if len(accepted) else 0
