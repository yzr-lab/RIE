"""Official C-MAPSS test-split scoring and endpoint-isolated evaluation."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .data import ObservedTrajectory
from .evaluation import load_verified_scores
from .monitors import MONITOR_NAMES
from .protocol import ReplayConfig
from .replay import ReplayAudit, TrajectoryScoreResult, score_trajectory


def score_censored_trajectory(
    trajectory: ObservedTrajectory,
    config: ReplayConfig,
    *,
    conditioning: str,
) -> TrajectoryScoreResult:
    """Score only the observed test trajectory; no endpoint input is accepted."""

    if len(trajectory.cycles) < config.calibration_cycles:
        unavailable = float("nan")
        return TrajectoryScoreResult(
            records={name: tuple() for name in MONITOR_NAMES},
            audit=ReplayAudit(
                subset=trajectory.subset,
                engine_id=trajectory.engine_id,
                conditioning=conditioning,
                monitor_windows=0,
                monitorable=False,
                fdr_retained_count=0,
                relation_candidate_count=0,
                unsupported_fraction=unavailable,
                median_support_distance=unavailable,
                residual_energy_ratio=unavailable,
                median_sensor_energy_ratio=unavailable,
                median_variance_retention=unavailable,
                median_condition_association_before=unavailable,
                median_condition_association_after=unavailable,
            ),
        )
    return score_trajectory(trajectory, config, conditioning=conditioning)


def join_official_test_endpoints(
    manifest_path: Path,
    data_root: Path,
    *,
    horizon: int,
) -> tuple[pd.DataFrame, dict]:
    """Verify locked test scores, then join observed ends and official RUL offsets."""

    scores, manifest = load_verified_scores(manifest_path)
    endpoints: list[pd.DataFrame] = []
    for subset in sorted(scores["subset"].unique()):
        observed = pd.read_csv(
            Path(data_root) / f"test_{subset}.txt",
            sep=r"\s+",
            header=None,
            usecols=[0, 1],
            names=["engine_id", "cycle"],
        )
        observed_end = (
            observed.groupby("engine_id", as_index=False)["cycle"]
            .max()
            .rename(columns={"cycle": "observed_end"})
        )
        offsets = pd.read_csv(
            Path(data_root) / f"RUL_{subset}.txt",
            sep=r"\s+",
            header=None,
            usecols=[0],
            names=["additional_rul"],
        )
        offsets["engine_id"] = np.arange(1, len(offsets) + 1)
        subset_endpoints = observed_end.merge(
            offsets, on="engine_id", validate="one_to_one"
        )
        subset_endpoints["subset"] = subset
        endpoints.append(subset_endpoints)
    endpoint_frame = pd.concat(endpoints, ignore_index=True)
    joined = scores.merge(
        endpoint_frame,
        on=["subset", "engine_id"],
        how="left",
        validate="many_to_one",
    )
    if joined[["observed_end", "additional_rul"]].isna().any().any():
        raise ValueError("one or more test score rows lack an official endpoint")
    if (joined["score_time"] > joined["observed_end"]).any():
        raise ValueError("a censored score occurs after the observed test endpoint")
    joined["max_cycle"] = joined["observed_end"] + joined["additional_rul"]
    joined["rul"] = joined["max_cycle"] - joined["score_time"]
    joined["event_label"] = joined["rul"] <= int(horizon)
    return joined, manifest
