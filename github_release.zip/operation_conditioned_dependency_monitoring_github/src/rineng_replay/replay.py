"""Sequential, window-end-timestamped trajectory scoring."""

from __future__ import annotations

import json
from dataclasses import dataclass

import numpy as np

from .conditioning import (
    audit_conditioning,
    fit_context_model,
    fit_engine_scaler,
    transform_with_support,
)
from .data import ObservedTrajectory
from .ledger import ScoreRecord
from .monitors import MONITOR_NAMES, calibration_scores_for_monitor, fit_monitor
from .protocol import ReplayConfig, iter_completed_windows
from .relations import fit_stratified_random_relations, fit_top_strength_relations


@dataclass(frozen=True)
class ReplayAudit:
    subset: str
    engine_id: int
    conditioning: str
    monitor_windows: int
    monitorable: bool
    fdr_retained_count: int
    relation_candidate_count: int
    unsupported_fraction: float
    median_support_distance: float
    residual_energy_ratio: float
    median_sensor_energy_ratio: float
    median_variance_retention: float
    median_condition_association_before: float
    median_condition_association_after: float


@dataclass(frozen=True)
class TrajectoryScoreResult:
    records: dict[str, tuple[ScoreRecord, ...]]
    audit: ReplayAudit


def score_trajectory(
    trajectory: ObservedTrajectory,
    config: ReplayConfig,
    *,
    conditioning: str,
    monitor_names: tuple[str, ...] = MONITOR_NAMES,
    threshold_branch: str = "reference_deviation",
    short_alpha: float = 0.40,
    long_alpha: float = 0.10,
    selector_mode: str = "top_strength",
    selector_seed: int = 0,
) -> TrajectoryScoreResult:
    """Score one observed trajectory without evaluation endpoints."""

    if conditioning not in {"raw", "linear", "quadratic", "regime"}:
        raise ValueError(f"unsupported conditioning branch: {conditioning}")
    if not monitor_names or any(name not in MONITOR_NAMES for name in monitor_names):
        raise ValueError("monitor_names contains an unsupported monitor")
    if threshold_branch not in {"reference_deviation", "matched_operator"}:
        raise ValueError(f"unsupported threshold branch: {threshold_branch}")
    if selector_mode not in {"top_strength", "stratified_random"}:
        raise ValueError(f"unsupported selector mode: {selector_mode}")
    calibration_mask = trajectory.cycles <= config.calibration_cycles
    if int(np.count_nonzero(calibration_mask)) != config.calibration_cycles:
        raise ValueError("trajectory lacks the fixed calibration prefix")

    scaler = fit_engine_scaler(trajectory, config.calibration_cycles)
    scaled = scaler.transform(trajectory.sensors)
    context_model = fit_context_model(
        trajectory.settings[calibration_mask],
        scaled[calibration_mask],
        conditioning,
    )
    conditioned = transform_with_support(context_model, trajectory.settings, scaled)
    preservation = audit_conditioning(
        trajectory.settings, scaled, conditioned
    )
    representation = conditioned.residuals
    calibration = representation[calibration_mask]
    if selector_mode == "stratified_random":
        relation_set = fit_stratified_random_relations(
            calibration,
            max_lag=config.max_lag,
            m=config.selector_m,
            seed=selector_seed,
        )
    else:
        relation_set = fit_top_strength_relations(
            calibration,
            max_lag=config.max_lag,
            m=config.selector_m,
        )
    completed_windows = list(iter_completed_windows(trajectory, config))
    monitorable = len(completed_windows) >= config.min_monitor_windows
    support_radius = float(context_model.support_radius)
    generated: dict[str, list[ScoreRecord]] = {name: [] for name in monitor_names}
    for monitor_name in monitor_names:
        monitor = fit_monitor(
            monitor_name,
            calibration,
            relation_set,
            config.aggregation_k,
            short_alpha=short_alpha,
            long_alpha=long_alpha,
        )
        if threshold_branch == "matched_operator":
            calibration_scores = calibration_scores_for_monitor(
                monitor,
                calibration,
                window_size=config.window_size,
                step=config.step,
            )
            threshold = _calibration_threshold(calibration_scores)
        else:
            threshold = _calibration_threshold(monitor.calibration_scores)
        consecutive = 0
        active_episode: int | None = None
        next_episode = 1
        for completed in completed_windows:
            start_row = int(
                np.searchsorted(trajectory.cycles, completed.window_start)
            )
            end_row = int(
                np.searchsorted(trajectory.cycles, completed.window_end, side="right")
            )
            unsupported_rows = int(
                np.count_nonzero(~conditioned.supported[start_row:end_row])
            )
            output = monitor.score_window(representation[start_row:end_row])
            alert = bool(output.score > threshold)
            consecutive = consecutive + 1 if alert else 0
            persistent = bool(consecutive >= config.persistence)
            if persistent and active_episode is None:
                active_episode = next_episode
                next_episode += 1
            if not alert:
                active_episode = None
            generated[monitor_name].append(
                ScoreRecord(
                    subset=trajectory.subset,
                    engine_id=trajectory.engine_id,
                    condition_group=_condition_group(trajectory.subset),
                    fault_mode_group=_fault_mode_group(trajectory.subset),
                    calibration_end=config.calibration_cycles,
                    window_start=completed.window_start,
                    window_end=completed.window_end,
                    score_time=completed.score_time,
                    monitor=monitor_name,
                    conditioning=conditioning,
                    selector_m=config.selector_m,
                    aggregation_k=config.aggregation_k,
                    score=float(output.score),
                    threshold=float(threshold),
                    alert=alert,
                    persistent_alert=persistent,
                    episode_id=active_episode if persistent else None,
                    threshold_branch=threshold_branch,
                    contributors_json=json.dumps(
                        [
                            {
                                "key": item.key,
                                "legacy_key": item.legacy_key,
                                "value": item.value,
                                "direction": item.direction,
                            }
                            for item in output.contributors
                        ],
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                    unsupported_rows_in_window=unsupported_rows,
                    support_radius=support_radius,
                    support_policy="flag_only",
                )
            )
    records: dict[str, tuple[ScoreRecord, ...]] = {
        key: tuple(value) for key, value in generated.items()
    }

    audit = ReplayAudit(
        subset=trajectory.subset,
        engine_id=trajectory.engine_id,
        conditioning=conditioning,
        monitor_windows=len(completed_windows),
        monitorable=monitorable,
        fdr_retained_count=relation_set.fdr_retained_count,
        relation_candidate_count=relation_set.candidate_count,
        unsupported_fraction=preservation.unsupported_fraction,
        median_support_distance=float(np.median(conditioned.support_distance)),
        residual_energy_ratio=conditioned.residual_energy_ratio,
        median_sensor_energy_ratio=float(
            np.median(preservation.sensor_residual_energy_ratio)
        ),
        median_variance_retention=float(
            np.median(preservation.sensor_variance_retention)
        ),
        median_condition_association_before=float(
            np.median(preservation.condition_association_before)
        ),
        median_condition_association_after=float(
            np.median(preservation.condition_association_after)
        ),
    )
    return TrajectoryScoreResult(records=records, audit=audit)


def _calibration_threshold(scores: np.ndarray) -> float:
    values = np.asarray(scores, dtype=float)
    median = float(np.median(values))
    mad = float(np.median(np.abs(values - median)))
    robust_limit = median + 3.0 * 1.4826 * mad
    return float(max(np.quantile(values, 0.99), robust_limit, 0.0))


def _condition_group(subset: str) -> str:
    return "single-condition" if subset in {"FD001", "FD003"} else "multi-condition"


def _fault_mode_group(subset: str) -> str:
    return "one-fault" if subset in {"FD001", "FD002"} else "two-fault"
