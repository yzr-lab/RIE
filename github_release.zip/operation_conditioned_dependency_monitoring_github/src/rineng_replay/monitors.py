"""Transparent dependency-monitor family with one frozen calibration interface."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .relations import RelationSet, relation_strengths


MONITOR_NAMES = ("ldsi", "dynamic_corr", "mewma", "mcusum", "var1")
_EPS = np.finfo(float).eps


@dataclass(frozen=True)
class Contributor:
    key: str
    value: float
    direction: str
    legacy_key: str | None = None


@dataclass(frozen=True)
class MonitorOutput:
    monitor: str
    score: float
    contributors: tuple[Contributor, ...]
    state: dict[str, object]


@dataclass
class TransparentMonitor:
    name: str
    relation_set: RelationSet
    aggregation_k: int
    baseline: np.ndarray
    scale: np.ndarray
    calibration_scores: np.ndarray
    short_state: np.ndarray
    long_state: np.ndarray
    cumulative_state: np.ndarray
    var_baseline: np.ndarray | None = None
    short_alpha: float = 0.40
    long_alpha: float = 0.10
    mewma_alpha: float = 0.20
    cusum_allowance: float = 0.50
    _step: int = field(default=0, init=False)

    def score_window(self, window: np.ndarray) -> MonitorOutput:
        values = np.asarray(window, dtype=float)
        if self.name == "var1":
            current = _fit_var1(values)
            if self.var_baseline is None:
                raise RuntimeError("VAR(1) baseline is missing")
            matrix_change = current - self.var_baseline
            component = np.sqrt(np.sum(np.square(matrix_change), axis=1))
            keys = tuple(f"target-sensor-{index}" for index in range(len(component)))
            score, contributors = _aggregate(component, keys, self.aggregation_k)
            state = {"step": self._step + 1, "frobenius": float(np.linalg.norm(matrix_change))}
        else:
            current = relation_strengths(values, self.relation_set)
            delta = current - self.baseline
            standardized = delta / self.scale
            if self.name == "ldsi":
                self.short_state = self.short_alpha * current + (1.0 - self.short_alpha) * self.short_state
                self.long_state = self.long_alpha * current + (1.0 - self.long_alpha) * self.long_state
                component = np.abs(self.short_state - self.long_state) / (np.abs(self.long_state) + 0.05)
                state = {
                    "step": self._step + 1,
                    "short_mean": float(np.mean(self.short_state)),
                    "long_mean": float(np.mean(self.long_state)),
                }
            elif self.name == "dynamic_corr":
                component = np.abs(standardized)
                state = {"step": self._step + 1, "mean_abs_shift": float(np.mean(np.abs(delta)))}
            elif self.name == "mewma":
                self.short_state = self.mewma_alpha * standardized + (1.0 - self.mewma_alpha) * self.short_state
                component = np.abs(self.short_state)
                state = {"step": self._step + 1, "ewma_norm": float(np.linalg.norm(self.short_state))}
            elif self.name == "mcusum":
                self.cumulative_state = np.maximum(
                    0.0, self.cumulative_state + np.abs(standardized) - self.cusum_allowance
                )
                component = self.cumulative_state
                state = {"step": self._step + 1, "cusum_norm": float(np.linalg.norm(component))}
            else:
                raise ValueError(f"unsupported monitor: {self.name}")
            keys = tuple(relation.display_key for relation in self.relation_set.relations)
            legacy_keys = tuple(relation.key for relation in self.relation_set.relations)
            score, contributors = _aggregate(
                component, keys, self.aggregation_k, delta, legacy_keys
            )
        self._step += 1
        return MonitorOutput(
            monitor=self.name,
            score=float(score),
            contributors=contributors,
            state=state,
        )


def fit_monitor(
    name: str,
    calibration: np.ndarray,
    relation_set: RelationSet,
    aggregation_k: int,
    *,
    short_alpha: float = 0.40,
    long_alpha: float = 0.10,
) -> TransparentMonitor:
    """Fit one monitor using only its calibration matrix."""

    if name not in MONITOR_NAMES:
        raise ValueError(f"unsupported monitor: {name}")
    if aggregation_k < 1 or aggregation_k > len(relation_set.relations):
        raise ValueError("aggregation_k must be between 1 and candidate M")
    values = np.asarray(calibration, dtype=float)
    baseline = relation_strengths(values, relation_set)
    feature_history = np.vstack(
        [relation_strengths(window, relation_set) for window in _reference_feature_windows(values)]
    )
    scale = np.std(feature_history, axis=0, ddof=1)
    scale = np.where(scale > 0.05, scale, 0.05)
    var_baseline = _fit_var1(values) if name == "var1" else None
    calibration_scores = _calibration_score_distribution(
        name,
        values,
        relation_set,
        aggregation_k,
        baseline,
        scale,
        var_baseline,
    )
    zeros = np.zeros_like(baseline)
    return TransparentMonitor(
        name=name,
        relation_set=relation_set,
        aggregation_k=aggregation_k,
        baseline=baseline,
        scale=scale,
        calibration_scores=calibration_scores,
        short_state=baseline.copy() if name == "ldsi" else zeros.copy(),
        long_state=baseline.copy(),
        cumulative_state=zeros.copy(),
        var_baseline=var_baseline,
        short_alpha=short_alpha,
        long_alpha=long_alpha,
    )


def _reference_feature_windows(values: np.ndarray) -> list[np.ndarray]:
    """Calibration windows used only to estimate relation scale (legacy, unchanged)."""
    width = min(40, max(20, len(values) // 2))
    step = max(5, width // 4)
    windows = [values[start : start + width] for start in range(0, len(values) - width + 1, step)]
    return windows or [values]


def _threshold_calibration_windows(
    calibration: np.ndarray, window_size: int, step: int
) -> list[np.ndarray]:
    """Complete calibration-only windows (width W, step s) for matched thresholds."""
    n = len(calibration)
    windows = [
        calibration[end - window_size : end]
        for end in range(window_size, n + 1, step)
    ]
    return windows


def calibration_scores_for_monitor(
    monitor: TransparentMonitor,
    calibration: np.ndarray,
    *,
    window_size: int,
    step: int,
) -> np.ndarray:
    """Run the monitor's own scoring recursion on matched calibration windows.

    Uses a deep-copied monitor so the caller's online state is never mutated.
    """
    import copy

    fresh = copy.deepcopy(monitor)
    scores = [
        float(fresh.score_window(window).score)
        for window in _threshold_calibration_windows(calibration, window_size, step)
    ]
    return np.asarray(scores, dtype=float)


def _calibration_score_distribution(
    name: str,
    calibration: np.ndarray,
    relation_set: RelationSet,
    aggregation_k: int,
    baseline: np.ndarray,
    scale: np.ndarray,
    var_baseline: np.ndarray | None,
) -> np.ndarray:
    scores: list[float] = []
    for window in _reference_feature_windows(calibration):
        if name == "var1":
            if var_baseline is None:
                raise RuntimeError("VAR calibration baseline is missing")
            component = np.sqrt(np.sum(np.square(_fit_var1(window) - var_baseline), axis=1))
        else:
            component = np.abs((relation_strengths(window, relation_set) - baseline) / scale)
        scores.append(float(np.mean(np.sort(component)[-min(aggregation_k, len(component)) :])))
    return np.asarray(scores, dtype=float)


def _fit_var1(values: np.ndarray, ridge: float = 1.0e-3) -> np.ndarray:
    if len(values) < 3:
        raise ValueError("VAR(1) requires at least three rows")
    previous = values[:-1]
    current = values[1:]
    design = np.column_stack((np.ones(len(previous)), previous))
    penalty = ridge * np.eye(design.shape[1])
    penalty[0, 0] = 0.0
    coefficients = np.linalg.solve(design.T @ design + penalty, design.T @ current)
    return coefficients[1:].T


def _aggregate(
    component: np.ndarray,
    keys: tuple[str, ...],
    k: int,
    signed_delta: np.ndarray | None = None,
    legacy_keys: tuple[str, ...] | None = None,
) -> tuple[float, tuple[Contributor, ...]]:
    count = min(k, len(component))
    order = np.argsort(component)[-count:][::-1]
    contributors: list[Contributor] = []
    for index in order:
        direction_value = component[index] if signed_delta is None else signed_delta[index]
        contributors.append(
            Contributor(
                key=keys[index],
                value=float(component[index]),
                direction="increase" if direction_value >= 0.0 else "decrease",
                legacy_key=legacy_keys[index] if legacy_keys is not None else None,
            )
        )
    return float(np.mean(component[order])), tuple(contributors)
