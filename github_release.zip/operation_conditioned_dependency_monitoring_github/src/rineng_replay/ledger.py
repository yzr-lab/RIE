"""Immutable scoring records and hash verification."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


class LedgerIntegrityError(RuntimeError):
    """Raised when a locked scoring ledger no longer matches its manifest."""


@dataclass(frozen=True)
class ScoreRecord:
    subset: str
    engine_id: int
    condition_group: str
    fault_mode_group: str
    calibration_end: int
    window_start: int
    window_end: int
    score_time: int
    monitor: str
    conditioning: str
    selector_m: int
    aggregation_k: int
    score: float
    threshold: float
    alert: bool
    persistent_alert: bool
    episode_id: int | None
    contributors_json: str
    threshold_branch: str = "reference_deviation"
    unsupported_rows_in_window: int = 0
    support_radius: float = 0.0
    support_policy: str = "flag_only"

    def __post_init__(self) -> None:
        if self.score_time != self.window_end:
            raise ValueError("score time must equal the completed window end")
        if self.window_start <= self.calibration_end:
            raise ValueError("monitoring window must start after calibration")
        if self.window_start > self.window_end:
            raise ValueError("window start cannot exceed window end")
        if self.aggregation_k > self.selector_m:
            raise ValueError("aggregation_k cannot exceed selector_m")


@dataclass(frozen=True)
class LedgerManifest:
    path: str
    sha256: str
    bytes: int
    row_count: int
    protocol_sha256: str
    schema_version: str = "1.0"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_score_ledger(
    records: Iterable[ScoreRecord], output_path: Path, protocol_hash: str
) -> LedgerManifest:
    if len(protocol_hash) != 64:
        raise ValueError("protocol hash must be a SHA-256 hex digest")
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(records)
    handle, temp_name = tempfile.mkstemp(
        prefix=path.name + ".", suffix=".tmp", dir=path.parent
    )
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            for record in rows:
                stream.write(
                    json.dumps(asdict(record), sort_keys=True, separators=(",", ":"))
                    + "\n"
                )
        Path(temp_name).replace(path)
    except BaseException:
        Path(temp_name).unlink(missing_ok=True)
        raise
    manifest = LedgerManifest(
        path=path.as_posix(),
        sha256=_sha256(path),
        bytes=path.stat().st_size,
        row_count=len(rows),
        protocol_sha256=protocol_hash,
    )
    sidecar = path.with_suffix(path.suffix + ".manifest.json")
    sidecar.write_text(
        json.dumps(asdict(manifest), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


def verify_locked_ledger(path: Path, manifest: LedgerManifest) -> None:
    ledger_path = Path(path)
    if not ledger_path.is_file():
        raise LedgerIntegrityError(f"ledger is missing: {ledger_path}")
    if ledger_path.stat().st_size != manifest.bytes:
        raise LedgerIntegrityError("ledger byte size differs from its manifest")
    if _sha256(ledger_path) != manifest.sha256:
        raise LedgerIntegrityError("ledger SHA-256 differs from its manifest")
    with ledger_path.open("r", encoding="utf-8") as stream:
        row_count = sum(1 for line in stream if line.strip())
    if row_count != manifest.row_count:
        raise LedgerIntegrityError("ledger row count differs from its manifest")

