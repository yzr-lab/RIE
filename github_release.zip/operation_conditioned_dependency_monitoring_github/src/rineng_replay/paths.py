"""Portable project and third-party data path resolution."""

from __future__ import annotations

import os
from collections.abc import Mapping
from pathlib import Path


def resolve_cmapss_root(
    project_root: Path,
    *,
    environ: Mapping[str, str] | None = None,
) -> Path:
    """Return the first existing C-MAPSS directory in the public search order."""

    project_root = Path(project_root).resolve()
    values = os.environ if environ is None else environ
    candidates: list[Path] = []
    configured = values.get("CMAPSS_DATA_ROOT", "").strip()
    if configured:
        candidates.append(Path(configured).expanduser())
    candidates.extend(
        (
            project_root / "data" / "cmapss",
            project_root.parent / "data" / "cmapss",
        )
    )
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved.is_dir():
            return resolved
    rendered = "\n  - ".join(str(path.resolve()) for path in candidates)
    raise FileNotFoundError(
        "C-MAPSS data directory was not found. Set CMAPSS_DATA_ROOT or place "
        f"the NASA files in one of:\n  - {rendered}"
    )
